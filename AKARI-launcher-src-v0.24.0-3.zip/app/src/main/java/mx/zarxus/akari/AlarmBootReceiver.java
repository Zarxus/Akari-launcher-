package mx.zarxus.akari;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
public class AlarmBootReceiver extends BroadcastReceiver {
    @Override public void onReceive(Context c, Intent i) {
        if (Prefs.alarmEnabled()) AlarmScheduler.schedule(c);
    }
}
