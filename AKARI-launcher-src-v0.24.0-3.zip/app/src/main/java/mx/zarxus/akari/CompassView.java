package mx.zarxus.akari;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RadialGradient;
import android.graphics.Shader;
import android.util.AttributeSet;
import android.view.View;

/** Instrument-style compass dial with a damped bearing transition. */
public class CompassView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path needle = new Path();
    private float heading;
    private float targetHeading;
    private boolean animating;

    public CompassView(Context context) { this(context, null); }

    public CompassView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setWillNotDraw(false);
        setClickable(true);
        setFocusable(true);
        setContentDescription("Brújula");
    }

    public void setHeading(float value) {
        targetHeading = normalize(value);
        if (!animating) {
            animating = true;
            postInvalidateOnAnimation();
        }
        setContentDescription(direction(targetHeading) + ", " + Math.round(targetHeading) + " grados");
    }

    public float getHeading() { return normalize(heading); }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float delta = shortest(targetHeading - heading);
        heading = normalize(heading + delta * .16f);
        if (Math.abs(delta) < .08f) {
            heading = targetHeading;
            animating = false;
        }

        float w = getWidth();
        float h = getHeight();
        float cx = w * .5f;
        float cy = h * .49f;
        float r = Math.min(w, h) * .405f;
        float d = getResources().getDisplayMetrics().density;

        paint.setStyle(Paint.Style.FILL);
        paint.setShader(new RadialGradient(cx, cy, r, 0xDD171321, 0xF005040A,
                Shader.TileMode.CLAMP));
        canvas.drawCircle(cx, cy, r, paint);
        paint.setShader(null);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(1.3f * d);
        paint.setColor(0xAA2EF0FF);
        canvas.drawCircle(cx, cy, r, paint);
        paint.setStrokeWidth(.7f * d);
        paint.setColor(0x66FF2ED9);
        canvas.drawCircle(cx, cy, r * .79f, paint);

        for (int degree = 0; degree < 360; degree += 5) {
            float display = degree - heading - 90f;
            double rad = Math.toRadians(display);
            boolean major = degree % 30 == 0;
            boolean mid = degree % 10 == 0;
            float outerX = cx + (float) Math.cos(rad) * r * .95f;
            float outerY = cy + (float) Math.sin(rad) * r * .95f;
            float innerRadius = r * (major ? .82f : mid ? .87f : .91f);
            float innerX = cx + (float) Math.cos(rad) * innerRadius;
            float innerY = cy + (float) Math.sin(rad) * innerRadius;
            paint.setStrokeWidth((major ? 1.8f : .8f) * d);
            paint.setColor(major ? 0xFFF4F0FF : 0x779B93B3);
            canvas.drawLine(innerX, innerY, outerX, outerY, paint);
        }

        drawCardinal(canvas, "N", 0, cx, cy, r, 0xFFFF2ED9);
        drawCardinal(canvas, "E", 90, cx, cy, r, 0xFF2EF0FF);
        drawCardinal(canvas, "S", 180, cx, cy, r, 0xFFF4F0FF);
        drawCardinal(canvas, "O", 270, cx, cy, r, 0xFF2EF0FF);

        needle.reset();
        needle.moveTo(cx, cy - r * .69f);
        needle.lineTo(cx - 7f * d, cy + 5f * d);
        needle.lineTo(cx + 7f * d, cy + 5f * d);
        needle.close();
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xFFFF2ED9);
        canvas.drawPath(needle, paint);

        needle.reset();
        needle.moveTo(cx, cy + r * .55f);
        needle.lineTo(cx - 5f * d, cy - 4f * d);
        needle.lineTo(cx + 5f * d, cy - 4f * d);
        needle.close();
        paint.setColor(0xFF2EF0FF);
        canvas.drawPath(needle, paint);

        paint.setColor(0xFFF4F0FF);
        canvas.drawCircle(cx, cy, 9f * d, paint);
        paint.setColor(0xFF05040A);
        canvas.drawCircle(cx, cy, 4f * d, paint);

        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(android.graphics.Typeface.create("sans-serif-condensed",
                android.graphics.Typeface.BOLD));
        paint.setTextSize(28f * d);
        paint.setColor(0xFFF4F0FF);
        canvas.drawText(String.format(java.util.Locale.getDefault(), "%03d°",
                Math.round(heading) % 360), cx, cy + r * .17f, paint);
        paint.setTextSize(11f * d);
        paint.setColor(0xFF2EF0FF);
        canvas.drawText(direction(heading) + " · NORTE VERDADERO", cx, cy + r * .28f, paint);
        paint.setTextAlign(Paint.Align.LEFT);

        if (animating && isShown()) postInvalidateOnAnimation();
    }

    private void drawCardinal(Canvas canvas, String text, float degree, float cx, float cy,
                              float radius, int color) {
        double rad = Math.toRadians(degree - heading - 90f);
        float x = cx + (float) Math.cos(rad) * radius * .69f;
        float y = cy + (float) Math.sin(rad) * radius * .69f;
        float d = getResources().getDisplayMetrics().density;
        paint.setStyle(Paint.Style.FILL);
        paint.setTextAlign(Paint.Align.CENTER);
        paint.setTypeface(android.graphics.Typeface.create("sans-serif-condensed",
                android.graphics.Typeface.BOLD));
        paint.setTextSize(("N".equals(text) ? 18f : 13f) * d);
        paint.setColor(color);
        canvas.drawText(text, x, y + 5f * d, paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    public static String direction(float value) {
        String[] names = {"N", "NNE", "NE", "ENE", "E", "ESE", "SE", "SSE",
                "S", "SSO", "SO", "OSO", "O", "ONO", "NO", "NNO"};
        int index = Math.round(normalize(value) / 22.5f) % names.length;
        return names[index];
    }

    private static float shortest(float value) {
        return (value + 540f) % 360f - 180f;
    }

    private static float normalize(float value) {
        value %= 360f;
        return value < 0 ? value + 360f : value;
    }
}
