package mx.zarxus.akari;

import android.app.Notification;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.RemoteInput;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.service.notification.NotificationListenerService;
import android.service.notification.StatusBarNotification;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Bridge between Android's notification authority and AKARI's own notification UI.
 * Nothing is uploaded: active cards live only in this process.
 */
public class AkariNotificationService extends NotificationListenerService {
    public static final String ACTION_CHANGED = "mx.zarxus.akari.NOTIFICATIONS_CHANGED";
    public static final String EXTRA_EVENT = "event";
    public static final String EXTRA_KEY = "key";
    public static final String EXTRA_APP = "app";
    public static final String EXTRA_TITLE = "title";
    public static final String EXTRA_KIND = "kind";

    private static final Object LOCK = new Object();
    private static final Map<String, NotificationEntry> ACTIVE = new LinkedHashMap<>();
    private static volatile AkariNotificationService instance;
    private static volatile boolean connected;

    @Override
    public void onListenerConnected() {
        super.onListenerConnected();
        instance = this;
        connected = true;
        syncActive();
        publish("connected", null);
    }

    @Override
    public void onListenerDisconnected() {
        connected = false;
        publish("disconnected", null);
        super.onListenerDisconnected();
    }

    @Override
    public void onDestroy() {
        if (instance == this) instance = null;
        connected = false;
        super.onDestroy();
    }

    @Override
    public void onNotificationPosted(StatusBarNotification sbn) {
        if (sbn == null || getPackageName().equals(sbn.getPackageName())) return;
        NotificationEntry entry = NotificationEntry.from(this, sbn);
        synchronized (LOCK) {
            ACTIVE.put(entry.key, entry);
        }
        Prefs.rememberNotification(entry.appName, entry.kind(), entry.postedAt);
        publish("posted", entry);
    }

    @Override
    public void onNotificationRemoved(StatusBarNotification sbn) {
        if (sbn == null) return;
        NotificationEntry old;
        synchronized (LOCK) {
            old = ACTIVE.remove(sbn.getKey());
        }
        publish("removed", old);
    }

    private void syncActive() {
        try {
            StatusBarNotification[] now = getActiveNotifications();
            Map<String, NotificationEntry> fresh = new LinkedHashMap<>();
            if (now != null) {
                for (StatusBarNotification sbn : now) {
                    if (sbn == null || getPackageName().equals(sbn.getPackageName())) continue;
                    NotificationEntry entry = NotificationEntry.from(this, sbn);
                    fresh.put(entry.key, entry);
                }
            }
            synchronized (LOCK) {
                ACTIVE.clear();
                ACTIVE.putAll(fresh);
            }
        } catch (SecurityException ignored) {
            connected = false;
        }
    }

    private void publish(String event, NotificationEntry entry) {
        Intent intent = new Intent(ACTION_CHANGED).setPackage(getPackageName());
        intent.putExtra(EXTRA_EVENT, event);
        if (entry != null) {
            intent.putExtra(EXTRA_KEY, entry.key);
            intent.putExtra(EXTRA_APP, entry.appName);
            intent.putExtra(EXTRA_TITLE, entry.title);
            intent.putExtra(EXTRA_KIND, entry.kind());
        }
        sendBroadcast(intent);
    }

    public static boolean isConnected() {
        return connected && instance != null;
    }

    public static boolean hasAccess(Context context) {
        ComponentName component = new ComponentName(context, AkariNotificationService.class);
        if (Build.VERSION.SDK_INT >= 27) {
            NotificationManager nm = (NotificationManager) context.getSystemService(Context.NOTIFICATION_SERVICE);
            return nm != null && nm.isNotificationListenerAccessGranted(component);
        }
        String flat = Settings.Secure.getString(context.getContentResolver(), "enabled_notification_listeners");
        if (flat == null || flat.isEmpty()) return false;
        for (String item : flat.split(":")) {
            ComponentName enabled = ComponentName.unflattenFromString(item);
            if (component.equals(enabled)) return true;
        }
        return false;
    }

    public static void openAccessSettings(Context context) {
        try {
            Intent intent = new Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS);
            if (!(context instanceof android.app.Activity)) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception ignored) {
            QuickActions.appInfo(context, context.getPackageName());
        }
    }

    /**
     * Android 13+ may block sensitive settings for manually installed APKs.
     * This cannot be bypassed by an app, so AKARI gives the owner both explicit steps.
     */
    public static void showAccessGuide(final Activity activity) {
        if (hasAccess(activity)) {
            openAccessSettings(activity);
            return;
        }
        new AlertDialog.Builder(activity)
                .setTitle("Android bloqueó este permiso")
                .setMessage("Si instalaste AKARI desde un APK, Android/Xiaomi exige autorizar primero la configuración restringida.\n\n" +
                        "PASO 1 · Abre la ficha de AKARI, toca ⋮ arriba a la derecha y elige ‘Permitir configuración restringida’.\n\n" +
                        "PASO 2 · Vuelve aquí, pulsa de nuevo y entra a ‘Centro AKARI’ para activar el interruptor.")
                .setNegativeButton("AHORA NO", null)
                .setNeutralButton("PASO 2 · CONTINUAR", (dialog, which) -> openAccessSettings(activity))
                .setPositiveButton("PASO 1 · ABRIR FICHA", (dialog, which) -> openAppDetails(activity))
                .show();
    }

    public static void openAppDetails(Context context) {
        try {
            Intent intent = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                    Uri.parse("package:" + context.getPackageName()));
            if (!(context instanceof Activity)) intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            context.startActivity(intent);
        } catch (Exception ignored) {
            QuickActions.appInfo(context, context.getPackageName());
        }
    }

    public static void requestReconnect(Context context) {
        if (!hasAccess(context) || isConnected()) return;
        try {
            requestRebind(new ComponentName(context, AkariNotificationService.class));
        } catch (Exception ignored) {}
    }

    public static void refreshNow() {
        AkariNotificationService current = instance;
        if (current != null && connected) current.syncActive();
    }

    public static List<NotificationEntry> snapshot(Context context) {
        List<NotificationEntry> result;
        synchronized (LOCK) {
            result = new ArrayList<>(ACTIVE.values());
        }
        Collections.sort(result, new Comparator<NotificationEntry>() {
            @Override public int compare(NotificationEntry a, NotificationEntry b) {
                if (a.call != b.call) return a.call ? -1 : 1;
                return Long.compare(b.postedAt, a.postedAt);
            }
        });
        return result;
    }

    public static int activeCount(Context context) {
        int count = 0;
        for (NotificationEntry entry : snapshot(context)) {
            if (!entry.groupSummary) count++;
        }
        return count;
    }

    public static int unreadCount(Context context) {
        long seenAt = Prefs.notificationSeenAt();
        int count = 0;
        for (NotificationEntry entry : snapshot(context)) {
            if (!entry.groupSummary && entry.postedAt > seenAt) count++;
        }
        return count;
    }

    public static NotificationEntry find(String key) {
        if (key == null) return null;
        synchronized (LOCK) {
            return ACTIVE.get(key);
        }
    }

    public static boolean open(Context context, String key) {
        NotificationEntry entry = find(key);
        if (entry == null || entry.source == null) return false;
        PendingIntent content = entry.source.getNotification().contentIntent;
        if (content == null) return false;
        try {
            content.send();
            Prefs.setNotificationSeenAt(System.currentTimeMillis());
            return true;
        } catch (PendingIntent.CanceledException ignored) {
            return false;
        }
    }

    public static boolean performAction(Context context, String key, int actionIndex, String reply) {
        NotificationEntry entry = find(key);
        if (entry == null) return false;
        Notification.Action[] actions = entry.actions();
        if (actionIndex < 0 || actionIndex >= actions.length) return false;
        Notification.Action action = actions[actionIndex];
        if (action == null || action.actionIntent == null) return false;
        try {
            RemoteInput[] inputs = action.getRemoteInputs();
            if (reply != null && inputs != null && inputs.length > 0) {
                Bundle results = new Bundle();
                for (RemoteInput input : inputs) results.putCharSequence(input.getResultKey(), reply);
                Intent fillIn = new Intent();
                RemoteInput.addResultsToIntent(inputs, fillIn, results);
                action.actionIntent.send(context, 0, fillIn);
            } else {
                action.actionIntent.send();
            }
            Prefs.setNotificationSeenAt(System.currentTimeMillis());
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    public static boolean dismiss(String key) {
        AkariNotificationService current = instance;
        NotificationEntry entry = find(key);
        if (current == null || entry == null || !entry.clearable) return false;
        try {
            current.cancelNotification(key);
            synchronized (LOCK) { ACTIVE.remove(key); }
            current.publish("removed", entry);
            return true;
        } catch (Exception ignored) {
            return false;
        }
    }

    public static int dismissClearable() {
        List<NotificationEntry> copy;
        synchronized (LOCK) { copy = new ArrayList<>(ACTIVE.values()); }
        int cleared = 0;
        for (NotificationEntry entry : copy) {
            if (entry.clearable && dismiss(entry.key)) cleared++;
        }
        return cleared;
    }
}
