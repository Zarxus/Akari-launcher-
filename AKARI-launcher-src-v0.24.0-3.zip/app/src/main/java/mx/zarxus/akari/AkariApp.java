package mx.zarxus.akari;

import android.app.Application;

public class AkariApp extends Application {
    @Override
    public void onCreate() {
        super.onCreate();
        Prefs.init(this);
        UsageStore.init(this);
        SoundEngine.init(this);
        Voice.init(this);
    }
}
