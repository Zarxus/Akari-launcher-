package mx.zarxus.akari;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.view.animation.OvershootInterpolator;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class NewsActivity extends Activity {
    public static final String RSS = "https://news.google.com/rss?hl=es-419&gl=MX&ceid=MX:es-419";
    private static final String[] TOPICS = {"PORTADA", "MÉXICO", "CIENCIA", "TECNOLOGÍA"};
    private static final String[] FEEDS = {
            RSS,
            "https://news.google.com/rss/search?q=M%C3%A9xico&hl=es-419&gl=MX&ceid=MX:es-419",
            "https://news.google.com/rss/search?q=ciencia&hl=es-419&gl=MX&ceid=MX:es-419",
            "https://news.google.com/rss/search?q=tecnolog%C3%ADa%20OR%20inteligencia%20artificial&hl=es-419&gl=MX&ceid=MX:es-419"
    };

    private final Handler handler = new Handler(Looper.getMainLooper());
    private List<NewsItem> items = new ArrayList<>();
    private TextView status, focus, focusMeta, akariLine, refreshButton;
    private AkariAvatarView akari;
    private LinearLayout column, topicBar;
    private final List<View> cards = new ArrayList<>();
    private int topic, focused;
    private boolean loading;
    private int loadingTopic = -1;
    private int loadGeneration;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_news);
        Insets.attach(this);
        SoundEngine.init(this);
        Voice.init(this);
        status = findViewById(R.id.newsStatus);
        focus = findViewById(R.id.newsFocus);
        focusMeta = findViewById(R.id.newsFocusMeta);
        akariLine = findViewById(R.id.newsAkariLine);
        akari = findViewById(R.id.newsAkari);
        akari.setHeat(Prefs.heat());
        akari.setBond(Prefs.bond());
        column = findViewById(R.id.newsCol);
        topicBar = findViewById(R.id.newsTopics);
        topic = Prefs.newsTopic();

        findViewById(R.id.btnBack).setOnClickListener(v -> { SoundEngine.back(); finish(); });
        refreshButton = findViewById(R.id.btnRefresh);
        refreshButton.setOnClickListener(v -> load(true));
        findViewById(R.id.btnSpeakNews).setOnClickListener(v -> speakHeadlines());
        findViewById(R.id.newsPrev).setOnClickListener(v -> shift(-1));
        findViewById(R.id.newsNext).setOnClickListener(v -> shift(1));
        findViewById(R.id.newsAnalyze).setOnClickListener(v -> reactToFocused());
        findViewById(R.id.newsShare).setOnClickListener(v -> shareFocused());
        focus.setOnClickListener(v -> openFocused());
        focus.setOnLongClickListener(v -> { shareFocused(); return true; });
        akari.setListener(new AkariAvatarView.Listener() {
            @Override public void onBodyTouch(AkariAvatarView.Zone zone, float y, boolean hold) {
                if (hold) openFocused();
                else reactToFocused();
            }
            @Override public void onGesture(AkariAvatarView.Gesture gesture) {
                if (gesture == AkariAvatarView.Gesture.LEFT) shift(1);
                else if (gesture == AkariAvatarView.Gesture.RIGHT) shift(-1);
                else if (gesture == AkariAvatarView.Gesture.UP) speakHeadlines();
                else reactToFocused();
            }
            @Override public void onDoubleTap() { openFocused(); }
            @Override public void onScale(float scale) {
                akariLine.setText("Amplío el foco editorial contigo. Deslízame para recorrer titulares.");
            }
        });
        DockMotion.bind(findViewById(R.id.newsPrev));
        DockMotion.bind(findViewById(R.id.newsNext));
        DockMotion.bind(findViewById(R.id.newsAnalyze));
        DockMotion.bind(findViewById(R.id.newsShare));
        buildTopics();
        load(false);
    }

    private void buildTopics() {
        topicBar.removeAllViews();
        for (int i = 0; i < TOPICS.length; i++) {
            final int index = i;
            TextView chip = new TextView(this);
            chip.setText(TOPICS[i]);
            chip.setTextSize(9);
            chip.setGravity(17);
            chip.setTextColor(i == topic ? 0xFF05040A : 0xFFF4F0FF);
            chip.setBackgroundResource(i == topic ? R.drawable.bg_chip_selected : R.drawable.bg_chip);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, dp(40), 1f);
            lp.setMargins(dp(2), 0, dp(2), 0);
            chip.setLayoutParams(lp);
            chip.setOnClickListener(v -> {
                if (topic == index) return;
                topic = index;
                focused = 0;
                Prefs.setNewsTopic(index);
                SoundEngine.news();
                Haptics.tap(this);
                buildTopics();
                load(false);
            });
            DockMotion.bind(chip);
            topicBar.addView(chip);
        }
    }

    private void load(final boolean force) {
        final int requestedTopic = topic;
        if (loading && loadingTopic == requestedTopic) {
            akariLine.setText("El radar ya está sincronizando. No necesito duplicar la consulta.");
            return;
        }
        final int generation = ++loadGeneration;
        loadingTopic = requestedTopic;
        setLoading(true);
        status.setText("SINCRONIZANDO · " + TOPICS[requestedTopic]);
        akariLine.setText("Estoy rastreando titulares y fuentes. Dame un segundo.");
        final String cached = Prefs.newsCache(requestedTopic);
        if (!force && !cached.isEmpty() && System.currentTimeMillis() - Prefs.newsCacheAt(requestedTopic) < 15 * 60 * 1000L) {
            render(cached);
            status.setText("CACHÉ RECIENTE · " + TOPICS[requestedTopic] + " · "
                    + ageOf(Prefs.newsCacheAt(requestedTopic)));
            setLoading(false);
            return;
        }
        new Thread(() -> {
            try {
                final String xml = Net.get(FEEDS[requestedTopic]);
                Prefs.setNewsCache(requestedTopic, xml);
                handler.post(() -> {
                    if (generation != loadGeneration || topic != requestedTopic || isFinishing()) return;
                    render(xml);
                    status.setText("EN VIVO · GOOGLE NEWS MX · AHORA");
                    setLoading(false);
                });
            } catch (final Exception error) {
                handler.post(() -> {
                    if (generation != loadGeneration || topic != requestedTopic || isFinishing()) return;
                    if (!cached.isEmpty()) {
                        render(cached);
                        status.setText("SIN RED · CACHÉ LOCAL · " + ageOf(Prefs.newsCacheAt(requestedTopic)));
                    } else {
                        status.setText("NO SE PUDO CARGAR EL FEED");
                        akariLine.setText("No tengo red ahora. Conservé el panel listo para el próximo intento.");
                        Toast.makeText(this, "Comprueba tu conexión", Toast.LENGTH_SHORT).show();
                    }
                    setLoading(false);
                });
            }
        }, "akari-news").start();
    }

    private void render(String xml) {
        items = NewsItem.parseRss(xml);
        focused = Math.max(0, Math.min(focused, items.size() - 1));
        column.removeAllViews();
        cards.clear();
        if (items.isEmpty()) {
            focus.setText("Sin titulares parseados");
            focusMeta.setText("Pulsa REFRESCAR para reintentar");
            return;
        }
        updateFocus(false);
        int visibleItems = Math.min(30, items.size());
        for (int i = 0; i < visibleItems; i++) {
            final int index = i;
            NewsItem item = items.get(i);
            LinearLayout card = new LinearLayout(this);
            card.setOrientation(LinearLayout.VERTICAL);
            card.setPadding(dp(13), dp(10), dp(13), dp(10));
            card.setBackgroundResource(R.drawable.bg_panel);
            LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            cardLp.bottomMargin = dp(7);
            card.setLayoutParams(cardLp);
            TextView title = new TextView(this);
            title.setText((i + 1) + " · " + item.title);
            title.setTextColor(0xFFF4F0FF);
            title.setTextSize(14);
            TextView details = new TextView(this);
            details.setText(item.source.toUpperCase(Locale.ROOT) + "  ·  " + item.ageLabel());
            details.setTextColor(0xFF9B93B3);
            details.setTextSize(9);
            details.setPadding(0, dp(4), 0, 0);
            card.addView(title);
            card.addView(details);
            card.setContentDescription("Titular " + (i + 1) + ". " + item.title + ". Fuente "
                    + item.source + ". Toca para enfocar; mantén para compartir.");
            card.setOnClickListener(v -> {
                focused = index;
                updateFocus(true);
            });
            card.setOnLongClickListener(v -> {
                focused = index;
                updateFocus(false);
                shareFocused();
                return true;
            });
            DockMotion.bind(card);
            card.setAlpha(0f);
            card.setTranslationY(dp(14));
            card.animate().alpha(1f).translationY(0f).setStartDelay(Math.min(360, i * 22L)).setDuration(240).start();
            column.addView(card);
            cards.add(card);
        }
        akariLine.setText("Encontré " + items.size() + " titulares. Toca uno para enfocarlo; mantenlo para compartir.");
        updateFocus(false);
    }

    private void updateFocus(boolean animate) {
        if (items.isEmpty()) return;
        NewsItem item = items.get(focused);
        focus.setText(item.title);
        focusMeta.setText((focused + 1) + "/" + items.size() + "  ·  " + item.source + "  ·  " + item.ageLabel()
                + "\nTOCA: ABRIR  ·  ANALIZA O COMPARTE ABAJO");
        focus.setContentDescription("Titular enfocado. " + item.title + ". Fuente " + item.source
                + ". Toca para abrir el artículo.");
        for (int i = 0; i < cards.size(); i++) {
            View card = cards.get(i);
            card.setBackgroundResource(i == focused ? R.drawable.bg_notification : R.drawable.bg_panel);
            card.setAlpha(i == focused ? 1f : .82f);
        }
        if (animate) {
            SoundEngine.news();
            Haptics.press(this);
            focus.setScaleX(.94f);
            focus.setScaleY(.94f);
            focus.animate().scaleX(1f).scaleY(1f).setDuration(280)
                    .setInterpolator(new OvershootInterpolator(1.5f)).start();
            akari.impulse(focused % 2 == 0 ? 65f : -65f, -48f);
            akari.jiggle();
            akariLine.setText(shortReaction(item));
        }
    }

    private void shift(int delta) {
        if (items.isEmpty()) return;
        focused = (focused + delta + items.size()) % items.size();
        updateFocus(true);
    }

    private void reactToFocused() {
        if (items.isEmpty()) {
            akariLine.setText("Primero necesito titulares para comentarlos contigo.");
            return;
        }
        String reaction = detailedReaction(items.get(focused));
        akariLine.setText(reaction);
        SoundEngine.news();
        Haptics.success(this);
        Prefs.addBond(1);
        akari.setBond(Prefs.bond());
        akari.setHeat(Prefs.heat());
        Voice.speak(reaction);
        akari.animate().scaleX(.94f).scaleY(1.04f).setDuration(100)
                .withEndAction(() -> akari.animate().scaleX(1f).scaleY(1f).setDuration(220)
                        .setInterpolator(new OvershootInterpolator(2f)).start()).start();
    }

    private String shortReaction(NewsItem item) {
        String lower = item.title.toLowerCase(Locale.ROOT);
        if (lower.matches(".*\\bia\\b.*") || lower.contains("inteligencia artificial") || lower.contains("tecnolog"))
            return "Este sí me interesa: tecnología con consecuencias reales. Enfócalo y lo leemos.";
        if (lower.contains("méxico") || lower.contains("gobierno") || lower.contains("president"))
            return "Tema con impacto público. Conviene abrir la fuente antes de sacar conclusiones.";
        if (lower.contains("espacio") || lower.contains("ciencia") || lower.contains("salud"))
            return "Aquí quiero datos, no solo un titular llamativo. Veamos la fuente.";
        return "Lo puse en foco. Puedo leerte el titular, comentarlo o abrir su fuente.";
    }

    /** This is deliberately framed as a title reaction, not as a summary of an unopened article. */
    private String detailedReaction(NewsItem item) {
        String lower = item.title.toLowerCase(Locale.ROOT);
        String angle;
        if (lower.matches(".*(crisis|riesgo|alerta|guerra|ataque|hurac|sismo).*"))
            angle = "El lenguaje indica riesgo o urgencia; confirmaría fecha, lugar y fuente primaria.";
        else if (lower.matches(".*(estudio|ciencia|descubre|investig|salud).*"))
            angle = "Buscaría el estudio original, el tamaño de muestra y qué parte es todavía hipótesis.";
        else if (lower.matches(".*(\\bia\\b|inteligencia artificial|tecnolog|robot|chip).*"))
            angle = "Me fijaría en qué cambió de verdad, quién lo verificó y qué impacto tendrá para usuarios.";
        else if (lower.matches(".*(elecci|gobierno|ley|president|congreso).*"))
            angle = "Separaría el anuncio, la decisión legal y su efecto real; no siempre ocurren al mismo tiempo.";
        else angle = "Compararía esta versión con otra fuente y revisaría el dato central antes de compartirla.";
        return "Lectura del titular: " + angle + " Fuente enlazada: " + item.source + ".";
    }

    private void speakHeadlines() {
        if (items.isEmpty()) {
            Voice.speak("Todavía no hay titulares cargados.");
            return;
        }
        Voice.readNews(items.subList(0, Math.min(6, items.size())));
        akariLine.setText("Te leo los seis primeros. La música baja mientras hablo.");
    }

    private void openFocused() {
        if (items.isEmpty()) return;
        SoundEngine.open();
        Haptics.press(this);
        QuickActions.openLink(this, items.get(focused).link);
    }

    private void shareFocused() {
        if (items.isEmpty()) return;
        NewsItem item = items.get(focused);
        SoundEngine.confirm();
        Haptics.tap(this);
        Intent send = new Intent(Intent.ACTION_SEND);
        send.setType("text/plain");
        send.putExtra(Intent.EXTRA_TEXT, item.title + "\n" + item.link);
        try { startActivity(Intent.createChooser(send, "Compartir titular")); }
        catch (Exception ignored) { Toast.makeText(this, "No hay app para compartir", Toast.LENGTH_SHORT).show(); }
    }

    private void setLoading(boolean value) {
        loading = value;
        if (!value) loadingTopic = -1;
        if (refreshButton != null) {
            refreshButton.setEnabled(!value);
            refreshButton.setAlpha(value ? .45f : 1f);
            refreshButton.setText(value ? "CARGANDO…" : "REFRESCAR");
        }
    }

    private String ageOf(long at) {
        if (at <= 0L) return "SIN FECHA";
        long minutes = Math.max(0L, (System.currentTimeMillis() - at) / 60_000L);
        if (minutes < 1L) return "AHORA";
        if (minutes < 60L) return "HACE " + minutes + " MIN";
        long hours = minutes / 60L;
        if (hours < 24L) return "HACE " + hours + " H";
        return "HACE " + (hours / 24L) + " D";
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    @Override protected void onDestroy() {
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
