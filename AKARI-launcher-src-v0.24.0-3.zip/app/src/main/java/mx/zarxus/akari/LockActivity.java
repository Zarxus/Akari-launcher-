package mx.zarxus.akari;

import android.app.Activity;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class LockActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private TextView clock, date;
    private DevicePolicyManager dpm;
    private ComponentName admin;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            clock.setText(new SimpleDateFormat("HH:mm", Locale.getDefault()).format(new Date()));
            date.setText(new SimpleDateFormat("EEEE d MMMM", new Locale("es", "MX")).format(new Date()));
            h.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lock);

        Insets.attach(this);        Voice.init(this);
        clock = findViewById(R.id.lockClock);
        date = findViewById(R.id.lockDate);
        dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        admin = new ComponentName(this, AkariAdmin.class);
        if (Prefs.heat() >= 55) {
            ((ImageView) findViewById(R.id.lockArt)).setImageResource(R.drawable.cg_face);
        }
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { SoundEngine.back(); finish(); }
        });
        findViewById(R.id.btnLockAdmin).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { requestAdmin(); }
        });
        findViewById(R.id.btnLockNow).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { lockNow(); }
        });
        Voice.speak("Lock Link. Si me das permiso de administrador, apago la pantalla por ti.");
    }

    private void requestAdmin() {
        Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, admin);
        i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "AKARI usa esto solo para bloquear la pantalla cuando se lo pides.");
        startActivity(i);
    }

    private void lockNow() {
        if (dpm != null && dpm.isAdminActive(admin)) {
            Voice.speak("Te bloqueo. Vuelve pronto.");
            try { dpm.lockNow(); } catch (Exception e) {
                Toast.makeText(this, "No pude bloquear", Toast.LENGTH_SHORT).show();
            }
        } else {
            Voice.speak("Primero actívame el permiso de bloqueo.");
            requestAdmin();
        }
    }

    @Override protected void onResume() {
        super.onResume();
        h.removeCallbacks(tick);
        h.post(tick);
    }

    @Override protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
    }
}
