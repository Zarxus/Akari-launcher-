package mx.zarxus.akari;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public final class SpeechStyle {
    private static final Random R = new Random();
    private static final String[] NUM = {
            "cero", "una", "dos", "tres", "cuatro", "cinco", "seis", "siete", "ocho", "nueve",
            "diez", "once", "doce", "trece", "catorce", "quince", "dieciséis", "diecisiete",
            "dieciocho", "diecinueve", "veinte", "veintiuno", "veintidós", "veintitrés",
            "veinticuatro", "veinticinco", "veintiséis", "veintisiete", "veintiocho", "veintinueve",
            "treinta"
    };

    private SpeechStyle() {}

    public static String naturalTime() {
        Calendar c = Calendar.getInstance();
        int h24 = c.get(Calendar.HOUR_OF_DAY);
        int m = c.get(Calendar.MINUTE);
        int h = h24 % 12;
        if (h == 0) h = 12;
        String hora = (h == 1) ? "la una" : "las " + n(h);
        String min;
        if (m == 0) min = "en punto";
        else if (m == 15) min = "y cuarto";
        else if (m == 30) min = "y media";
        else if (m == 45) min = "menos cuarto";
        else min = "y " + n(m);
        String when;
        if (h24 < 5) when = "de la madrugada";
        else if (h24 < 12) when = "de la mañana";
        else if (h24 < 19) when = "de la tarde";
        else when = "de la noche";
        String extra = pick(
                " ¿Quieres que te abra algo?",
                " Dime si busco algo o te paso una app.",
                " Sigo aquí."
        );
        return "Son " + hora + " " + min + " " + when + "." + extra;
    }

    public static String spoken(String raw) {
        if (raw == null) return "";
        String t = raw;
        t = t.replace("·", ", ").replace("|", ", ").replace("/", " ");
        t = t.replaceAll("[✦◉☀⛅☁🌫🌧❄⛈⚡🔋🔊◀▲↻✕*]", "");
        t = t.replace("%", " por ciento");
        t = t.replace("°C", " grados");
        t = t.replace("°", " grados");
        t = t.replace("OK", "okey");
        t = t.replace("HUD", "interfaz");
        t = t.replace("NEWS", "noticias");
        t = t.replace("MIC", "micrófono");
        t = t.replaceAll("\\s+", " ").trim();
        // pausas naturales
        t = t.replace("...", ".");
        t = t.replace("…", ".");
        return t;
    }

    public static List<String> chunks(String text) {
        String t = spoken(text);
        String[] parts = t.split("(?<=[.!?])\\s+");
        List<String> out = new ArrayList<>();
        for (String p : parts) {
            p = p.trim();
            if (p.isEmpty()) continue;
            if (p.length() > 140) {
                int cut = p.lastIndexOf(',', 140);
                if (cut < 40) cut = 120;
                out.add(p.substring(0, Math.min(cut, p.length())).trim());
                if (cut < p.length()) out.add(p.substring(cut).replaceFirst("^,\\s*", "").trim());
            } else {
                out.add(p);
            }
        }
        if (out.isEmpty() && t.length() > 0) out.add(t);
        return out;
    }

    public static String ssml(String sentence, float heat) {
        float rate = 88 + (1f - heat) * 8f; // 88-96%
        float pitch = 8 + heat * 10f;       // +8 to +18%
        // pequeña variación para que no suene clip repetido
        rate += R.nextInt(5) - 2;
        pitch += R.nextInt(5) - 2;
        String safe = sentence
                .replace("&", " y ")
                .replace("<", " ")
                .replace(">", " ");
        return "<speak><prosody rate=\"" + (int) rate + "%\" pitch=\"+" + (int) pitch + "%\">"
                + safe + "<break time=\"180ms\"/></prosody></speak>";
    }

    public static boolean isQuestion(String s) {
        if (s == null) return false;
        String x = s.toLowerCase(Locale.ROOT).trim();
        if (x.endsWith("?")) return true;
        String[] starts = {
                "qué ", "que ", "quién ", "quien ", "cómo ", "como ", "por qué", "porque ",
                "cuándo ", "cuando ", "dónde ", "donde ", "cuál ", "cual ", "cuánto", "cuanto ",
                "busca ", "búscame", "buscame", "google ", "explícame", "explicame",
                "dime qué", "dime que", "quién es", "qué es", "que es", "define ",
                "traduce ", "calcúla", "calcula "
        };
        for (String k : starts) if (x.startsWith(k) || x.contains(" " + k.trim() + " ")) {
            // exclude pure time
            if (x.contains("hora") && x.length() < 28) return false;
            return true;
        }
        if (x.startsWith("busca") || x.startsWith("googlea") || x.startsWith("investiga")) return true;
        return false;
    }

    public static String n(int v) {
        if (v < 0) v = 0;
        if (v <= 30) return NUM[v];
        if (v < 40) return "treinta y " + NUM[v - 30];
        if (v == 40) return "cuarenta";
        if (v < 50) return "cuarenta y " + NUM[v - 40];
        if (v == 50) return "cincuenta";
        if (v < 60) return "cincuenta y " + NUM[v - 50];
        return String.valueOf(v);
    }

    private static String pick(String... s) {
        return s[R.nextInt(s.length)];
    }
}
