package mx.zarxus.akari;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.GridLayout;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.List;
import java.util.Random;

public class ChessActivity extends Activity {
    private final ChessBoard board = new ChessBoard();
    private final TextView[] cells = new TextView[64];
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final BodyPhysics body = new BodyPhysics();
    private final Random rng = new Random();
    private TextView line, status, meta, levelButton;
    private ImageView art;
    private View hero;
    private int selected = -1, hintFrom = -1, hintTo = -1;
    private int ply, generation;
    private boolean over, dragging, aiThinking;
    private long lastTick;

    private final Runnable frame = new Runnable() {
        @Override public void run() {
            long now = System.nanoTime();
            float dt = lastTick == 0 ? .016f : (now - lastTick) / 1_000_000_000f;
            lastTick = now;
            if (dt > .05f) dt = .05f;
            if (!dragging) body.y += (float) Math.sin(now / 380_000_000.0) * .18f;
            body.tick(dt);
            handler.postDelayed(this, Prefs.physics() ? 16 : 80);
        }
    };

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_chess);
        Insets.attach(this);
        Voice.init(this);
        SoundEngine.init(this);
        line = findViewById(R.id.chessLine);
        status = findViewById(R.id.chessStatus);
        meta = findViewById(R.id.chessMeta);
        levelButton = findViewById(R.id.chessLevel);
        art = findViewById(R.id.chessArt);
        hero = findViewById(R.id.chessHero);
        bindHero();
        findViewById(R.id.btnBack).setOnClickListener(v -> { SoundEngine.back(); finish(); });
        findViewById(R.id.chessReset).setOnClickListener(v -> resetGame());
        findViewById(R.id.chessHint).setOnClickListener(v -> requestHint());
        findViewById(R.id.chessUndo).setOnClickListener(v -> undoTurn());
        levelButton.setOnClickListener(v -> cycleLevel());
        DockMotion.bind(findViewById(R.id.chessHint));
        DockMotion.bind(findViewById(R.id.chessUndo));
        DockMotion.bind(levelButton);
        buildGrid();
        refreshLevel();
        paint();
        pose();
        say("Mate Link listo. Tú llevas blancas; yo ya estoy leyendo el tablero.");
    }

    private void bindHero() {
        if (hero == null) return;
        body.attach(hero);
        hero.setOnTouchListener(new View.OnTouchListener() {
            float x0;
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dragging = true;
                        x0 = e.getRawX();
                        body.grab();
                        body.squash();
                        SoundEngine.spring();
                        Haptics.press(ChessActivity.this);
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        body.dragBy((e.getRawX() - x0) * .03f, 0);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        dragging = false;
                        body.release((e.getRawX() - x0) * .2f, -24);
                        Prefs.addHeat(1);
                        teaseTouch();
                        return true;
                    default: return false;
                }
            }
        });
    }

    private void buildGrid() {
        GridLayout grid = findViewById(R.id.chessGrid);
        grid.removeAllViews();
        for (int i = 0; i < 64; i++) {
            final int index = i;
            TextView cell = new TextView(this);
            cell.setGravity(Gravity.CENTER);
            cell.setTextSize(22);
            cell.setTextColor(0xFFF4F0FF);
            GridLayout.LayoutParams lp = new GridLayout.LayoutParams();
            lp.width = 0;
            lp.height = 0;
            lp.columnSpec = GridLayout.spec(i % 8, 1f);
            lp.rowSpec = GridLayout.spec(i / 8, 1f);
            lp.setMargins(1, 1, 1, 1);
            cell.setOnClickListener(v -> tap(index));
            cells[i] = cell;
            grid.addView(cell, lp);
        }
    }

    private void tap(int index) {
        if (over || aiThinking || !board.white) return;
        hintFrom = hintTo = -1;
        if (selected < 0) {
            char piece = board.at(index);
            if (piece != '.' && ChessBoard.isWhite(piece)) {
                selected = index;
                SoundEngine.click();
                Haptics.tap(this);
                bounce(cells[index]);
                say(onPick(piece));
                paint();
            } else {
                SoundEngine.back();
                say("Esa pieza no responde a tu lado. Busca una blanca.");
            }
            return;
        }
        if (index == selected) {
            selected = -1;
            paint();
            return;
        }
        int from = selected;
        char captured = board.play(from, index);
        if (captured == 0) {
            char piece = board.at(index);
            selected = piece != '.' && ChessBoard.isWhite(piece) ? index : -1;
            SoundEngine.back();
            paint();
            return;
        }
        ply++;
        selected = -1;
        if (captured == '.') {
            SoundEngine.move();
            Haptics.press(this);
        } else {
            SoundEngine.capture();
            Haptics.capture(this);
        }
        bounce(cells[index]);
        body.impulse((index - from) * 1.4f, -36);
        onCapture(captured, true);
        paint();
        if (!finishIfOver()) startAi();
    }

    private void startAi() {
        aiThinking = true;
        final int token = generation;
        final int level = Prefs.chessLevel();
        final ChessBoard analysis = board.snapshot();
        status.setText("AKARI calcula · nivel " + level + "…");
        say(thinkLine());
        new Thread(() -> {
            final int[] move = analysis.bestMove(false, level);
            handler.post(() -> {
                if (token != generation || over || board.white) return;
                aiThinking = false;
                if (move == null) {
                    finishIfOver();
                    return;
                }
                char captured = board.play(move[0], move[1]);
                ply++;
                if (captured == '.') {
                    SoundEngine.move();
                    Haptics.press(this);
                } else {
                    SoundEngine.capture();
                    Haptics.capture(this);
                }
                bounce(cells[move[1]]);
                body.jiggle();
                onCapture(captured, false);
                paint();
                finishIfOver();
            });
        }, "akari-chess-ai").start();
    }

    private void requestHint() {
        if (over) {
            say("La partida terminó. Reiníciala y volveré a guiarte.");
            return;
        }
        if (aiThinking || !board.white) {
            say("Espera mi jugada; después te marco una ruta.");
            return;
        }
        aiThinking = true;
        final int token = generation;
        final ChessBoard analysis = board.snapshot();
        status.setText("Escaneando una pista…");
        new Thread(() -> {
            final int[] move = analysis.bestMove(true, Math.min(3, Prefs.chessLevel() + 1));
            handler.post(() -> {
                if (token != generation || over || !board.white) return;
                aiThinking = false;
                if (move == null) return;
                hintFrom = move[0];
                hintTo = move[1];
                SoundEngine.news();
                Haptics.success(this);
                say("Mi lectura: " + ChessBoard.moveLabel(move) + ". La marco en violeta y cian.");
                status.setText("PISTA · " + ChessBoard.moveLabel(move));
                paint();
            });
        }, "akari-chess-hint").start();
    }

    private void undoTurn() {
        generation++;
        aiThinking = false;
        selected = hintFrom = hintTo = -1;
        boolean changed = false;
        if (!board.white) {
            changed = board.undo();
        } else if (board.historySize() > 0) {
            changed = board.undo();
            if (!board.white && board.historySize() > 0) board.undo();
        }
        if (!changed) {
            say("Todavía no hay una jugada que deshacer.");
            return;
        }
        over = false;
        ply = Math.max(0, ply - 2);
        SoundEngine.back();
        Haptics.warning(this);
        say("Rebobiné el turno completo. Prueba otra línea.");
        paint();
        pose();
    }

    private void cycleLevel() {
        int level = Prefs.chessLevel() % 3 + 1;
        Prefs.setChessLevel(level);
        refreshLevel();
        SoundEngine.click();
        Haptics.tap(this);
        say(level == 1 ? "Nivel suave: te dejaré respirar." : level == 2
                ? "Nivel táctico: ya no regalaré piezas." : "Nivel neón: voy a mirar tres jugadas hacia delante.");
    }

    private void refreshLevel() {
        int level = Prefs.chessLevel();
        levelButton.setText(level == 1 ? "SUAVE" : level == 2 ? "TÁCTICA" : "NEÓN");
    }

    private void resetGame() {
        generation++;
        board.reset();
        selected = hintFrom = hintTo = -1;
        over = aiThinking = false;
        ply = 0;
        paint();
        pose();
        SoundEngine.unlock();
        Haptics.success(this);
        say(pick("Tablero limpio. Esta vez mira dos jugadas más lejos.",
                "Reinicio completo. Vuelve a abrirme una línea.",
                "Otra partida. Yo ya estoy preparada."));
    }

    private String onPick(char piece) {
        switch (piece) {
            case 'P': return pick("Ese peón puede ganar espacio. Empújalo con intención.", "Peón elegido. Pequeño, pero peligroso si llega al fondo.");
            case 'N': return pick("El caballo entra por ángulos que nadie espera.", "Caballo listo. Busca una horquilla.");
            case 'B': return pick("Abre la diagonal y el alfil te recompensará.", "Ese alfil quiere una línea larga.");
            case 'R': return pick("Torre activa. Una columna abierta sería deliciosa.", "La torre prefiere caminos directos.");
            case 'Q': return pick("Tu reina concentra demasiado poder; cuídala.", "Reina seleccionada. Haz que la jugada merezca su presencia.");
            case 'K': return pick("Tu rey también puede pelear cuando el centro se vacía.", "Rey en tus manos. No lo expongas demasiado pronto.");
            default: return "Esa.";
        }
    }

    private String thinkLine() {
        return pick("Déjame leer las diagonales… ya veo una tensión.",
                "Estoy midiendo material, centro y seguridad del rey.",
                "Un instante. Quiero que mi respuesta tenga filo.",
                "No mires solo mis ojos; vigila también tu dama.");
    }

    private void onCapture(char captured, boolean byUser) {
        if (captured == 0 || captured == '.') {
            if (byUser && ply < 4) say(pick("Buena salida. Ahora pelea por el centro.", "Apertura limpia; no rompas el ritmo."));
            return;
        }
        char kind = Character.toLowerCase(captured);
        if (byUser) {
            Prefs.addHeat(kind == 'q' ? 8 : kind == 'r' ? 5 : 3);
            Prefs.addBond(1);
            if (kind == 'q') say("Mi reina cayó. Eso sí consiguió alterarme.");
            else if (kind == 'r') say("Me quitaste una torre; la posición empieza a arder.");
            else say("Captura limpia. Sentí el golpe en todo el tablero.");
        } else {
            if (kind == 'q') say("Tu reina es mía. Ahora tendrás que ser creativo.");
            else if (kind == 'r') say("Tomé tu torre. No apartes la mirada.");
            else say("Una pieza menos para ti. Mi ventaja acaba de moverse.");
        }
        pose();
    }

    private boolean finishIfOver() {
        boolean side = board.white;
        if (board.hasMove(side)) {
            if (board.inCheck(side)) {
                status.setText(side ? "JAQUE A TI" : "JAQUE A AKARI");
                SoundEngine.heat();
                Haptics.warning(this);
                body.impulse(0, -50);
                say(side ? "Jaque. Tu rey necesita una salida inmediata."
                        : "Jaque a mí… buena presión. Ahora demuestra que puedes cerrarla.");
            } else {
                status.setText(side ? "TU TURNO" : "TURNO DE AKARI");
            }
            updateMeta();
            return false;
        }
        over = true;
        aiThinking = false;
        if (board.inCheck(side)) {
            if (side) {
                SoundEngine.scene();
                status.setText("MATE · GANA AKARI");
                art.setImageResource(R.drawable.cg_jacket);
                say("Jaque mate. Esta ronda es mía; puedes pedirme revancha.");
            } else {
                SoundEngine.unlock();
                Prefs.addHeat(14);
                Prefs.addBond(4);
                status.setText("MATE · GANAS TÚ");
                art.setImageResource(R.drawable.cg_face);
                say("Me diste mate. La recompensa es verme admitir que me superaste.");
            }
        } else {
            status.setText("TABLAS");
            say("Tablas. Equilibrio perfecto… aunque yo todavía quiero otra ronda.");
        }
        Haptics.success(this);
        body.jiggle();
        updateMeta();
        return true;
    }

    private void teaseTouch() {
        if (over) {
            say("La partida terminó, pero mi revancha sigue disponible.");
            return;
        }
        int score = board.eval();
        if (score >= 15) say("Vas por delante y aún vienes a provocarme. Ambicioso.");
        else if (score <= -15) say("Tu posición está apretada. Respira: aún puedes crear contrajuego.");
        else say("Estamos cerca. Una sola imprecisión cambiará el pulso.");
        pose();
    }

    private void pose() {
        int score = board.eval();
        if (over || score >= 18 || Prefs.heat() >= 70) art.setImageResource(R.drawable.cg_face);
        else if (score >= 5 || Prefs.heat() >= 40) art.setImageResource(R.drawable.cg_jacket);
        else art.setImageResource(R.drawable.akari_portrait);
    }

    private void bounce(View view) {
        if (view == null) return;
        view.animate().scaleX(.82f).scaleY(.82f).rotation(rng.nextBoolean() ? 2f : -2f).setDuration(70)
                .withEndAction(() -> view.animate().scaleX(1f).scaleY(1f).rotation(0f).setDuration(160)
                        .setInterpolator(new DecelerateInterpolator()).start()).start();
    }

    private void paint() {
        List<Integer> marks = selected >= 0 ? board.movesFrom(selected) : null;
        for (int i = 0; i < 64; i++) {
            TextView cell = cells[i];
            boolean dark = ((i / 8) + (i % 8)) % 2 == 1;
            int bg = dark ? 0xFF25102E : 0xFF32203F;
            if (i == board.lastFrom) bg = 0xFF554027;
            if (i == board.lastTo) bg = 0xFF76501F;
            if (i == selected || i == hintFrom) bg = 0xFF7B267E;
            if (marks != null && marks.contains(i)) bg = board.at(i) == '.' ? 0xFF17646B : 0xFF8B2D48;
            if (i == hintTo) bg = 0xFF148A99;
            cell.setBackgroundColor(bg);
            cell.setText(ChessBoard.glyph(board.at(i)));
        }
        updateMeta();
    }

    private void updateMeta() {
        if (meta == null) return;
        String last = board.lastTo < 0 ? "sin movimientos" : ChessBoard.square(board.lastFrom) + "→" + ChessBoard.square(board.lastTo);
        meta.setText("JUGADA " + ply + "  ·  " + board.materialLabel() + "  ·  " + last);
    }

    private void say(String text) {
        line.setText(text);
        Voice.speak(text);
        Prefs.setLastSay(text);
    }

    private String pick(String... lines) { return lines[rng.nextInt(lines.length)]; }

    @Override protected void onResume() {
        super.onResume();
        lastTick = 0;
        handler.removeCallbacks(frame);
        handler.post(frame);
    }

    @Override protected void onPause() {
        super.onPause();
        handler.removeCallbacks(frame);
    }

    @Override protected void onDestroy() {
        generation++;
        handler.removeCallbacksAndMessages(null);
        super.onDestroy();
    }
}
