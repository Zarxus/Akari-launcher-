package mx.zarxus.akari;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class GalleryActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_gallery);

        Insets.attach(this);        SoundEngine.init(this);
        SoundEngine.open();

        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.back();
                finish();
            }
        });

        LinearLayout col = findViewById(R.id.galleryCol);
        int rowIndex = 0;
        for (final SceneCatalog.Scene s : SceneCatalog.all()) {
            LinearLayout row = new LinearLayout(this);
            row.setOrientation(LinearLayout.HORIZONTAL);
            row.setPadding(dp(10), dp(10), dp(10), dp(10));
            row.setBackgroundResource(R.drawable.bg_panel);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT,
                    LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.bottomMargin = dp(10);
            row.setLayoutParams(lp);

            ImageView iv = new ImageView(this);
            LinearLayout.LayoutParams ip = new LinearLayout.LayoutParams(dp(72), dp(96));
            iv.setLayoutParams(ip);
            iv.setScaleType(ImageView.ScaleType.CENTER_CROP);
            boolean open = Prefs.unlocked(s.id) || Prefs.bond() >= s.needBond;
            iv.setImageResource(open ? s.thumb : s.thumb);
            iv.setAlpha(open ? 1f : 0.28f);

            LinearLayout txt = new LinearLayout(this);
            txt.setOrientation(LinearLayout.VERTICAL);
            txt.setPadding(dp(12), dp(4), 0, 0);
            txt.setGravity(Gravity.CENTER_VERTICAL);

            TextView t = new TextView(this);
            t.setText(s.title);
            t.setTextColor(0xFFF4F0FF);
            t.setTextSize(16);

            TextView sub = new TextView(this);
            sub.setText(open
                    ? (Prefs.unlocked(s.id) ? "CG DESBLOQUEADO · tocar para jugar" : "DISPONIBLE · bond " + Prefs.bond())
                    : "BLOQUEADO · bond " + s.needBond + " requerido");
            sub.setTextColor(open ? 0xFF2EF0FF : 0xFF9B93B3);
            sub.setTextSize(12);

            txt.addView(t);
            txt.addView(sub);
            row.addView(iv);
            row.addView(txt);

            final boolean can = Prefs.bond() >= s.needBond;
            row.setContentDescription(s.title + (can
                    ? ". Disponible. Toca para abrir la escena."
                    : ". Bloqueada. Requiere bond " + s.needBond + "."));
            row.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (!can) {
                        SoundEngine.back();
                        Toast.makeText(GalleryActivity.this, "Sube el bond tocándola o con escenas previas", Toast.LENGTH_SHORT).show();
                        return;
                    }
                    SoundEngine.click();
                    Intent i = new Intent(GalleryActivity.this, SceneActivity.class);
                    i.putExtra(SceneActivity.EXTRA_ID, s.id);
                    startActivity(i);
                }
            });
            DockMotion.bind(row);
            row.setAlpha(0f);
            row.setTranslationY(dp(20));
            col.addView(row);
            row.animate().alpha(1f).translationY(0f).setStartDelay(rowIndex++ * 55L)
                    .setDuration(260L).start();
        }
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
