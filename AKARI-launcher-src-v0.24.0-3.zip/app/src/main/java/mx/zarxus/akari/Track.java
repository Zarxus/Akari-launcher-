package mx.zarxus.akari;

import android.net.Uri;

public class Track {
    public final long id;
    public final String title;
    public final String artist;
    public final long duration;
    public final Uri uri;

    public Track(long id, String title, String artist, long duration, Uri uri) {
        this.id = id;
        this.title = title == null ? "Sin título" : title;
        this.artist = artist == null || artist.trim().isEmpty() ? "Desconocido" : artist;
        this.duration = duration;
        this.uri = uri;
    }

    public String line() {
        return title + " — " + artist;
    }
}
