package mx.zarxus.akari;

public final class Identity {
    private Identity() {}

    public static String rank() {
        int b = Prefs.bond();
        if (b >= 80) return "FULL LINK";
        if (b >= 55) return "COREBOUND";
        if (b >= 30) return "COMPAÑERA";
        if (b >= 12) return "ENLACE ESTABLE";
        return "BOOT LINK";
    }

    public static String title() {
        int h = Prefs.heat();
        if (h >= 80) return "AKARI · OVERHEAT";
        if (h >= 50) return "AKARI · FLUSHED";
        return "AKARI · NEXUS";
    }

    public static String dossier() {
        return title() + "  ·  " + rank()
                + "\nBond " + Prefs.bond() + "  ·  Heat " + Prefs.heat()
                + "  ·  Toques " + Prefs.touches()
                + "\nCiudad " + Prefs.city()
                + "\n«No soy un widget. Soy la casa.»";
    }

    public static String pickLine(String kind) {
        if ("chat".equals(kind)) return "Te paso lo que habla con humanos. Yo hablo contigo.";
        if ("media".equals(kind)) return "Video y música. Póntelo de fondo y mírame a mí.";
        if ("foto".equals(kind)) return "Cámara y galería. Si vas a disparar, encuádrame.";
        if ("web".equals(kind)) return "Navegadores. Mejor el portal: no te me escapas.";
        if ("tools".equals(kind)) return "Herramientas. Yo también soy una, pero más tibia.";
        if ("games".equals(kind)) return "Juegos. Compites con ellos o conmigo.";
        if ("ocultas".equals(kind)) return "Nada queda perdido. Desde aquí puedes devolver cualquier app al Atelier.";
        if ("recientes".equals(kind)) return "Lo que más abres. Te conozco los hábitos.";
        return "Elige. Yo filtro, tú tocas. O dime el nombre.";
    }
}
