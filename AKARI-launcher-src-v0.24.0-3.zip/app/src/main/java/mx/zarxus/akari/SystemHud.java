package mx.zarxus.akari;

import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Build;
import android.text.format.DateFormat;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public final class SystemHud {
    private SystemHud() {}

    public static String time(boolean seconds) {
        // Context-free fallback for utility callers. The HOME overload respects 12/24h settings.
        return new SimpleDateFormat(seconds ? "HH:mm:ss" : "HH:mm", Locale.getDefault()).format(new Date());
    }

    public static String time(Context ctx, boolean seconds) {
        boolean h24 = DateFormat.is24HourFormat(ctx);
        String pattern;
        if (h24) pattern = seconds ? "HH:mm:ss" : "HH:mm";
        else pattern = seconds ? "h:mm:ss a" : "h:mm a";
        return new SimpleDateFormat(pattern, Locale.getDefault()).format(new Date());
    }

    public static String dateLine() {
        String date = new SimpleDateFormat("EEEE d MMM", Locale.getDefault()).format(new Date());
        String tz = TimeZone.getDefault().getDisplayName(false, TimeZone.SHORT, Locale.getDefault());
        return date.toUpperCase(Locale.getDefault()) + "  ·  " + tz;
    }

    public static String battery(Context ctx) {
        try {
            Intent bat = ctx.registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
            if (bat == null) return "—%";
            int level = bat.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
            int scale = bat.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
            int pct = scale > 0 ? Math.round(level * 100f / scale) : -1;
            int status = bat.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
            boolean chg = status == BatteryManager.BATTERY_STATUS_CHARGING
                    || status == BatteryManager.BATTERY_STATUS_FULL;
            return (chg ? "⚡" : "🔋") + " " + pct + "%";
        } catch (Exception e) {
            return "🔋 —";
        }
    }

    public static void expandNotifications(Context ctx) {
        try {
            Intent center = new Intent(ctx, NotificationCenterActivity.class);
            if (!(ctx instanceof android.app.Activity)) center.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            ctx.startActivity(center);
        } catch (Exception ignored) {}
    }

    public static int sdk() {
        return Build.VERSION.SDK_INT;
    }
}
