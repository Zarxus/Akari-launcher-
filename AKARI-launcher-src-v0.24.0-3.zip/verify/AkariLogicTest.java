package mx.zarxus.akari;

import java.util.Arrays;
import java.util.Calendar;

/** Host-side smoke tests for the pure logic used by the APK. */
public final class AkariLogicTest {
    public static void main(String[] args) {
        calculator();
        chess();
        alarmCalendar();
        solarCycle();
        compassDirections();
        searchRanking();
        layerMotion();
        System.out.println("AKARI logic checks: OK");
    }

    private static void calculator() {
        close(14, CalcActivity.Parser.solve("2+3×4"));
        close(25, CalcActivity.Parser.solve("(2+3)^2"));
        close(9, CalcActivity.Parser.solve("√(81)"));
        close(20, CalcActivity.Parser.solve("200×10%"));
        close(-7, CalcActivity.Parser.solve("-(3+4)"));
        boolean rejected = false;
        try { CalcActivity.Parser.solve("1÷0"); } catch (ArithmeticException expected) { rejected = true; }
        check(rejected, "division by zero must fail");
    }

    private static void chess() {
        ChessBoard board = new ChessBoard();
        check(board.movesFrom(52).contains(36), "e2-e4 should be legal");
        char[] before = Arrays.copyOf(board.s, 64);
        int[] hint = board.bestMove(true, 2);
        check(hint != null && Arrays.equals(before, board.s), "hint must not mutate board");
        check(board.play(52, 36) == '.', "e2-e4 failed");
        check(board.aiMove(1) != 0 && board.white, "AI should return the turn");
        check(board.undo() && board.undo() && board.white && Arrays.equals(before, board.s), "full undo failed");

        ChessBoard mate = new ChessBoard();
        check(mate.play(53, 45) != 0, "f2-f3");
        check(mate.play(12, 28) != 0, "e7-e5");
        check(mate.play(54, 38) != 0, "g2-g4");
        check(mate.play(3, 39) != 0, "d8-h4");
        check(mate.inCheck(true) && !mate.hasMove(true), "fool's mate should be detected");
    }

    private static void alarmCalendar() {
        Calendar monday = Calendar.getInstance();
        monday.set(2026, Calendar.SEPTEMBER, 14, 6, 30, 0);
        monday.set(Calendar.MILLISECOND, 0);
        int mondayOnly = 1 << (Calendar.MONDAY - 1);
        long next = AlarmScheduler.next(monday.getTimeInMillis(), 7, 0, mondayOnly);
        Calendar result = Calendar.getInstance();
        result.setTimeInMillis(next);
        check(result.get(Calendar.DAY_OF_WEEK) == Calendar.MONDAY
                && result.get(Calendar.HOUR_OF_DAY) == 7
                && result.get(Calendar.MINUTE) == 0, "alarm day/time mismatch");
    }

    private static void solarCycle() {
        Weather weather = new Weather();
        long now = System.currentTimeMillis();
        weather.sunriseAt = now - 60L * 60L * 1000L;
        weather.sunsetAt = now + 60L * 60L * 1000L;
        weather.uv = 7.2;
        weather.timezone = "UTC";
        check(weather.hasSolar(), "solar response should be usable");
        check(weather.sunIsUp(), "sun should be above the test horizon");
        check(weather.sunProgress() > .45f && weather.sunProgress() < .55f,
                "solar arc should be near its midpoint");
        check(weather.uvLabel().contains("ALTO"), "UV risk band mismatch");
        check(weather.solarNarration().contains("Amanecer"), "solar narration missing");
    }

    private static void compassDirections() {
        check("N".equals(CompassView.direction(0f)), "north direction mismatch");
        check("E".equals(CompassView.direction(90f)), "east direction mismatch");
        check("SO".equals(CompassView.direction(225f)), "southwest direction mismatch");
    }

    private static void searchRanking() {
        check("brujula".equals(AppRepository.normalized("Brújula")),
                "accent normalization mismatch");
        java.util.List<AppInfo> apps = Arrays.asList(
                new AppInfo("Calculadora", null, null, "mx.calc"),
                new AppInfo("Brújula Pro", null, null, "mx.compass"),
                new AppInfo("WhatsApp", null, null, "com.whatsapp")
        );
        check(AppRepository.filter(apps, "brujula").get(0).label.equals("Brújula Pro"),
                "accent-insensitive app search failed");
        check(AppRepository.filter(apps, "whtsp").get(0).label.equals("WhatsApp"),
                "fuzzy subsequence search failed");
    }

    private static void layerMotion() {
        close(.5, LayerMotion.progress(1, 0f, 500f, 0f, 1000f, 2000f));
        close(.5, LayerMotion.progress(2, 0f, -500f, 0f, 1000f, 2000f));
        close(.5, LayerMotion.progress(3, 0f, 0f, 1000f, 1000f, 2000f));
        close(.5, LayerMotion.progress(4, 0f, 0f, -1000f, 1000f, 2000f));
        close(.2, LayerMotion.progress(1, 1f, -800f, 0f, 1000f, 2000f));
        check(!LayerMotion.shouldOpen(.40f, 0f, 1000f), "short layer drag must return");
        check(LayerMotion.shouldOpen(.34f, 900f, 1000f), "fast layer fling must open");
        close(.58, LayerMotion.settleTarget(.52f, true, 120f, 1000f, true));
        close(1, LayerMotion.settleTarget(.52f, true, 900f, 1000f, true));
        close(0, LayerMotion.settleTarget(.20f, false, 0f, 1000f, true));
    }

    private static void close(double expected, double actual) {
        check(Math.abs(expected - actual) < 0.0000001, "expected " + expected + ", got " + actual);
    }

    private static void check(boolean condition, String message) {
        if (!condition) throw new AssertionError(message);
    }
}
