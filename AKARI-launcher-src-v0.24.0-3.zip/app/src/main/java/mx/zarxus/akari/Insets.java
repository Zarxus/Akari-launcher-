package mx.zarxus.akari;

import android.app.Activity;
import android.os.Build;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;

/** Keeps AKARI chrome above the 3-button / gesture nav bar. */
public final class Insets {
    private Insets() {}

    public static void attach(Activity a) {
        attach(a, a.findViewById(android.R.id.content));
    }

    public static void attach(Activity a, final View target) {
        if (a == null || target == null) return;
        final int baseLeft = target.getPaddingLeft();
        final int baseTop = target.getPaddingTop();
        final int baseRight = target.getPaddingRight();
        final int baseBottom = target.getPaddingBottom();
        Window w = a.getWindow();
        if (Build.VERSION.SDK_INT >= 21) {
            w.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_NAVIGATION);
            w.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
        }
        target.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
                int top = insets.getSystemWindowInsetTop();
                int bot = insets.getSystemWindowInsetBottom();
                int left = insets.getSystemWindowInsetLeft();
                int right = insets.getSystemWindowInsetRight();
                // Preserve the layout's own spacing and add safe areas exactly once.
                v.setPadding(baseLeft + left, baseTop + top,
                        baseRight + right, baseBottom + bot);
                return insets;
            }
        });
        target.requestApplyInsets();
    }
}
