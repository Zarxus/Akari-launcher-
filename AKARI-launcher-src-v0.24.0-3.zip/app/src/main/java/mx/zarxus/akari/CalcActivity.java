package mx.zarxus.akari;
import android.app.Activity;
import android.os.Bundle;
import android.view.animation.OvershootInterpolator;
import android.widget.TextView;
import java.text.DecimalFormat;
import java.text.DecimalFormatSymbols;
import java.util.Locale;

public class CalcActivity extends Activity {
    private final StringBuilder b=new StringBuilder();
    private final DecimalFormat f=new DecimalFormat("0.##########",DecimalFormatSymbols.getInstance(Locale.US));
    private TextView out,expr,line,hist,mem;
    private double ans;
    private boolean done;
    @Override protected void onCreate(Bundle x){super.onCreate(x);setContentView(R.layout.activity_calc);Insets.attach(this);
        SoundEngine.init(this);Voice.init(this);out=findViewById(R.id.calcOut);expr=findViewById(R.id.calcExpr);
        line=findViewById(R.id.calcLine);hist=findViewById(R.id.calcHistory);mem=findViewById(R.id.calcMemory);
        hist.setText(Prefs.calcHistory().isEmpty()?"SIN HISTORIAL":Prefs.calcHistory());
        findViewById(R.id.btnBack).setOnClickListener(v->{SoundEngine.back();finish();});
        int[] nums={R.id.c0,R.id.c1,R.id.c2,R.id.c3,R.id.c4,R.id.c5,R.id.c6,R.id.c7,R.id.c8,R.id.c9};
        for(int id:nums){TextView v=findViewById(id);v.setOnClickListener(q->push(v.getText().toString()));}
        bind(R.id.cDot,".");bind(R.id.cAdd,"+");bind(R.id.cSub,"-");bind(R.id.cMul,"×");bind(R.id.cDiv,"÷");
        bind(R.id.cOpen,"(");bind(R.id.cClose,")");bind(R.id.cPercent,"%");bind(R.id.cPow,"^");bind(R.id.cSqrt,"√(");
        findViewById(R.id.cClr).setOnClickListener(v->clear());
        findViewById(R.id.cClr).setOnLongClickListener(v->{Prefs.setCalcHistory("");hist.setText("SIN HISTORIAL");return true;});
        findViewById(R.id.cBack).setOnClickListener(v->{if(b.length()>0)b.deleteCharAt(b.length()-1);done=false;refresh();});
        findViewById(R.id.cSign).setOnClickListener(v->{if(b.length()==0)b.append('-');else b.insert(0,"-(").append(')');done=false;refresh();});
        findViewById(R.id.cEq).setOnClickListener(v->solve());
        findViewById(R.id.cMemAdd).setOnClickListener(v->{try{Prefs.setCalcMemory(Prefs.calcMemory()+Parser.solve(b.toString()));renderMem();Haptics.success(this);}catch(Exception ignored){}});
        findViewById(R.id.cMemRecall).setOnClickListener(v->push(fmt(Prefs.calcMemory())));
        findViewById(R.id.cMemClear).setOnClickListener(v->{Prefs.setCalcMemory(0);renderMem();});
        findViewById(R.id.cAns).setOnClickListener(v->push(fmt(ans)));
        int[] all={R.id.c0,R.id.c1,R.id.c2,R.id.c3,R.id.c4,R.id.c5,R.id.c6,R.id.c7,R.id.c8,R.id.c9,
                R.id.cDot,R.id.cAdd,R.id.cSub,R.id.cMul,R.id.cDiv,R.id.cOpen,R.id.cClose,R.id.cPercent,
                R.id.cPow,R.id.cSqrt,R.id.cClr,R.id.cBack,R.id.cSign,R.id.cEq,R.id.cMemAdd,R.id.cMemRecall,R.id.cMemClear,R.id.cAns};
        for(int id:all)DockMotion.bind(findViewById(id));renderMem();
        Voice.speak("Core Math en línea. Prioridad, paréntesis, potencias, memoria e historial.");
    }
    private void bind(int id,String t){findViewById(id).setOnClickListener(v->push(t));}
    private void push(String t){if(b.length()>72)return;if(done&&!"+-×÷^%".contains(t))b.setLength(0);done=false;
        if(("(".equals(t)||t.startsWith("√"))&&b.length()>0&&(Character.isDigit(b.charAt(b.length()-1))||b.charAt(b.length()-1)==')'))b.append('×');
        b.append(t);SoundEngine.calc();Haptics.tap(this);refresh();}
    private void refresh(){expr.setText(b.length()==0?"":b.toString());if(b.length()==0){out.setText("0");return;}
        try{out.setText(fmt(Parser.solve(b.toString())));}catch(Exception e){out.setText("…");}}
    private void clear(){b.setLength(0);done=false;expr.setText("");out.setText("0");line.setText("Cuenta conmigo.");SoundEngine.back();}
    private void solve(){if(b.length()==0)return;String original=b.toString();try{ans=Parser.solve(original);String r=fmt(ans);
        b.setLength(0);b.append(r);done=true;expr.setText(original+" =");out.setText(r);history(original+" = "+r);
        String q=AkariLines.calcResult(ans);line.setText(q);SoundEngine.unlock();Haptics.success(this);
        out.setScaleX(.84f);out.setScaleY(.84f);out.animate().scaleX(1).scaleY(1).setDuration(300).setInterpolator(new OvershootInterpolator(1.8f)).start();
        Voice.speak(q+" Da "+r.replace("."," punto "));}catch(Exception e){out.setText("ERROR");line.setText(e.getMessage());SoundEngine.back();Haptics.warning(this);}}
    private void history(String row){String old=Prefs.calcHistory();String n=row+(old.isEmpty()?"":"\n"+old);String[] rows=n.split("\n");StringBuilder z=new StringBuilder();
        for(int i=0;i<Math.min(4,rows.length);i++){if(i>0)z.append('\n');z.append(rows[i]);}Prefs.setCalcHistory(z.toString());hist.setText(z);}
    private void renderMem(){mem.setText("MEMORIA · "+fmt(Prefs.calcMemory()));}
    private String fmt(double v){if(!Double.isFinite(v))throw new ArithmeticException("Resultado fuera del dominio.");if(Math.abs(v)<5e-11)v=0;return f.format(v);}

    static final class Parser{
        final String s;int p;Parser(String x){s=x.replace(" ","").replace('×','*').replace('÷','/').replace("√","sqrt");}
        static double solve(String x){Parser q=new Parser(x);double v=q.expr();if(q.p!=q.s.length())throw new IllegalArgumentException("Símbolo inesperado.");if(!Double.isFinite(v))throw new ArithmeticException("Resultado fuera del dominio.");return v;}
        double expr(){double v=term();for(;;){if(eat('+'))v+=term();else if(eat('-'))v-=term();else return v;}}
        double term(){double v=power();for(;;){if(eat('*'))v*=power();else if(eat('/')){double d=power();if(Math.abs(d)<1e-15)throw new ArithmeticException("Dividir entre cero no está definido.");v/=d;}else return v;}}
        double power(){double v=unary();if(eat('^'))v=Math.pow(v,power());return v;}
        double unary(){if(eat('+'))return unary();if(eat('-'))return-unary();double v;if(word("sqrt")){need('(');v=expr();need(')');if(v<0)throw new ArithmeticException("La raíz real de un negativo no existe.");v=Math.sqrt(v);}else if(eat('(')){v=expr();need(')');}else v=number();while(eat('%'))v/=100;return v;}
        double number(){int a=p;while(p<s.length()&&(Character.isDigit(s.charAt(p))||s.charAt(p)=='.'))p++;if(a==p)throw new IllegalArgumentException("Expresión incompleta.");return Double.parseDouble(s.substring(a,p));}
        boolean eat(char c){if(p<s.length()&&s.charAt(p)==c){p++;return true;}return false;}
        boolean word(String w){if(s.regionMatches(p,w,0,w.length())){p+=w.length();return true;}return false;}
        void need(char c){if(!eat(c))throw new IllegalArgumentException("Falta cerrar el paréntesis.");}
    }
}
