package mx.zarxus.akari;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.AlarmClock;
import android.provider.MediaStore;
import android.view.View;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class DossierActivity extends Activity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_dossier);

        Insets.attach(this);        Voice.init(this);

        ((TextView) findViewById(R.id.dossierTitle)).setText(Identity.title());
        ((TextView) findViewById(R.id.dossierBody)).setText(Identity.dossier());
        ImageView art = findViewById(R.id.dossierArt);
        if (Prefs.heat() >= 60) art.setImageResource(R.drawable.cg_face);
        else if (Prefs.heat() >= 30) art.setImageResource(R.drawable.cg_jacket);
        else art.setImageResource(R.drawable.akari_portrait);

        EditText note = findViewById(R.id.noteBox);
        note.setText(Prefs.note());

        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { SoundEngine.back(); finish(); }
        });
        findViewById(R.id.btnSaveNote).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Prefs.setNote(note.getText().toString());
                Voice.speak("Guardé tu nota. La voy a recordar.");
                Toast.makeText(DossierActivity.this, "Nota en el core", Toast.LENGTH_SHORT).show();
            }
        });
        findViewById(R.id.winStudio).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(DossierActivity.this, StudioActivity.class));
            }
        });
        findViewById(R.id.winPortal).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Launcher.openPortal(DossierActivity.this, "https://www.google.com", "Portal");
            }
        });
        findViewById(R.id.winNews).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(DossierActivity.this, NewsActivity.class));
            }
        });
        findViewById(R.id.winSignal).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(DossierActivity.this, NotificationCenterActivity.class));
            }
        });
        findViewById(R.id.winEroge).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(DossierActivity.this, ErogeHubActivity.class));
            }
        });
        findViewById(R.id.winCalc).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(DossierActivity.this, CalcActivity.class));
            }
        });
        findViewById(R.id.winArcade).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(DossierActivity.this, ArcadeActivity.class));
            }
        });
        findViewById(R.id.winPulse).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(DossierActivity.this, PulseActivity.class));
            }
        });
        findViewById(R.id.winChess).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(DossierActivity.this, ChessActivity.class));
            }
        });
        findViewById(R.id.winLounge).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(DossierActivity.this, LoungeActivity.class));
            }
        });
        findViewById(R.id.winVol).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(DossierActivity.this, VolumeActivity.class));
            }
        });
        findViewById(R.id.winLock).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(DossierActivity.this, LockActivity.class));
            }
        });
        findViewById(R.id.utilCal).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_CALENDAR));
                } catch (Exception e) {
                    startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse("content://com.android.calendar/time")));
                }
            }
        });
        findViewById(R.id.utilClock).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    startActivity(new Intent(AlarmClock.ACTION_SHOW_ALARMS));
                } catch (Exception ignored) {}
            }
        });
        findViewById(R.id.utilFiles).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    startActivity(new Intent(Intent.ACTION_GET_CONTENT).setType("*/*"));
                } catch (Exception ignored) {}
            }
        });

        String hello = "Dossier abierto. Esta soy yo. Elige una ventana o déjame una nota.";
        Voice.speak(hello);
        if (Prefs.note() != null && !Prefs.note().isEmpty()) {
            Voice.speakQueue("Tu última nota: " + Prefs.note());
        }
    }
}
