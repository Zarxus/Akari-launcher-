package mx.zarxus.akari;

import android.content.Context;
import android.content.SharedPreferences;

public final class Prefs {
    public static final String MODE_ECCHI = "ecchi";
    public static final String MODE_TECH = "tech";
    public static final String MODE_MIX = "mix";
    public static final String MODE_HENTAI = "hentai";

    private static SharedPreferences p;

    public static void init(Context c) {
        p = c.getSharedPreferences("akari", Context.MODE_PRIVATE);
    }

    private static SharedPreferences p() {
        if (p == null) throw new IllegalStateException("Prefs.init missing");
        return p;
    }

    public static String mode() {
        return p().getString("mode", MODE_HENTAI);
    }

    public static void setMode(String m) {
        p.edit().putString("mode", m).apply();
    }

    public static boolean haptic() {
        return p.getBoolean("haptic", true);
    }

    public static void setHaptic(boolean v) {
        p.edit().putBoolean("haptic", v).apply();
    }

    public static boolean sound() {
        return p.getBoolean("sound", true);
    }

    public static void setSound(boolean v) {
        p.edit().putBoolean("sound", v).apply();
    }

    public static boolean ambient() {
        return p.getBoolean("ambient", true);
    }

    public static void setAmbient(boolean v) {
        p.edit().putBoolean("ambient", v).apply();
    }

    public static boolean voice() {
        return p.getBoolean("voice", true);
    }

    public static void setVoice(boolean v) {
        p.edit().putBoolean("voice", v).apply();
        if (!v) Voice.stop();
    }

    public static boolean voiceAuto() {
        return p.getBoolean("voice_auto", false);
    }

    public static void setVoiceAuto(boolean v) {
        p.edit().putBoolean("voice_auto", v).apply();
    }

    /** Controls explicit web links only. Installed application tiles always open natively. */
    public static boolean internalBrowser() {
        return p().getBoolean("internal_browser", true);
    }

    public static void setInternalBrowser(boolean v) {
        p().edit().putBoolean("internal_browser", v).apply();
    }

    /** Kept for source compatibility with older modules; no longer controls app launching. */
    @Deprecated public static boolean portalFirst() { return internalBrowser(); }
    @Deprecated public static void setPortalFirst(boolean v) { setInternalBrowser(v); }

    public static int riftStyle() {
        return clamp(p().getInt("rift_style", 0), 0, 3);
    }

    public static void setRiftStyle(int value) {
        p().edit().putInt("rift_style", clamp(value, 0, 3)).apply();
    }

    public static int poseMode() {
        return clamp(p().getInt("pose_mode", 1), 0, 2);
    }

    public static void setPoseMode(int value) {
        p().edit().putInt("pose_mode", clamp(value, 0, 2)).apply();
    }

    public static int portalVisits() {
        return p().getInt("portal_visits", 0);
    }

    public static void incPortalVisits() {
        p().edit().putInt("portal_visits", portalVisits() + 1).apply();
    }

    /** Returns the consecutive touch count for this body zone and stores the new state. */
    public static int bodyZoneStreak(int zone) {
        int previous = p().getInt("body_zone_last", -1);
        int streak = previous == zone ? p().getInt("body_zone_streak", 0) + 1 : 1;
        p().edit().putInt("body_zone_last", zone).putInt("body_zone_streak", streak).apply();
        return streak;
    }

    public static boolean physics() {
        return p.getBoolean("physics", true);
    }

    public static void setPhysics(boolean v) {
        p.edit().putBoolean("physics", v).apply();
    }

    /** 0 = calm, 1 = balanced, 2 = vivid. Kept separate from the physics switch. */
    public static int motionLevel() {
        return clamp(p().getInt("motion_level", 2), 0, 2);
    }

    public static void setMotionLevel(int value) {
        p().edit().putInt("motion_level", clamp(value, 0, 2)).apply();
    }

    public static float motionScale() {
        int value = motionLevel();
        if (value == 0) return .62f;
        if (value == 1) return .86f;
        return 1.10f;
    }

    public static int soundLevel() {
        return clamp(p().getInt("sound_level", 82), 0, 100);
    }

    public static void setSoundLevel(int value) {
        p().edit().putInt("sound_level", clamp(value, 0, 100)).apply();
    }

    public static float soundScale() {
        return soundLevel() / 100f;
    }

    public static int ambientLevel() {
        return clamp(p().getInt("ambient_level", 62), 0, 100);
    }

    public static void setAmbientLevel(int value) {
        p().edit().putInt("ambient_level", clamp(value, 0, 100)).apply();
    }

    public static float ambientScale() {
        return ambientLevel() / 100f;
    }

    public static boolean commandDeckExpanded() {
        return p().getBoolean("command_deck_expanded", false);
    }

    public static void setCommandDeckExpanded(boolean value) {
        p().edit().putBoolean("command_deck_expanded", value).apply();
    }

    public static float avatarScale() {
        return Math.max(.80f, Math.min(1.16f, p().getFloat("avatar_scale", 1f)));
    }

    public static void setAvatarScale(float value) {
        p().edit().putFloat("avatar_scale", Math.max(.80f, Math.min(1.16f, value))).apply();
    }

    public static int wallpaper() {
        return p.getInt("wallpaper", 0);
    }

    public static void setWallpaper(int i) {
        p.edit().putInt("wallpaper", i).apply();
    }

    public static int bond() {
        return p.getInt("bond", 8);
    }

    public static void addBond(int d) {
        p.edit().putInt("bond", clamp(bond() + d, 0, 100)).apply();
    }

    public static int heat() {
        return p.getInt("heat", 0);
    }

    public static void addHeat(int d) {
        p.edit().putInt("heat", clamp(heat() + d, 0, 100)).apply();
    }

    public static void setHeat(int v) {
        p.edit().putInt("heat", clamp(v, 0, 100)).apply();
    }

    public static boolean unlocked(String id) {
        return p.getBoolean("cg_" + id, "boot".equals(id));
    }

    public static void unlock(String id) {
        p.edit().putBoolean("cg_" + id, true).apply();
    }

    public static String lastDaily() {
        return p.getString("last_daily", "");
    }

    public static void setLastDaily(String day) {
        p.edit().putString("last_daily", day).apply();
    }

    public static int scenesDone() {
        return p.getInt("scenes_done", 0);
    }

    public static void incScenes() {
        p.edit().putInt("scenes_done", scenesDone() + 1).apply();
    }

    public static int touches() {
        return p.getInt("touches", 0);
    }

    public static void incTouches() {
        p.edit().putInt("touches", touches() + 1).apply();
    }

    public static boolean showSeconds() {
        return p.getBoolean("seconds", true);
    }

    public static void setShowSeconds(boolean v) {
        p.edit().putBoolean("seconds", v).apply();
    }

    public static String city() {
        return p.getString("city", "Hermosillo");
    }

    public static double lat() {
        return Double.parseDouble(p.getString("lat", "29.0729"));
    }

    public static double lon() {
        return Double.parseDouble(p.getString("lon", "-110.9559"));
    }

    public static void setPlace(String city, double lat, double lon) {
        p.edit().putString("city", city)
                .putString("lat", String.valueOf(lat))
                .putString("lon", String.valueOf(lon))
                .apply();
    }

    public static String searchEngine() {
        return p.getString("engine", "ddg");
    }

    public static void setSearchEngine(String e) {
        p.edit().putString("engine", e).apply();
    }

    public static String weatherCache() {
        return p.getString("wx_cache", "");
    }

    public static long weatherCacheAt() {
        return p.getLong("wx_at", 0);
    }

    public static void setWeatherCache(String json) {
        p.edit().putString("wx_cache", json).putLong("wx_at", System.currentTimeMillis()).apply();
    }

    public static String newsCache() {
        return p.getString("news_cache", "");
    }

    public static void setNewsCache(String xml) {
        p.edit().putString("news_cache", xml).putLong("news_at", System.currentTimeMillis()).apply();
    }

    public static long newsCacheAt() {
        return p.getLong("news_at", 0);
    }

    public static String dockPins() {
        return p.getString("dock_pins", "");
    }

    public static boolean pinned(String pkg) {
        if (pkg == null || pkg.isEmpty()) return false;
        String raw = dockPins();
        if (raw == null || raw.isEmpty()) return false;
        for (String value : raw.split(",")) if (pkg.equals(value)) return true;
        return false;
    }

    public static void togglePin(String pkg) {
        java.util.LinkedHashSet<String> set = new java.util.LinkedHashSet<>();
        String raw = dockPins();
        if (raw != null && !raw.isEmpty()) {
            for (String s : raw.split(",")) if (!s.isEmpty()) set.add(s);
        }
        if (!set.remove(pkg)) {
            if (set.size() >= 5) {
                java.util.Iterator<String> oldest = set.iterator();
                if (oldest.hasNext()) {
                    oldest.next();
                    oldest.remove();
                }
            }
            set.add(pkg);
        }
        StringBuilder sb = new StringBuilder();
        int i = 0;
        for (String s : set) {
            if (i++ > 0) sb.append(',');
            sb.append(s);
            if (i >= 5) break;
        }
        p.edit().putString("dock_pins", sb.toString()).apply();
    }

    public static boolean companionOpen() {
        return p.getBoolean("comp_open", true);
    }

    public static void setCompanionOpen(boolean v) {
        p.edit().putBoolean("comp_open", v).apply();
    }

    public static void setLastSay(String s) {
        if (s == null) return;
        p.edit().putString("last_say", s).apply();
    }

    public static String lastSay() {
        return p.getString("last_say", "");
    }

    public static String note() {
        return p.getString("note", "");
    }

    public static void setNote(String s) {
        p.edit().putString("note", s == null ? "" : s).apply();
    }

    public static int pulseBest() {
        return p.getInt("pulse_best", 0);
    }

    public static void setPulseBest(int v) {
        p.edit().putInt("pulse_best", v).apply();
    }

    public static boolean alarmEnabled(){return p().getBoolean("alarm_enabled",false);}
    public static void setAlarmEnabled(boolean v){p().edit().putBoolean("alarm_enabled",v).apply();}
    public static int alarmHour(){return p().getInt("alarm_hour",7);}
    public static int alarmMinute(){return p().getInt("alarm_minute",0);}
    public static int alarmDays(){return p().getInt("alarm_days",0x7F);}
    public static String alarmLabel(){return p().getString("alarm_label","Despierta, Saúl");}
    public static void setAlarmConfig(int h,int m,int days,String label){p().edit().putInt("alarm_hour",h)
            .putInt("alarm_minute",m).putInt("alarm_days",days).putString("alarm_label",label).apply();}
    public static boolean alarmGradual(){return p().getBoolean("alarm_gradual",true);}
    public static void setAlarmGradual(boolean v){p().edit().putBoolean("alarm_gradual",v).apply();}
    public static int alarmSnoozeMinutes(){return p().getInt("alarm_snooze_minutes",10);}
    public static void setAlarmSnoozeMinutes(int v){p().edit().putInt("alarm_snooze_minutes",clamp(v,5,15)).apply();}
    public static long alarmNextAt(){return p().getLong("alarm_next_at",0);}
    public static void setAlarmNextAt(long v){p().edit().putLong("alarm_next_at",v).apply();}
    public static long alarmSnoozeAt(){return p().getLong("alarm_snooze_at",0);}
    public static void setAlarmSnoozeAt(long v){p().edit().putLong("alarm_snooze_at",v).apply();}
    public static String calcHistory(){return p().getString("calc_history","");}
    public static void setCalcHistory(String v){p().edit().putString("calc_history",v==null?"":v).apply();}
    public static double calcMemory(){return Double.longBitsToDouble(p().getLong("calc_memory",Double.doubleToRawLongBits(0d)));}
    public static void setCalcMemory(double v){p().edit().putLong("calc_memory",Double.doubleToRawLongBits(v)).apply();}
    public static int chessLevel(){return clamp(p().getInt("chess_level",2),1,3);}
    public static void setChessLevel(int v){p().edit().putInt("chess_level",clamp(v,1,3)).apply();}
    public static int newsTopic(){return clamp(p().getInt("news_topic",0),0,3);}
    public static void setNewsTopic(int v){p().edit().putInt("news_topic",clamp(v,0,3)).apply();}
    public static String newsCache(int t){return p().getString(t==0?"news_cache":"news_cache_"+t,"");}
    public static long newsCacheAt(int t){return p().getLong(t==0?"news_at":"news_at_"+t,0);}
    public static void setNewsCache(int t,String xml){p().edit().putString(t==0?"news_cache":"news_cache_"+t,xml)
            .putLong(t==0?"news_at":"news_at_"+t,System.currentTimeMillis()).apply();}

    public static boolean permsPrompted() {
        return p.getBoolean("perms_prompted", false);
    }

    public static void setPermsPrompted(boolean v) {
        p.edit().putBoolean("perms_prompted", v).apply();
    }

    public static boolean liveWall() {
        return p.getBoolean("live_wall", true);
    }

    public static void setLiveWall(boolean v) {
        p.edit().putBoolean("live_wall", v).apply();
    }

    public static boolean notificationPrivacy() {
        return p.getBoolean("notification_privacy", false);
    }

    public static void setNotificationPrivacy(boolean value) {
        p.edit().putBoolean("notification_privacy", value).apply();
    }

    public static boolean notificationVoice() {
        return p.getBoolean("notification_voice", false);
    }

    public static void setNotificationVoice(boolean value) {
        p.edit().putBoolean("notification_voice", value).apply();
    }

    public static boolean immersiveHome() {
        return p.getBoolean("immersive_home", false);
    }

    public static void setImmersiveHome(boolean value) {
        p.edit().putBoolean("immersive_home", value).apply();
    }

    public static long notificationSeenAt() {
        return p.getLong("notification_seen_at", 0L);
    }

    public static void setNotificationSeenAt(long value) {
        p.edit().putLong("notification_seen_at", value).apply();
    }

    public static void rememberNotification(String app, String kind, long when) {
        p.edit()
                .putString("last_notification_app", app == null ? "una aplicación" : app)
                .putString("last_notification_kind", kind == null ? "notification" : kind)
                .putLong("last_notification_at", when)
                .apply();
    }

    public static String lastNotificationApp() {
        return p.getString("last_notification_app", "una aplicación");
    }

    public static String lastNotificationKind() {
        return p.getString("last_notification_kind", "notification");
    }

    public static long lastNotificationAt() {
        return p.getLong("last_notification_at", 0L);
    }

    public static long lastNotificationReactedAt() {
        return p.getLong("last_notification_reacted_at", 0L);
    }

    public static void setLastNotificationReactedAt(long value) {
        p.edit().putLong("last_notification_reacted_at", value).apply();
    }

    public static boolean hidden(String pkg) {
        String s = p.getString("hidden", "");
        return pkg != null && ("," + s + ",").contains("," + pkg + ",");
    }

    public static void toggleHidden(String pkg) {
        java.util.LinkedHashSet<String> set = new java.util.LinkedHashSet<>();
        String s = p.getString("hidden", "");
        if (s != null && !s.isEmpty()) {
            for (String x : s.split(",")) if (!x.isEmpty()) set.add(x);
        }
        if (!set.add(pkg)) set.remove(pkg);
        StringBuilder sb = new StringBuilder();
        for (String x : set) {
            if (sb.length() > 0) sb.append(',');
            sb.append(x);
        }
        p.edit().putString("hidden", sb.toString()).apply();
    }

    private static int clamp(int v, int a, int b) {
        return Math.max(a, Math.min(b, v));
    }
}
