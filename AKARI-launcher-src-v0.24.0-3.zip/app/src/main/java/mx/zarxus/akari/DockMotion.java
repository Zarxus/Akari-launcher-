package mx.zarxus.akari;
import android.view.MotionEvent;
import android.os.Build;
import android.view.View;
import android.view.ViewGroup;
import android.view.animation.OvershootInterpolator;
public final class DockMotion {
    private DockMotion(){}
    public static void bind(final View v){if(v==null)return;v.setOnTouchListener(new View.OnTouchListener(){
        float x,y;
        @Override public boolean onTouch(View q,MotionEvent e){if(!Prefs.physics())return false;
            float m=Prefs.motionScale();
            if(e.getActionMasked()==MotionEvent.ACTION_DOWN){x=e.getRawX();y=e.getRawY();q.animate().cancel();
                q.animate().scaleX(1f+.11f*m).scaleY(1f+.11f*m).translationY(-dp(q,7)*m).setDuration(90).start();
                if(Build.VERSION.SDK_INT>=21)q.setElevation(dp(q,18));Haptics.press(q.getContext());
                if(q.getTag() instanceof String)SoundEngine.appTouch((String)q.getTag());neighbors(q,true);
            }else if(e.getActionMasked()==MotionEvent.ACTION_MOVE){float dx=e.getRawX()-x,dy=e.getRawY()-y;
                q.setTranslationX(clamp(dx*.1f*m,-dp(q,8)*m,dp(q,8)*m));q.setTranslationY(clamp(-dp(q,7)*m+dy*.06f*m,-dp(q,12)*m,dp(q,2)*m));
                q.setRotation(clamp(dx*.05f*m,-7*m,7*m));
            }else if(e.getActionMasked()==MotionEvent.ACTION_UP||e.getActionMasked()==MotionEvent.ACTION_CANCEL){settle(q);neighbors(q,false);}
            return false;}});
    }
    public static void launchWave(View v){SoundEngine.dock();float m=Prefs.motionScale();ViewGroup g=v.getParent()instanceof ViewGroup?(ViewGroup)v.getParent():null;
        if(g==null)return;int at=g.indexOfChild(v);for(int i=0;i<g.getChildCount();i++){View c=g.getChildAt(i);long delay=Math.abs(i-at)*28L;
            c.animate().cancel();c.animate().translationY((i==at?-dp(c,10):-dp(c,4))*m).scaleX(1f+(i==at?.15f:.04f)*m)
                    .scaleY(1f+(i==at?.15f:.04f)*m).setStartDelay(delay).setDuration(90).withEndAction(()->settle(c)).start();}}
    private static void neighbors(View v,boolean up){ViewGroup g=v.getParent()instanceof ViewGroup?(ViewGroup)v.getParent():null;if(g==null)return;
        float m=Prefs.motionScale();
        int at=g.indexOfChild(v);for(int i=0;i<g.getChildCount();i++){View c=g.getChildAt(i);if(c==v)continue;int d=Math.abs(i-at);if(d>2)continue;
            c.animate().scaleX(up?1f+(d==1?.052f:.024f)*m:1).scaleY(up?1f+(d==1?.052f:.024f)*m:1)
                    .translationY(up?-dp(v,d==1?3:1)*m:0).setDuration(up?110:220).start();}}
    private static void settle(View v){v.animate().cancel();v.animate().translationX(0).translationY(0).rotation(0).scaleX(1).scaleY(1)
            .setStartDelay(0).setDuration(260+(long)(45*Prefs.motionScale())).setInterpolator(new OvershootInterpolator(1.05f+.65f*Prefs.motionScale())).start();if(Build.VERSION.SDK_INT>=21)v.setElevation(0);}
    private static float clamp(float n,float a,float b){return Math.max(a,Math.min(b,n));}
    private static int dp(View v,int n){return Math.round(n*v.getResources().getDisplayMetrics().density);}
}
