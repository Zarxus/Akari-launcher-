package mx.zarxus.akari;

import org.json.JSONArray;
import org.json.JSONObject;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;
import java.util.TimeZone;

public final class Weather {
    public String city = "Hermosillo";
    public double lat = 29.0729;
    public double lon = -110.9559;
    public int temp = Integer.MIN_VALUE;
    public int hi = Integer.MIN_VALUE;
    public int lo = Integer.MIN_VALUE;
    public int humidity = -1;
    public int wind = -1;
    public int code = -1;
    public double uv = Double.NaN;
    public double uvMax = Double.NaN;
    public long sunriseAt;
    public long sunsetAt;
    public int daylightSeconds = -1;
    public String timezone = TimeZone.getDefault().getID();
    public String desc = "sin datos";
    public long fetchedAt;

    public String line() {
        if (temp == Integer.MIN_VALUE) return city + " · actualizando…";
        String hilo = (hi != Integer.MIN_VALUE) ? ("  " + lo + "°/" + hi + "°") : "";
        return icon() + "  " + temp + "°C" + hilo + "  ·  " + desc + "  ·  " + city;
    }

    public String icon() {
        if (code == 0) return "☀";
        if (code == 1 || code == 2) return "⛅";
        if (code == 3) return "☁";
        if (code >= 45 && code <= 48) return "🌫";
        if (code >= 51 && code <= 67) return "🌧";
        if (code >= 71 && code <= 77) return "❄";
        if (code >= 80 && code <= 82) return "🌧";
        if (code >= 95) return "⛈";
        return "◉";
    }

    public static String describe(int code) {
        if (code == 0) return "despejado";
        if (code == 1) return "mayormente despejado";
        if (code == 2) return "parcialmente nublado";
        if (code == 3) return "nublado";
        if (code >= 45 && code <= 48) return "niebla";
        if (code >= 51 && code <= 55) return "llovizna";
        if (code >= 56 && code <= 57) return "llovizna helada";
        if (code >= 61 && code <= 67) return "lluvia";
        if (code >= 71 && code <= 77) return "nieve";
        if (code >= 80 && code <= 82) return "chubascos";
        if (code >= 95) return "tormenta";
        return "variable";
    }

    public static Weather parse(String json, String city, double lat, double lon) throws Exception {
        JSONObject o = new JSONObject(json);
        Weather w = new Weather();
        w.city = city;
        w.lat = lat;
        w.lon = lon;
        w.fetchedAt = System.currentTimeMillis();
        if (o.has("current")) {
            JSONObject c = o.getJSONObject("current");
            w.temp = (int) Math.round(c.optDouble("temperature_2m", Double.NaN));
            w.humidity = c.optInt("relative_humidity_2m", -1);
            w.wind = (int) Math.round(c.optDouble("wind_speed_10m", -1));
            w.code = c.optInt("weather_code", -1);
            w.uv = c.optDouble("uv_index", Double.NaN);
            w.desc = describe(w.code);
        }
        w.timezone = o.optString("timezone", TimeZone.getDefault().getID());
        if (o.has("daily")) {
            JSONObject d = o.getJSONObject("daily");
            JSONArray max = d.optJSONArray("temperature_2m_max");
            JSONArray min = d.optJSONArray("temperature_2m_min");
            if (max != null && max.length() > 0) w.hi = (int) Math.round(max.getDouble(0));
            if (min != null && min.length() > 0) w.lo = (int) Math.round(min.getDouble(0));
            JSONArray uvMax = d.optJSONArray("uv_index_max");
            JSONArray sunrise = d.optJSONArray("sunrise");
            JSONArray sunset = d.optJSONArray("sunset");
            JSONArray daylight = d.optJSONArray("daylight_duration");
            if (uvMax != null && uvMax.length() > 0) w.uvMax = uvMax.optDouble(0, Double.NaN);
            if (sunrise != null && sunrise.length() > 0) w.sunriseAt = parseLocal(sunrise.optString(0), w.timezone);
            if (sunset != null && sunset.length() > 0) w.sunsetAt = parseLocal(sunset.optString(0), w.timezone);
            if (daylight != null && daylight.length() > 0) {
                w.daylightSeconds = (int) Math.round(daylight.optDouble(0, -1));
            }
        }
        return w;
    }

    public boolean hasSolar() {
        return sunriseAt > 0 && sunsetAt > sunriseAt && !Double.isNaN(uv);
    }

    public float sunProgress() {
        if (sunriseAt <= 0 || sunsetAt <= sunriseAt) return 0f;
        return (float) Math.max(0d, Math.min(1d,
                (System.currentTimeMillis() - sunriseAt) / (double) (sunsetAt - sunriseAt)));
    }

    public boolean sunIsUp() {
        long now = System.currentTimeMillis();
        return now >= sunriseAt && now < sunsetAt;
    }

    public String uvLabel() {
        if (Double.isNaN(uv)) return "UV --";
        String risk = uv < 3 ? "BAJO" : uv < 6 ? "MODERADO" : uv < 8 ? "ALTO"
                : uv < 11 ? "MUY ALTO" : "EXTREMO";
        return String.format(Locale.getDefault(), "UV %.1f %s", uv, risk);
    }

    public String lightRemainingLabel() {
        if (sunriseAt <= 0 || sunsetAt <= sunriseAt) return "LUZ --";
        long now = System.currentTimeMillis();
        if (now < sunriseAt) return "SOL EN " + duration(sunriseAt - now);
        if (now < sunsetAt) return "LUZ " + duration(sunsetAt - now);
        return "SOL OCULTO";
    }

    public String dayRemainingLabel() {
        TimeZone zone = TimeZone.getTimeZone(timezone);
        Calendar next = Calendar.getInstance(zone);
        next.add(Calendar.DAY_OF_YEAR, 1);
        next.set(Calendar.HOUR_OF_DAY, 0);
        next.set(Calendar.MINUTE, 0);
        next.set(Calendar.SECOND, 0);
        next.set(Calendar.MILLISECOND, 0);
        return "DÍA " + duration(Math.max(0L, next.getTimeInMillis() - System.currentTimeMillis()));
    }

    public String sunriseLabel() { return timeLabel(sunriseAt); }
    public String sunsetLabel() { return timeLabel(sunsetAt); }

    public String solarNarration() {
        if (!hasSolar()) return "Aún no tengo el ciclo solar. Toca otra vez para sincronizarlo.";
        return uvLabel() + ". Amanecer " + sunriseLabel() + ", ocaso " + sunsetLabel()
                + ". " + lightRemainingLabel() + " y "
                + dayRemainingLabel().toLowerCase(Locale.ROOT) + " antes de mañana.";
    }

    private String timeLabel(long when) {
        if (when <= 0) return "--:--";
        SimpleDateFormat f = new SimpleDateFormat("HH:mm", Locale.getDefault());
        f.setTimeZone(TimeZone.getTimeZone(timezone));
        return f.format(new Date(when));
    }

    private static String duration(long millis) {
        long total = Math.max(0L, millis / 60_000L);
        long hours = total / 60L;
        long minutes = total % 60L;
        return hours > 0 ? String.format(Locale.getDefault(), "%dh %02dm", hours, minutes)
                : String.format(Locale.getDefault(), "%dm", minutes);
    }

    private static long parseLocal(String value, String timezone) {
        if (value == null || value.trim().isEmpty()) return 0L;
        try {
            SimpleDateFormat f = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm", Locale.US);
            f.setLenient(false);
            f.setTimeZone(TimeZone.getTimeZone(timezone));
            Date parsed = f.parse(value);
            return parsed == null ? 0L : parsed.getTime();
        } catch (Exception ignored) {
            return 0L;
        }
    }

    public static String[] geocode(String name) throws Exception {
        String q = java.net.URLEncoder.encode(name, "UTF-8");
        String raw = Net.get("https://geocoding-api.open-meteo.com/v1/search?name=" + q + "&count=1&language=es&format=json");
        JSONObject o = new JSONObject(raw);
        JSONArray arr = o.optJSONArray("results");
        if (arr == null || arr.length() == 0) throw new RuntimeException("ciudad no encontrada");
        JSONObject r = arr.getJSONObject(0);
        return new String[]{
                r.optString("name", name),
                String.valueOf(r.getDouble("latitude")),
                String.valueOf(r.getDouble("longitude"))
        };
    }

    public String forecastUrl() {
        return "https://api.open-meteo.com/v1/forecast?latitude=" + lat
                + "&longitude=" + lon
                + "&current=temperature_2m,relative_humidity_2m,weather_code,wind_speed_10m,uv_index,is_day"
                + "&daily=temperature_2m_max,temperature_2m_min,weather_code,uv_index_max,sunrise,sunset,daylight_duration"
                + "&forecast_days=2&timezone=auto";
    }
}
