package mx.zarxus.akari;

import android.content.ContentUris;
import android.content.Context;
import android.database.Cursor;
import android.net.Uri;
import android.os.Build;
import android.provider.MediaStore;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class MusicLib {
    private MusicLib() {}

    public static List<Track> load(Context ctx) {
        List<Track> out = new ArrayList<>();
        Uri base = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI;
        String[] cols = new String[]{
                MediaStore.Audio.Media._ID,
                MediaStore.Audio.Media.TITLE,
                MediaStore.Audio.Media.ARTIST,
                MediaStore.Audio.Media.DURATION,
                MediaStore.Audio.Media.IS_MUSIC
        };
        String sort = MediaStore.Audio.Media.TITLE + " COLLATE NOCASE ASC";
        try {
            Cursor c = ctx.getContentResolver().query(base, cols, null, null, sort);
            if (c == null) return out;
            int iId = c.getColumnIndex(MediaStore.Audio.Media._ID);
            int iT = c.getColumnIndex(MediaStore.Audio.Media.TITLE);
            int iA = c.getColumnIndex(MediaStore.Audio.Media.ARTIST);
            int iD = c.getColumnIndex(MediaStore.Audio.Media.DURATION);
            int iM = c.getColumnIndex(MediaStore.Audio.Media.IS_MUSIC);
            while (c.moveToNext()) {
                if (iM >= 0 && c.getInt(iM) == 0) continue;
                long id = c.getLong(iId);
                Uri u = ContentUris.withAppendedId(base, id);
                long dur = iD >= 0 ? c.getLong(iD) : 0;
                if (dur > 0 && dur < 8000) continue;
                out.add(new Track(id, c.getString(iT), c.getString(iA), dur, u));
            }
            c.close();
        } catch (Exception ignored) {}
        return out;
    }

    public static String mood(Track t, float energy) {
        String s = (t.title + " " + t.artist).toLowerCase(Locale.ROOT);
        if (has(s, "sad", "triste", "llor", "alone", "sadeness", "hurt", "pain"))
            return "melancólica";
        if (has(s, "love", "amor", "beso", "kiss", "heart", "corazón"))
            return "cariñosa";
        if (has(s, "phonk", "rage", "metal", "rock", "punk", "dnb", "bass"))
            return "agresiva";
        if (has(s, "lofi", "chill", "jazz", "ambient", "sleep", "piano"))
            return "suave";
        if (has(s, "night", "noche", "midnight", "2am", "3am"))
            return "nocturna";
        if (has(s, "dance", "disco", "edm", "house", "techno", "reggaeton", "perreo"))
            return "caliente";
        if (energy > 0.55f) return "eufórica";
        if (energy < 0.18f) return "soñolienta";
        return "a ritmo";
    }

    public static String moodLine(String mood) {
        if ("melancólica".equals(mood)) return "Esto duele rico. Acércate, no hables.";
        if ("cariñosa".equals(mood)) return "Tema de couple. Yo me pongo blandita.";
        if ("agresiva".equals(mood)) return "Me sube el heat a golpes. No pares el drop.";
        if ("suave".equals(mood)) return "Lofi en el loft. Me balanceo despacio.";
        if ("nocturna".equals(mood)) return "Hora de no dormir. Bailo pegada al core.";
        if ("caliente".equals(mood)) return "Esto es para perrear el HUD. Jacket off.";
        if ("eufórica".equals(mood)) return "El espectro está alto. No me sueltes.";
        if ("soñolienta".equals(mood)) return "Casi idle. Un sway, no un baile.";
        return "Voy a tu tempo. Tú pones la pista, yo el cuerpo.";
    }

    private static boolean has(String s, String... k) {
        for (String x : k) if (s.contains(x)) return true;
        return false;
    }
}
