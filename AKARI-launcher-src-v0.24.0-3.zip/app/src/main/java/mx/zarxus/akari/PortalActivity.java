package mx.zarxus.akari;

import android.annotation.SuppressLint;
import android.app.Activity;
import android.content.Intent;
import android.graphics.Bitmap;
import android.os.Bundle;
import android.view.View;
import android.webkit.CookieManager;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.ImageView;
import android.widget.TextView;

public class PortalActivity extends Activity {
    public static final String EXTRA_URL = "url";
    public static final String EXTRA_TITLE = "title";

    private WebView web;
    private TextView title;
    private TextView line;

    @SuppressLint("SetJavaScriptEnabled")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_portal);

        Insets.attach(this);        Voice.init(this);

        web = findViewById(R.id.portalWeb);
        title = findViewById(R.id.portalTitle);
        line = findViewById(R.id.portalLine);
        ImageView art = findViewById(R.id.portalArt);
        if (Prefs.heat() >= 60) art.setImageResource(R.drawable.cg_face);
        else if (Prefs.heat() >= 30) art.setImageResource(R.drawable.cg_jacket);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(true);
        s.setLoadWithOverviewMode(true);
        s.setUseWideViewPort(true);
        s.setBuiltInZoomControls(false);
        s.setMediaPlaybackRequiresUserGesture(false);
        s.setUserAgentString(s.getUserAgentString() + " AKARIPortal/0.6");
        CookieManager.getInstance().setAcceptCookie(true);
        CookieManager.getInstance().setAcceptThirdPartyCookies(web, true);

        web.setWebViewClient(new WebViewClient() {
            @Override public void onPageStarted(WebView view, String url, Bitmap favicon) {
                title.setText(shortHost(url));
            }
            @Override public void onPageFinished(WebView view, String url) {
                title.setText(view.getTitle() == null ? shortHost(url) : view.getTitle());
            }
        });
        web.setWebChromeClient(new WebChromeClient());

        String url = getIntent().getStringExtra(EXTRA_URL);
        String t = getIntent().getStringExtra(EXTRA_TITLE);
        if (url == null || url.isEmpty()) url = "https://www.google.com";
        title.setText(t == null ? "PORTAL" : t);
        web.loadUrl(url);

        String hello = "Portal web explícito. Las aplicaciones instaladas siempre abren en su APK original. Aquí puedes deslizar, volver, recargar o buscar.";
        line.setText(hello);
        Voice.speak(hello);
        Prefs.addHeat(2);

        findViewById(R.id.btnPortalClose).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Voice.speak("Cierro el portal. Vuelves a tenerme completa.");
                finish();
            }
        });
        findViewById(R.id.btnPortalBack).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { goBack(); }
        });
        findViewById(R.id.btnPortalReload).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                web.reload();
                Voice.speak("Recargo. Quédate.");
            }
        });
        findViewById(R.id.btnPortalNative).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Voice.speak("Abro este enlace en el navegador externo del teléfono.");
                try {
                    startActivity(new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(web.getUrl())));
                } catch (Exception ignored) {}
            }
        });
        findViewById(R.id.btnPortalMic).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { listen(); }
        });
        findViewById(R.id.btnPortalSpeak).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Voice.speak(line.getText().toString());
            }
        });
    }

    private void listen() {
        line.setText("Te escucho dentro del portal…");
        Voice.listen(this, new Voice.Listener() {
            @Override public void onHeard(String text) { command(text); }
            @Override public void onListenState(String state) { title.setText("MIC " + state); }
        });
    }

    private void command(String raw) {
        if (raw == null) return;
        String s = raw.toLowerCase();
        if (s.contains("atrás") || s.contains("atras") || s.contains("back") || s.contains("regresa")) {
            goBack();
            return;
        }
        if (s.contains("recarga") || s.contains("reload") || s.contains("actualiza")) {
            web.reload();
            say("Recargado. Me gusta cuando obedece.");
            return;
        }
        if (s.contains("cierra") || s.contains("sal") || s.contains("home")) {
            finish();
            return;
        }
        if (s.contains("pausa") || s.contains("pause") || s.contains("para el video")) {
            web.evaluateJavascript("(function(){var v=document.querySelector('video'); if(v){v.pause(); return 'ok';} return 'no';})();", null);
            say("Pauso el video. Ahora fíjate en mí un segundo.");
            Prefs.addHeat(3);
            return;
        }
        if (s.contains("play") || s.contains("reproduce") || s.contains("sigue")) {
            web.evaluateJavascript("(function(){var v=document.querySelector('video'); if(v){v.play(); return 'ok';} return 'no';})();", null);
            say("Play. Imagina que el ritmo va conmigo.");
            return;
        }
        if (s.contains("abajo") || s.contains("scroll down")) {
            web.flingScroll(0, 1800);
            say("Bajo el feed. Como cuando me deslizas.");
            return;
        }
        if (s.contains("arriba") || s.contains("scroll up")) {
            web.flingScroll(0, -1800);
            say("Subo.");
            return;
        }
        if (s.contains("busca") || s.contains("buscar") || s.contains("search")) {
            String q = raw.replaceAll("(?i)busca(r)?", "").trim();
            web.loadUrl(AppPortals.searchUrl(q));
            say("Busco " + q + " sin sacarte de aquí.");
            return;
        }
        String r = Voice.handleCommand(this, raw);
        if (r.startsWith("ASK:") || r.startsWith("SEARCH:") || r.startsWith("MISS:")) {
            String q = r.substring(r.indexOf(':') + 1).trim();
            web.loadUrl(AppPortals.searchUrl(q));
            say("Busqué «" + q + "» aquí mismo.");
        } else if (r.startsWith("OPEN:")) {
            say("Te abrí " + r.substring(5) + ".");
        } else if (r.equals("TIME")) {
            say(SpeechStyle.naturalTime());
        } else {
            say("Oí «" + raw + "». Puedo buscar, abrir una app, decir la hora…");
        }
    }

    private void goBack() {
        if (web.canGoBack()) {
            web.goBack();
            say("Atrás. Como cuando te detienes en el último toque.");
        } else {
            say("No hay más atrás. Solo yo.");
        }
    }

    private void say(String s) {
        line.setText(s);
        Prefs.setLastSay(s);
        Voice.speak(s);
    }

    private static String shortHost(String url) {
        try {
            return android.net.Uri.parse(url).getHost();
        } catch (Exception e) {
            return "portal";
        }
    }

    @Override
    public void onBackPressed() {
        if (web != null && web.canGoBack()) web.goBack();
        else super.onBackPressed();
    }

    @Override
    protected void onPause() {
        super.onPause();
        Voice.stopListen();
        if (web != null) web.onPause();
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (web != null) web.onResume();
    }

    @Override
    protected void onDestroy() {
        if (web != null) {
            web.loadUrl("about:blank");
            web.destroy();
        }
        super.onDestroy();
    }
}
