package mx.zarxus.akari;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.os.SystemClock;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.View;

/**
 * Code-drawn HOME aperture. It does not replace applications with web pages:
 * this view is only the animated second layer of AKARI's launcher.
 */
public class PortalRiftView extends View {
    public static final int ACTION_OUTFIT = 0;
    public static final int ACTION_SCENES = 1;
    public static final int ACTION_APPS = 2;
    public static final int ACTION_MUSIC = 3;
    public static final int ACTION_POSE = 4;

    public interface Listener { void onPortalAction(int action); }

    private static final int[] ACCENTS = {
            0xFF2EF0FF, 0xFFFF2ED9, 0xFFFFC857, 0xFFFF496C
    };
    private static final int[] SECONDARY = {
            0xFFFF2ED9, 0xFF9B7BFF, 0xFFFF6B9D, 0xFF2EF0FF
    };

    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint fill = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Path path = new Path();
    private Listener listener;
    private float progress;
    private float phase;
    private float pulse;
    private float pulseX;
    private float pulseY;
    private float downX;
    private float downY;
    private long lastFrame;
    private int style;
    private boolean running;

    public PortalRiftView(Context context) { this(context, null); }

    public PortalRiftView(Context context, AttributeSet attrs) {
        super(context, attrs);
        line.setStyle(Paint.Style.STROKE);
        line.setStrokeCap(Paint.Cap.ROUND);
        fill.setStyle(Paint.Style.FILL);
        setClickable(true);
        setFocusable(true);
        setContentDescription("Portal RIFT de AKARI. Usa los bordes para vestuario, escenas, aplicaciones y música.");
    }

    public void setListener(Listener value) { listener = value; }

    public void setProgress(float value) {
        progress = clamp(value, 0f, 1f);
        if (progress > 0f && getVisibility() != VISIBLE) setVisibility(VISIBLE);
        invalidate();
    }

    public float getProgress() { return progress; }

    public void setStyle(int value) {
        style = Math.max(0, Math.min(3, value));
        invalidate();
    }

    public int getAccentColor() { return ACCENTS[style]; }

    public void pulse(float x, float y) {
        pulseX = x;
        pulseY = y;
        pulse = 1f;
        invalidate();
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        running = getWindowVisibility() == VISIBLE;
        lastFrame = 0L;
    }

    @Override protected void onDetachedFromWindow() {
        running = false;
        super.onDetachedFromWindow();
    }

    @Override protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        running = visibility == VISIBLE;
        lastFrame = 0L;
        if (running && progress > 0f) postInvalidateOnAnimation();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (progress <= .001f) return;

        long now = SystemClock.uptimeMillis();
        float dt = lastFrame == 0L ? .016f : Math.min(.05f, (now - lastFrame) / 1000f);
        lastFrame = now;
        phase += dt * (.75f + Prefs.motionScale() * .45f + Prefs.heat() / 180f);
        pulse = Math.max(0f, pulse - dt * 1.45f);

        final float w = getWidth();
        final float h = getHeight();
        final int accent = ACCENTS[style];
        final int secondary = SECONDARY[style];
        canvas.drawColor(Color.argb((int) (152 * progress), 2, 3, 12));

        drawGrid(canvas, w, h, accent);
        drawDiagonalShutters(canvas, w, h, accent, secondary);
        drawCore(canvas, w, h, accent, secondary);

        if (pulse > .01f) {
            line.setColor(withAlpha(secondary, (int) (190 * pulse)));
            line.setStrokeWidth(dp(1.4f + pulse * 1.8f));
            float radius = dp(24f + (1f - pulse) * 120f);
            canvas.drawCircle(pulseX, pulseY, radius, line);
            canvas.drawCircle(pulseX, pulseY, radius * .56f, line);
        }

        if (running && isShown() && progress > .001f) {
            if (Prefs.motionLevel() == 0) postInvalidateDelayed(34L);
            else postInvalidateOnAnimation();
        }
    }

    private void drawGrid(Canvas canvas, float w, float h, int accent) {
        line.setColor(withAlpha(accent, (int) (34 * progress)));
        line.setStrokeWidth(dp(.65f));
        float spacing = dp(36f);
        float drift = (phase * dp(8f)) % spacing;
        for (float x = -h + drift; x < w + h; x += spacing) {
            canvas.drawLine(x, 0f, x - h * .32f, h, line);
        }
        for (float y = drift; y < h; y += spacing) canvas.drawLine(0f, y, w, y, line);
    }

    private void drawDiagonalShutters(Canvas canvas, float w, float h, int accent, int secondary) {
        float open = ease(progress);
        float cut = w * (.52f - open * .44f);
        float slant = h * .13f;

        fill.setColor(withAlpha(0xFF070812, (int) (218 * (1f - open) + 22 * open)));
        path.reset();
        path.moveTo(0f, 0f);
        path.lineTo(cut + slant, 0f);
        path.lineTo(cut - slant, h);
        path.lineTo(0f, h);
        path.close();
        canvas.drawPath(path, fill);

        path.reset();
        path.moveTo(w, 0f);
        path.lineTo(w - cut + slant, 0f);
        path.lineTo(w - cut - slant, h);
        path.lineTo(w, h);
        path.close();
        canvas.drawPath(path, fill);

        line.setStrokeWidth(dp(2.2f));
        line.setColor(withAlpha(accent, (int) (205 * progress)));
        canvas.drawLine(cut + slant, 0f, cut - slant, h, line);
        line.setColor(withAlpha(secondary, (int) (175 * progress)));
        canvas.drawLine(w - cut + slant, 0f, w - cut - slant, h, line);
    }

    private void drawCore(Canvas canvas, float w, float h, int accent, int secondary) {
        float cx = w * .5f;
        float cy = h * .47f;
        float breathe = (float) Math.sin(phase * 2.1f)
                * dp(3f + Prefs.heat() * .025f) * Prefs.motionScale();
        float radius = dp(58f) + progress * Math.min(w, h) * .31f + breathe;

        line.setStyle(Paint.Style.STROKE);
        line.setStrokeWidth(dp(1.2f));
        line.setColor(withAlpha(accent, (int) (116 * progress)));
        canvas.drawCircle(cx, cy, radius, line);
        line.setColor(withAlpha(secondary, (int) (92 * progress)));
        canvas.drawCircle(cx, cy, radius * .82f, line);

        canvas.save();
        canvas.rotate(phase * 12f, cx, cy);
        for (int i = 0; i < 8; i++) {
            float a = (float) Math.toRadians(i * 45);
            float x1 = cx + (float) Math.cos(a) * radius;
            float y1 = cy + (float) Math.sin(a) * radius;
            float x2 = cx + (float) Math.cos(a) * (radius + dp(14f));
            float y2 = cy + (float) Math.sin(a) * (radius + dp(14f));
            canvas.drawLine(x1, y1, x2, y2, line);
        }
        canvas.restore();
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        if (progress < .93f) return false;
        if (event.getActionMasked() == MotionEvent.ACTION_DOWN) {
            downX = event.getX();
            downY = event.getY();
            pulse(downX, downY);
            return true;
        }
        if (event.getActionMasked() == MotionEvent.ACTION_UP) {
            float x = event.getX();
            float y = event.getY();
            if (Math.hypot(x - downX, y - downY) > dp(28f)) return true;
            performClick();
            if (listener == null) return true;
            if (y < getHeight() * .29f) listener.onPortalAction(ACTION_OUTFIT);
            else if (y > getHeight() * .72f) listener.onPortalAction(ACTION_MUSIC);
            else if (x < getWidth() * .30f) listener.onPortalAction(ACTION_SCENES);
            else if (x > getWidth() * .70f) listener.onPortalAction(ACTION_APPS);
            else listener.onPortalAction(ACTION_POSE);
            return true;
        }
        return true;
    }

    @Override public boolean performClick() {
        super.performClick();
        return true;
    }

    private int withAlpha(int color, int alpha) {
        return (Math.max(0, Math.min(255, alpha)) << 24) | (color & 0x00FFFFFF);
    }

    private float ease(float value) {
        return 1f - (float) Math.pow(1f - value, 3);
    }

    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }

    private float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
