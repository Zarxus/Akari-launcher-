package mx.zarxus.akari;

import android.app.Activity;
import android.hardware.GeomagneticField;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.os.Bundle;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class CompassActivity extends Activity implements SensorEventListener {
    private SensorManager sensors;
    private Sensor rotation;
    private Sensor accelerometer;
    private Sensor magnetometer;
    private final float[] acceleration = new float[3];
    private final float[] magnetic = new float[3];
    private boolean haveAcceleration;
    private boolean haveMagnetic;
    private CompassView dial;
    private AkariAvatarView avatar;
    private TextView headingText;
    private TextView meta;
    private TextView state;
    private TextView akariLine;
    private float declination;
    private float lastTrueHeading;
    private int lastSector = -1;
    private int sensorAccuracy = SensorManager.SENSOR_STATUS_UNRELIABLE;
    private boolean frozen;
    private long lastFeedback;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_compass);
        Insets.attach(this, findViewById(R.id.compassContent));
        SoundEngine.init(this);
        sensors = (SensorManager) getSystemService(SENSOR_SERVICE);
        rotation = sensors == null ? null : sensors.getDefaultSensor(Sensor.TYPE_ROTATION_VECTOR);
        accelerometer = sensors == null ? null : sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        magnetometer = sensors == null ? null : sensors.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD);
        GeomagneticField field = new GeomagneticField((float) Prefs.lat(), (float) Prefs.lon(),
                0f, System.currentTimeMillis());
        declination = field.getDeclination();

        dial = findViewById(R.id.compassDial);
        avatar = findViewById(R.id.compassAvatar);
        headingText = findViewById(R.id.compassHeading);
        meta = findViewById(R.id.compassMeta);
        state = findViewById(R.id.compassState);
        akariLine = findViewById(R.id.compassAkariLine);
        avatar.setHeat(Prefs.heat());
        avatar.setBond(Prefs.bond());

        findViewById(R.id.btnBack).setOnClickListener(v -> {
            SoundEngine.back();
            finish();
        });
        findViewById(R.id.btnCalibrate).setOnClickListener(v -> showCalibration());
        dial.setOnClickListener(v -> {
            frozen = !frozen;
            SoundEngine.compass();
            Haptics.tap(this);
            state.setText(frozen ? "VECTOR FIJADO · toca para reanudar" : sensorState());
            akariLine.setText(frozen
                    ? "Fijé este rumbo. Puedes mover el teléfono sin perder la lectura."
                    : "Seguimiento reactivado. Mantén el teléfono lejos de metal y sigue el vector.");
        });
        dial.setOnLongClickListener(v -> {
            showCalibration();
            return true;
        });
        avatar.setListener(new AkariAvatarView.Listener() {
            @Override public void onBodyTouch(AkariAvatarView.Zone zone, float y, boolean hold) {
                Prefs.addBond(1);
                Haptics.press(CompassActivity.this);
                akariLine.setText("Estoy orientada contigo: " + CompassView.direction(lastTrueHeading)
                        + " a " + Math.round(lastTrueHeading) + " grados.");
            }
            @Override public void onGesture(AkariAvatarView.Gesture gesture) {
                akariLine.setText("El gesto mueve mi cuerpo; la aguja conserva el norte.");
            }
            @Override public void onDoubleTap() { frozen = !frozen; }
            @Override public void onScale(float scale) { }
        });

        meta.setText(String.format(Locale.getDefault(),
                "DECLINACIÓN %+.1f° · %.4f, %.4f", declination, Prefs.lat(), Prefs.lon()));
        state.setText(sensorState());
    }

    @Override protected void onResume() {
        super.onResume();
        if (sensors == null) return;
        if (rotation != null) {
            sensors.registerListener(this, rotation, SensorManager.SENSOR_DELAY_GAME);
        } else {
            if (accelerometer != null) {
                sensors.registerListener(this, accelerometer, SensorManager.SENSOR_DELAY_GAME);
            }
            if (magnetometer != null) {
                sensors.registerListener(this, magnetometer, SensorManager.SENSOR_DELAY_GAME);
            }
        }
        state.setText(sensorState());
    }

    @Override protected void onPause() {
        if (sensors != null) sensors.unregisterListener(this);
        super.onPause();
    }

    @Override public void onSensorChanged(SensorEvent event) {
        if (frozen) return;
        float azimuth;
        if (event.sensor.getType() == Sensor.TYPE_ROTATION_VECTOR) {
            float[] matrix = new float[9];
            float[] orientation = new float[3];
            SensorManager.getRotationMatrixFromVector(matrix, event.values);
            SensorManager.getOrientation(matrix, orientation);
            azimuth = (float) Math.toDegrees(orientation[0]);
        } else {
            if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
                lowPass(event.values, acceleration);
                haveAcceleration = true;
            } else if (event.sensor.getType() == Sensor.TYPE_MAGNETIC_FIELD) {
                lowPass(event.values, magnetic);
                haveMagnetic = true;
            }
            if (!haveAcceleration || !haveMagnetic) return;
            float[] matrix = new float[9];
            float[] inclination = new float[9];
            if (!SensorManager.getRotationMatrix(matrix, inclination, acceleration, magnetic)) return;
            float[] orientation = new float[3];
            SensorManager.getOrientation(matrix, orientation);
            azimuth = (float) Math.toDegrees(orientation[0]);
        }
        float trueHeading = normalize(azimuth + declination);
        lastTrueHeading = trueHeading;
        dial.setHeading(trueHeading);
        headingText.setText(String.format(Locale.getDefault(), "%s  ·  %03d°",
                CompassView.direction(trueHeading), Math.round(trueHeading) % 360));
        updateSector(trueHeading);
    }

    private void updateSector(float heading) {
        int sector = Math.round(heading / 45f) % 8;
        if (sector == lastSector) return;
        lastSector = sector;
        String[] lines = {
                "Norte fijado. Éste es tu eje de referencia.",
                "Noreste. La aguja ya compensó la declinación local.",
                "Este. El sol nace de este lado; la hora exacta está en HOME.",
                "Sureste. Movimiento limpio, lectura estable.",
                "Sur. Media vuelta respecto al norte verdadero.",
                "Suroeste. Revisa la precisión antes de registrar evidencia.",
                "Oeste. El arco solar termina de este lado.",
                "Noroeste. Estás cerrando el círculo hacia el norte."
        };
        akariLine.setText(lines[sector]);
        avatar.impulse(sector % 2 == 0 ? 30f : -30f, -25f);
        long now = System.currentTimeMillis();
        if (now - lastFeedback > 700L) {
            lastFeedback = now;
            SoundEngine.compass();
        }
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {
        sensorAccuracy = accuracy;
        if (!frozen) state.setText(sensorState());
    }

    private String sensorState() {
        if (rotation == null && (accelerometer == null || magnetometer == null)) {
            return "ESTE TELÉFONO NO EXPONE SENSOR DE ORIENTACIÓN";
        }
        String accuracy = sensorAccuracy == SensorManager.SENSOR_STATUS_ACCURACY_HIGH ? "ALTA"
                : sensorAccuracy == SensorManager.SENSOR_STATUS_ACCURACY_MEDIUM ? "MEDIA"
                : sensorAccuracy == SensorManager.SENSOR_STATUS_ACCURACY_LOW ? "BAJA" : "CALIBRAR";
        return "SEGUIMIENTO EN VIVO · PRECISIÓN " + accuracy;
    }

    private void showCalibration() {
        SoundEngine.click();
        Haptics.tap(this);
        akariLine.setText("Calibra dibujando un ocho en el aire, y aléjalo de imanes o metal.");
        Toast.makeText(this, "Mueve el teléfono en forma de ∞", Toast.LENGTH_LONG).show();
    }

    private static void lowPass(float[] input, float[] output) {
        for (int i = 0; i < 3; i++) output[i] += .16f * (input[i] - output[i]);
    }

    private static float normalize(float value) {
        value %= 360f;
        return value < 0 ? value + 360f : value;
    }
}
