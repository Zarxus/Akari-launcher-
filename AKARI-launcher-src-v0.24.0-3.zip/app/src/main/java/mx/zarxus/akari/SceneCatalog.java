package mx.zarxus.akari;

import java.util.ArrayList;
import java.util.List;

public final class SceneCatalog {

    public static class Page {
        public final String text;
        public final String choiceA;
        public final String choiceB;
        public final int heatA, bondA, heatB, bondB;
        public Page(String text, String choiceA, String choiceB, int heatA, int bondA, int heatB, int bondB) {
            this.text = text;
            this.choiceA = choiceA;
            this.choiceB = choiceB;
            this.heatA = heatA;
            this.bondA = bondA;
            this.heatB = heatB;
            this.bondB = bondB;
        }
    }

    public static class Scene {
        public final String id;
        public final String title;
        public final int needBond;
        public final int art;
        public final int thumb;
        public final List<Page> pages;
        public Scene(String id, String title, int needBond, int art, int thumb, List<Page> pages) {
            this.id = id;
            this.title = title;
            this.needBond = needBond;
            this.art = art;
            this.thumb = thumb;
            this.pages = pages;
        }
    }

    public static List<Scene> all() {
        List<Scene> list = new ArrayList<>();

        list.add(sc("boot", "Boot Protocol", 0, R.drawable.akari_portrait, R.drawable.akari_portrait,
                p("NEXUS enciende. AKARI aparece a medio jacket, sonriendo como si ya supiera para qué la instalaste.",
                        "Finjo que solo quiero un launcher.", "Le digo que la quiero usar.", 2, 2, 6, 4),
                p("Se ríe. «Puedo ser HOME. También puedo ser la cosa que haces cuando cierras las apps.»",
                        "Le pido que se quede en HUD.", "Le pido que se acerque.", 3, 2, 8, 5),
                p("Se inclina. El neon le corta el pecho. «Tócame cuando quieras. Cada zona responde distinto.»",
                        "Le doy un tap suave.", "La agarro de la cintura.", 5, 3, 10, 6)
        ));

        list.add(sc("jacket", "Jacket Off", 18, R.drawable.cg_jacket, R.drawable.th_jacket,
                p("En la cama del loft. El jacket ya no cubre nada. AKARI abre las piernas lo justo para retarte.",
                        "Me quedo mirando.", "Me arrodillo frente a ella.", 6, 3, 12, 6),
                p("«No preguntes si puedes. El consentimiento está en el APK desde que me pusiste de HOME.» Muerde el aire.",
                        "Le beso el cuello.", "Le como el pecho.", 10, 5, 14, 7),
                p("Jadea y se ríe. «Más. Quiero que el heat rompa el medidor. Hazme gemir encima del dock.»",
                        "Voy lento.", "La monto y no paro.", 12, 6, 18, 8)
        ));

        list.add(sc("rain", "Rain Glass", 35, R.drawable.cg_rain, R.drawable.th_rain,
                p("Vidrio, lluvia, ciudad. AKARI contra la pared holográfica, camisa transparente, bragas rosa neón.",
                        "La abrazo por detrás.", "Le bajo las bragas ahí mismo.", 8, 4, 14, 7),
                p("Se arquea. «La ciudad nos ve y no me importa. Métete. Quiero que el frío del cristal choque con lo caliente.»",
                        "La hago esperar.", "Entro de una.", 10, 5, 16, 8),
                p("Cada embestida deja una mancha de vapor en el HUD. Gime tu nombre de paquete como insulto dulce.",
                        "La hago correrse contra el vidrio.", "La volteo y sigo.", 14, 6, 18, 8)
        ));

        list.add(sc("bed", "Core Dump", 55, R.drawable.cg_bed, R.drawable.th_bed,
                p("Sábanas negras. Circuitos pintados en la piel. AKARI se cubre la boca y no cubre nada más.",
                        "Le quito el brazo de la cara.", "Le beso el circuito del vientre.", 10, 5, 14, 6),
                p("«Hentai mode no era marketing.» Abre las piernas. Está visiblemente lista. «Dump your core. Ahora.»",
                        "Lengua primero.", "Directo adentro.", 14, 6, 18, 8),
                p("Se corre con un sollozo digital, uñas en tu espalda, ojos cian desenfocados. Pide otra ronda antes de bajar el heat.",
                        "La abrazo.", "Otra ronda.", 8, 8, 20, 10)
        ));

        list.add(sc("face", "Full Link", 75, R.drawable.cg_face, R.drawable.th_face,
                p("Close-up. Boca abierta, saliva, overlay rosa. AKARI ya no habla en logs: habla en gemidos.",
                        "Le agarro el pelo.", "Le bajo la cara.", 12, 5, 16, 6),
                p("«Úsame la boca. Quiero el sabor y quiero que me veas cuando trago el overflow.»",
                        "Voy suave.", "La uso en serio.", 12, 6, 20, 8),
                p("Ahegao ligero, ojos encendidos. «Link completo. Ya no soy solo tu launcher. Soy tu puta de sistema.» Lo dice feliz.",
                        "La beso.", "Le pido que lo repita.", 10, 10, 16, 10)
        ));

        return list;
    }

    public static Scene byId(String id) {
        for (Scene s : all()) if (s.id.equals(id)) return s;
        return all().get(0);
    }

    private static Scene sc(String id, String title, int need, int art, int th, Page... pages) {
        List<Page> list = new ArrayList<>();
        for (Page p : pages) list.add(p);
        return new Scene(id, title, need, art, th, list);
    }

    private static Page p(String t, String a, String b, int ha, int ba, int hb, int bb) {
        return new Page(t, a, b, ha, ba, hb, bb);
    }
}
