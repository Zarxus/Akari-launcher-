package mx.zarxus.akari;

import android.Manifest;
import android.animation.Animator;
import android.animation.AnimatorListenerAdapter;
import android.animation.ValueAnimator;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.os.Build;
import android.graphics.drawable.ColorDrawable;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.Gravity;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.view.animation.DecelerateInterpolator;
import android.view.animation.OvershootInterpolator;
import android.view.inputmethod.EditorInfo;
import android.view.inputmethod.InputMethodManager;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class HomeActivity extends Activity {
    private final Handler handler = new Handler(Looper.getMainLooper());
    private TextView clock, dateLine, akariLine, bondValue, heatValue, sysStatus;
    private TextView weatherLine, newsTicker, batteryLine, alarmMini;
    private TextView notificationPill, quickNotification, notificationPeekApp, notificationPeekText;
    private ProgressBar bondBar, heatBar;
    private LinearLayout dockRow, quickRow;
    private AkariAvatarView akariAvatar;
    private View dialogueBubble;
    private View content;
    private View heatVignette;
    private View dayTint;
    private View notificationPeek;
    private TextView deckHandle;
    private View toolScroller, primaryActionsRow, quickRowSys, quickScroller;
    private PortalRiftView riftView;
    private View riftHud, riftHandle;
    private TextView riftTitle, riftState, riftLine;
    private ValueAnimator riftAnimator;
    private boolean riftOpen;
    private boolean riftTransition;
    private HomeEdgeGestureView edgeGesture;
    private View layerDim, layerApps, layerAkari, layerSignal, layerTools;
    private ImageView layerAppsArt, layerAkariArt, layerSignalArt, layerToolsArt;
    private EditText layerAppsSearch;
    private GridView layerAppsGrid;
    private AppAdapter layerAppsAdapter;
    private TextView layerAppsMeta, layerAkariState, layerAkariQuote, layerAkariMeters;
    private TextView layerSignalCount, layerSignalWeather;
    private LinearLayout layerSignalList;
    private ValueAnimator layerAnimator;
    private int activeLayerEdge = HomeEdgeGestureView.NONE;
    private float layerProgress;
    private boolean layerThresholdPulse;
    private int layerAkariArtIndex;
    private EditText searchBar;
    private TiltParallax tilt;
    private long lastClock;
    private long lastHud;
    private Weather weather = new Weather();
    private SolarArcView solarArc;
    private final BodyPhysics body = new BodyPhysics();
    private ParticleView particles;
    private LinearLayout assistRow;
    private TextView assistHint;
    private List<AppInfo> assist = java.util.Collections.emptyList();
    private List<AppInfo> defaultAssist = java.util.Collections.emptyList();
    private List<AppInfo> allApps = java.util.Collections.emptyList();
    private int assistIndex;
    private int lastBatt = -1;
    private int lastHour = -1;
    private long lastTickNs;
    private long lastNotificationHud;
    private boolean notificationReceiverRegistered;
    private boolean searchPreviewActive;
    private boolean weatherLoading;
    private String pendingSearch = "";
    private int lastPhase = -1;
    private float peekDownX;
    private float peekDownY;

    private final Runnable searchPreview = new Runnable() {
        @Override public void run() { updateSearchPreview(pendingSearch); }
    };

    private final Runnable hideNotificationPeek = new Runnable() {
        @Override public void run() {
            if (notificationPeek == null || notificationPeek.getVisibility() != View.VISIBLE) return;
            notificationPeek.animate().alpha(0f).translationY(-18f).setDuration(180)
                    .withEndAction(new Runnable() {
                        @Override public void run() {
                            notificationPeek.setVisibility(View.GONE);
                            notificationPeek.setAlpha(1f);
                            notificationPeek.setTranslationY(0f);
                            notificationPeek.setTranslationX(0f);
                            notificationPeek.setRotation(0f);
                        }
                    }).start();
        }
    };

    private final BroadcastReceiver notificationChanges = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            refreshNotificationStatus();
            if (intent == null || !"posted".equals(intent.getStringExtra(AkariNotificationService.EXTRA_EVENT))) return;
            String app = intent.getStringExtra(AkariNotificationService.EXTRA_APP);
            String title = intent.getStringExtra(AkariNotificationService.EXTRA_TITLE);
            String kind = intent.getStringExtra(AkariNotificationService.EXTRA_KIND);
            onAkariNotification(app, title, kind);
        }
    };

    private final Runnable frame = new Runnable() {
        @Override public void run() {
            long now = System.currentTimeMillis();
            long clockRate = Prefs.showSeconds() ? 1_000L : 15_000L;
            if (now - lastClock >= clockRate) {
                updateClock();
                lastClock = now;
            }
            if (now - lastHud >= 30_000) {
                refreshHud();
                lastHud = now;
            }
            if (now - lastNotificationHud >= 5_000) {
                refreshNotificationStatus();
                lastNotificationHud = now;
            }
            long ns = System.nanoTime();
            float dt = lastTickNs == 0 ? 0.016f : (ns - lastTickNs) / 1_000_000_000f;
            lastTickNs = ns;
            if (dt > 0.05f) dt = 0.05f;
            body.tick(dt);
            handler.postDelayed(this, Prefs.physics() ? (Prefs.motionLevel() == 0 ? 33 : 16) : 1_000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WALLPAPER);
        getWindow().setBackgroundDrawable(new ColorDrawable(android.graphics.Color.TRANSPARENT));
        setContentView(R.layout.activity_home);
        content = findViewById(R.id.content);
        Insets.attach(this, content);
        content.requestFocus();
        SoundEngine.init(this);

        clock = findViewById(R.id.clock);
        dateLine = findViewById(R.id.dateLine);
        akariLine = findViewById(R.id.akariLine);
        bondValue = findViewById(R.id.bondValue);
        heatValue = findViewById(R.id.heatValue);
        bondBar = findViewById(R.id.bondBar);
        heatBar = findViewById(R.id.heatBar);
        dockRow = findViewById(R.id.dockRow);
        quickRow = findViewById(R.id.quickRow);
        akariAvatar = findViewById(R.id.akariAvatar);
        dialogueBubble = findViewById(R.id.dialogueBubble);
        heatVignette = findViewById(R.id.heatVignette);
        dayTint = findViewById(R.id.dayTint);
        sysStatus = findViewById(R.id.sysStatus);
        weatherLine = findViewById(R.id.weatherLine);
        solarArc = findViewById(R.id.solarArc);
        alarmMini = findViewById(R.id.alarmMini);
        newsTicker = findViewById(R.id.newsTicker);
        batteryLine = findViewById(R.id.batteryLine);
        notificationPill = findViewById(R.id.notificationPill);
        quickNotification = findViewById(R.id.qsNotif);
        notificationPeek = findViewById(R.id.notificationPeek);
        notificationPeekApp = findViewById(R.id.notificationPeekApp);
        notificationPeekText = findViewById(R.id.notificationPeekText);
        positionNotificationPeek();
        searchBar = findViewById(R.id.searchBar);
        particles = findViewById(R.id.particles);
        assistRow = findViewById(R.id.assistRow);
        assistHint = findViewById(R.id.assistHint);
        deckHandle = findViewById(R.id.deckHandle);
        toolScroller = findViewById(R.id.toolScroller);
        primaryActionsRow = findViewById(R.id.primaryActionsRow);
        quickRowSys = findViewById(R.id.quickRowSys);
        quickScroller = findViewById(R.id.quickScroller);
        riftView = findViewById(R.id.riftView);
        riftHud = findViewById(R.id.riftHud);
        riftHandle = findViewById(R.id.riftHandle);
        riftTitle = findViewById(R.id.riftTitle);
        riftState = findViewById(R.id.riftState);
        riftLine = findViewById(R.id.riftLine);
        edgeGesture = findViewById(R.id.edgeGesture);
        layerDim = findViewById(R.id.layerDim);
        layerApps = findViewById(R.id.layerApps);
        layerAkari = findViewById(R.id.layerAkari);
        layerSignal = findViewById(R.id.layerSignal);
        layerTools = findViewById(R.id.layerTools);
        layerAppsArt = findViewById(R.id.layerAppsArt);
        layerAkariArt = findViewById(R.id.layerAkariArt);
        layerSignalArt = findViewById(R.id.layerSignalArt);
        layerToolsArt = findViewById(R.id.layerToolsArt);
        layerAppsSearch = findViewById(R.id.layerAppsSearch);
        layerAppsGrid = findViewById(R.id.layerAppsGrid);
        layerAppsMeta = findViewById(R.id.layerAppsMeta);
        layerAkariState = findViewById(R.id.layerAkariState);
        layerAkariQuote = findViewById(R.id.layerAkariQuote);
        layerAkariMeters = findViewById(R.id.layerAkariMeters);
        layerSignalCount = findViewById(R.id.layerSignalCount);
        layerSignalWeather = findViewById(R.id.layerSignalWeather);
        layerSignalList = findViewById(R.id.layerSignalList);
        body.attach(akariAvatar);

        wireNotificationPeek();
        deckHandle.setOnClickListener(v -> toggleCommandDeck());
        DockMotion.bind(deckHandle);
        applyCommandDeck(false);

        akariLine.setText(AkariLines.next());
        if (findViewById(R.id.akariRole) != null) ((TextView) findViewById(R.id.akariRole)).setText(Identity.rank() + " · " + Identity.title());
        wireEdgeLayers();
        wireRift();
        wireCompanion();
        wireSearch();
        wireClicks();
        bindControlMotion();

        tilt = new TiltParallax(this);
        tilt.attachAvatar(akariAvatar);
        maybeDaily();
        updateClock();
        refreshMeters();
        refreshHud();
        loadWeather(false);
        loadNews(false);
        refreshAlarm();
    }

    private void wireClicks() {
        findViewById(R.id.btnDrawer).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.open();
                startActivity(new Intent(HomeActivity.this, StudioActivity.class));
            }
        });
        findViewById(R.id.btnSettings).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.click();
                startActivity(new Intent(HomeActivity.this, SettingsActivity.class));
            }
        });
        findViewById(R.id.btnSettings).setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                startActivity(new Intent(HomeActivity.this, PermsActivity.class));
                return true;
            }
        });
        findViewById(R.id.btnEroge).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.open();
                startActivity(new Intent(HomeActivity.this, ErogeHubActivity.class));
            }
        });
        findViewById(R.id.btnGallery).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.open();
                startActivity(new Intent(HomeActivity.this, GalleryActivity.class));
            }
        });
        findViewById(R.id.btnNews).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.open();
                startActivity(new Intent(HomeActivity.this, NewsActivity.class));
            }
        });
        findViewById(R.id.btnNews).setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                Launcher.openPortal(HomeActivity.this, "https://news.google.com/?hl=es-419&gl=MX&ceid=MX:es-419", "News");
                return true;
            }
        });
        findViewById(R.id.btnStudio).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, StudioActivity.class));
            }
        });
        findViewById(R.id.btnDossier).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, DossierActivity.class));
            }
        });
        findViewById(R.id.btnCalc).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, CalcActivity.class));
            }
        });
        findViewById(R.id.btnPortalHome).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Launcher.openPortal(HomeActivity.this, "https://www.google.com", "Portal");
            }
        });
        findViewById(R.id.btnArcade).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, ArcadeActivity.class));
            }
        });
        findViewById(R.id.btnPulse).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, PulseActivity.class));
            }
        });
        findViewById(R.id.btnLounge).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, LoungeActivity.class));
            }
        });
        findViewById(R.id.btnChess).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, ChessActivity.class));
            }
        });
        findViewById(R.id.btnAlarm).setOnClickListener(v -> {
            SoundEngine.open();
            startActivity(new Intent(this, AlarmActivity.class));
        });
        findViewById(R.id.btnCompass).setOnClickListener(v -> {
            SoundEngine.open();
            startActivity(new Intent(this, CompassActivity.class));
        });
        alarmMini.setOnClickListener(v -> startActivity(new Intent(this, AlarmActivity.class)));
        findViewById(R.id.btnSpeak).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Voice.init(HomeActivity.this);
                String line = akariLine.getText() == null ? "" : akariLine.getText().toString();
                String cache = Prefs.newsCache();
                if (cache != null && !cache.isEmpty()) {
                    Voice.speak("Te leo las noticias y lo que acabo de decir.");
                    Voice.speakQueue(line);
                    Voice.readNews(NewsItem.parseRss(cache));
                } else {
                    Voice.speak(line.isEmpty() ? "Sistema de voz listo. Dime abre y el nombre de una app." : line);
                }
            }
        });
        findViewById(R.id.btnSpeak).setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                Voice.stop();
                say("Silencio. Cuando quieras, VOZ otra vez.");
                return true;
            }
        });
        findViewById(R.id.btnMic).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startListen(); }
        });
        weatherLine.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.click();
                showLine("Actualizo clima, UV y trayectoria solar…", false);
                loadWeather(true);
            }
        });
        solarArc.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.click();
                if (weather.hasSolar()) say(weather.solarNarration());
                else {
                    showLine("Aún no tengo una lectura solar válida. Vuelvo a sincronizar.", false);
                    loadWeather(true);
                }
                if (akariAvatar != null) akariAvatar.impulse(18f, -48f);
            }
        });
        newsTicker.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, NewsActivity.class));
            }
        });
        clock.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Prefs.setShowSeconds(!Prefs.showSeconds());
                updateClock();
                say(SpeechStyle.naturalTime());
                body.jiggle();
                if (particles != null) particles.burst(v.getWidth() / 2f, 80);
            }
        });
        batteryLine.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                refreshHud();
                sayBatt(true);
            }
        });
        findViewById(R.id.topBar).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openNotificationCenter(); }
        });
        notificationPill.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openNotificationCenter(); }
        });
        findViewById(R.id.qsWifi).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { SoundEngine.click(); QuickActions.wifi(HomeActivity.this); }
        });
        findViewById(R.id.qsBt).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { SoundEngine.click(); QuickActions.bluetooth(HomeActivity.this); }
        });
        findViewById(R.id.qsTorch).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.click();
                boolean on = QuickActions.toggleTorch(HomeActivity.this);
                ((TextView) v).setText(on ? "Luz*" : "Luz");
            }
        });
        findViewById(R.id.qsPhone).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { SoundEngine.click(); QuickActions.phone(HomeActivity.this); }
        });
        findViewById(R.id.qsNotif).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openNotificationCenter(); }
        });
        findViewById(R.id.qsVol).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, VolumeActivity.class));
            }
        });
        findViewById(R.id.qsLock).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(HomeActivity.this, LockActivity.class));
            }
        });
    }

    private void bindControlMotion() {
        int[] ids={R.id.btnDrawer,R.id.btnEroge,R.id.btnGallery,R.id.btnNews,R.id.btnSpeak,R.id.btnMic,
                R.id.btnStudio,R.id.btnDossier,R.id.btnCalc,R.id.btnAlarm,R.id.btnCompass,R.id.btnPortalHome,R.id.btnArcade,
                R.id.btnPulse,R.id.btnLounge,R.id.btnChess,R.id.qsWifi,R.id.qsBt,R.id.qsTorch,R.id.qsPhone,
                R.id.qsNotif,R.id.qsVol,R.id.qsLock};
        for(int id:ids) DockMotion.bind(findViewById(id));
    }

    private void wireSearch() {
        searchBar.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId == EditorInfo.IME_ACTION_SEARCH || actionId == EditorInfo.IME_ACTION_DONE) {
                    submitSearch(v.getText().toString());
                    return true;
                }
                return false;
            }
        });
        searchBar.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                pendingSearch = s.toString().trim();
                handler.removeCallbacks(searchPreview);
                handler.postDelayed(searchPreview, pendingSearch.isEmpty() ? 0L : 120L);
            }
        });
        searchBar.setOnFocusChangeListener((view, focused) -> {
            if (focused && !Prefs.commandDeckExpanded()) {
                Prefs.setCommandDeckExpanded(true);
                applyCommandDeck(true);
            }
        });
    }

    private void submitSearch(String q) {
        if (q == null) return;
        q = q.trim();
        showLine(AkariNarrator.search(q), true);
        SoundEngine.soft();
        body.jiggle();
        InputMethodManager keyboard = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (keyboard != null) keyboard.hideSoftInputFromWindow(searchBar.getWindowToken(), 0);
        String command = q.toLowerCase(Locale.ROOT);
        if(command.equals("alarma")||command.equals("despertador")||command.equals("dawn link")){
            startActivity(new Intent(this,AlarmActivity.class));searchBar.setText("");return;
        }
        if (command.equals("brújula") || command.equals("brujula") || command.equals("compass")) {
            startActivity(new Intent(this, CompassActivity.class));
            searchBar.setText("");
            return;
        }
        if (command.equals("avisos") || command.equals("notificaciones") || command.equals("centro akari")) {
            openEdgeLayer(HomeEdgeGestureView.TOP_SIGNAL);
            searchBar.setText("");
            return;
        }
        if (command.equals("apps") || command.equals("aplicaciones") || command.equals("cajón")) {
            openEdgeLayer(HomeEdgeGestureView.LEFT_APPS);
            searchBar.setText("");
            return;
        }
        if (command.equals("akari") || command.equals("persona") || command.equals("personaje")) {
            openEdgeLayer(HomeEdgeGestureView.RIGHT_AKARI);
            searchBar.setText("");
            return;
        }
        if (command.equals("herramientas") || command.equals("control") || command.equals("control deck")) {
            openEdgeLayer(HomeEdgeGestureView.BOTTOM_TOOLS);
            searchBar.setText("");
            return;
        }
        if (command.equals("rift") || command.equals("portal akari") || command.equals("segunda capa")) {
            openRift();
            searchBar.setText("");
            return;
        }
        if (q.isEmpty()) {
            openEdgeLayer(HomeEdgeGestureView.LEFT_APPS);
            return;
        }
        List<AppInfo> hits = AppRepository.filter(AppRepository.loadLaunchable(this), q);
        if (hits.size() == 1) {
            showLine(AkariNarrator.openApp(hits.get(0)), true);
            Launcher.open(this, hits.get(0));
            searchBar.setText("");
            return;
        }
        if (hits.size() > 1) {
            final String filter = q;
            openEdgeLayer(HomeEdgeGestureView.LEFT_APPS);
            handler.postDelayed(() -> {
                layerAppsSearch.setText(filter);
                layerAppsSearch.setSelection(layerAppsSearch.length());
            }, 180L);
            return;
        }
        say("Te lo busco dentro de mí.");
        Launcher.openPortal(this, AppPortals.searchUrl(q), q);
    }

    private void wireEdgeLayers() {
        if (edgeGesture == null) return;
        Insets.attach(this, findViewById(R.id.layerAppsSafe));
        Insets.attach(this, findViewById(R.id.layerAkariSafe));
        Insets.attach(this, findViewById(R.id.layerSignalSafe));
        Insets.attach(this, findViewById(R.id.layerToolsSafe));

        edgeGesture.setListener(new HomeEdgeGestureView.Listener() {
            @Override public void onBegin(int edge) {
                beginEdgeLayer(edge);
            }

            @Override public void onProgress(int edge, float progress) {
                applyEdgeLayerProgress(edge, progress);
            }

            @Override public void onRelease(int edge, float progress, float velocityAlong, boolean open) {
                settleEdgeLayer(edge, open, velocityAlong, true);
            }
        });

        layerAppsAdapter = new AppAdapter(this, R.layout.item_app);
        layerAppsGrid.setAdapter(layerAppsAdapter);
        layerAppsGrid.setEmptyView(null);
        layerAppsGrid.setContentDescription("Aplicaciones instaladas dentro de la ventana HOME. Toca para abrir el APK original.");
        layerAppsGrid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final AppInfo app = layerAppsAdapter.getItem(position);
                DockMotion.launchWave(view);
                showLine(AkariNarrator.openApp(app), true);
                closeEdgeLayer();
                view.postDelayed(new Runnable() {
                    @Override public void run() { Launcher.open(HomeActivity.this, app); }
                }, 145L);
            }
        });
        layerAppsGrid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                final AppInfo app = layerAppsAdapter.getItem(position);
                AppActions.show(HomeActivity.this, app, () -> {
                    allApps = AppRepository.loadLaunchable(HomeActivity.this);
                    renderLayerApps(layerAppsSearch.getText().toString());
                });
                return true;
            }
        });
        layerAppsGrid.setOnScrollListener(new android.widget.AbsListView.OnScrollListener() {
            @Override public void onScrollStateChanged(android.widget.AbsListView view, int scrollState) {
                if (scrollState == SCROLL_STATE_TOUCH_SCROLL) SoundEngine.soft();
            }
            @Override public void onScroll(android.widget.AbsListView view, int firstVisibleItem,
                                           int visibleItemCount, int totalItemCount) {
                if (layerAppsArt != null && layerProgress >= .98f) {
                    layerAppsArt.setTranslationY(-Math.min(dp(34f), firstVisibleItem * dp(2.2f)));
                }
            }
        });
        layerAppsSearch.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) { renderLayerApps(s.toString()); }
        });

        findViewById(R.id.layerAppsClose).setOnClickListener(v -> closeEdgeLayer());
        findViewById(R.id.layerAkariClose).setOnClickListener(v -> closeEdgeLayer());
        findViewById(R.id.layerSignalClose).setOnClickListener(v -> closeEdgeLayer());
        findViewById(R.id.layerToolsClose).setOnClickListener(v -> closeEdgeLayer());
        findViewById(R.id.layerAppsClear).setOnClickListener(v -> {
            SoundEngine.soft();
            layerAppsSearch.setText("");
            hideLayerKeyboard();
        });
        findViewById(R.id.layerAppsStudio).setOnClickListener(v ->
                launchFromLayer(new Intent(HomeActivity.this, StudioActivity.class)));

        findViewById(R.id.layerAkariFace).setOnClickListener(v -> selectLayerAkariArt(0));
        findViewById(R.id.layerAkariRain).setOnClickListener(v -> selectLayerAkariArt(1));
        findViewById(R.id.layerAkariJacket).setOnClickListener(v -> selectLayerAkariArt(2));
        findViewById(R.id.layerAkariRift).setOnClickListener(v -> {
            closeEdgeLayer();
            handler.postDelayed(() -> openRift(), 260L);
        });
        findViewById(R.id.layerAkariScenes).setOnClickListener(v ->
                launchFromLayer(new Intent(HomeActivity.this, ErogeHubActivity.class)));
        findViewById(R.id.layerAkariGallery).setOnClickListener(v ->
                launchFromLayer(new Intent(HomeActivity.this, GalleryActivity.class)));
        layerAkari.setOnClickListener(v -> {
            if (activeLayerEdge != HomeEdgeGestureView.RIGHT_AKARI || layerProgress < .85f) return;
            Prefs.addBond(1);
            layerAkariQuote.setText("Sentí el toque en la lámina. Mi imagen conserva profundidad y la HOME sigue detrás.");
            layerAkariArt.animate().cancel();
            layerAkariArt.animate().scaleX(1.085f).scaleY(1.085f)
                    .translationX(layerAkariArtIndex == 1 ? dp(10f) : -dp(8f))
                    .setDuration(110L).withEndAction(() -> layerAkariArt.animate()
                            .scaleX(1.065f).scaleY(1.065f).translationX(0f).setDuration(260L).start()).start();
            SoundEngine.heat();
            Haptics.press(HomeActivity.this);
            refreshLayerAkari();
        });
        layerAkari.setOnLongClickListener(v -> {
            selectLayerAkariArt((layerAkariArtIndex + 1) % 3);
            return true;
        });

        findViewById(R.id.layerSignalCenter).setOnClickListener(v -> openNotificationCenterFull());
        findViewById(R.id.layerSignalNews).setOnClickListener(v ->
                launchFromLayer(new Intent(HomeActivity.this, NewsActivity.class)));
        findViewById(R.id.layerSignalAlarm).setOnClickListener(v ->
                launchFromLayer(new Intent(HomeActivity.this, AlarmActivity.class)));

        findViewById(R.id.layerToolWifi).setOnClickListener(v -> {
            SoundEngine.click(); QuickActions.wifi(HomeActivity.this);
        });
        findViewById(R.id.layerToolBt).setOnClickListener(v -> {
            SoundEngine.click(); QuickActions.bluetooth(HomeActivity.this);
        });
        findViewById(R.id.layerToolTorch).setOnClickListener(v -> {
            SoundEngine.click();
            boolean on = QuickActions.toggleTorch(HomeActivity.this);
            ((TextView) v).setText(on ? "Linterna ●" : "Linterna");
        });
        findViewById(R.id.layerToolCalc).setOnClickListener(v ->
                launchFromLayer(new Intent(HomeActivity.this, CalcActivity.class)));
        findViewById(R.id.layerToolCompass).setOnClickListener(v ->
                launchFromLayer(new Intent(HomeActivity.this, CompassActivity.class)));
        findViewById(R.id.layerToolAlarm).setOnClickListener(v ->
                launchFromLayer(new Intent(HomeActivity.this, AlarmActivity.class)));
        findViewById(R.id.layerToolMusic).setOnClickListener(v ->
                launchFromLayer(new Intent(HomeActivity.this, LoungeActivity.class)));
        findViewById(R.id.layerToolChess).setOnClickListener(v ->
                launchFromLayer(new Intent(HomeActivity.this, ChessActivity.class)));
        findViewById(R.id.layerToolSettings).setOnClickListener(v ->
                launchFromLayer(new Intent(HomeActivity.this, SettingsActivity.class)));
        findViewById(R.id.layerToolPhone).setOnClickListener(v -> {
            SoundEngine.click(); QuickActions.phone(HomeActivity.this);
        });
        findViewById(R.id.layerToolVolume).setOnClickListener(v ->
                launchFromLayer(new Intent(HomeActivity.this, VolumeActivity.class)));
        findViewById(R.id.layerToolLock).setOnClickListener(v ->
                launchFromLayer(new Intent(HomeActivity.this, LockActivity.class)));

        int[] motion = {R.id.layerAppsClose, R.id.layerAkariClose, R.id.layerSignalClose, R.id.layerToolsClose,
                R.id.layerAppsClear, R.id.layerAppsStudio, R.id.layerAkariFace, R.id.layerAkariRain,
                R.id.layerAkariJacket, R.id.layerAkariRift, R.id.layerAkariScenes, R.id.layerAkariGallery,
                R.id.layerSignalCenter, R.id.layerSignalNews, R.id.layerSignalAlarm, R.id.layerToolWifi,
                R.id.layerToolBt, R.id.layerToolTorch, R.id.layerToolCalc, R.id.layerToolCompass,
                R.id.layerToolAlarm, R.id.layerToolMusic, R.id.layerToolChess, R.id.layerToolSettings,
                R.id.layerToolPhone, R.id.layerToolVolume, R.id.layerToolLock};
        for (int id : motion) DockMotion.bind(findViewById(id));

        if (riftHandle != null) riftHandle.setVisibility(View.GONE);
        edgeGesture.setState(HomeEdgeGestureView.NONE, 0f);
    }

    private void beginEdgeLayer(int edge) {
        if (edge == HomeEdgeGestureView.NONE || riftOpen || riftTransition) return;
        cancelLayerAnimator();
        if (activeLayerEdge != HomeEdgeGestureView.NONE && activeLayerEdge != edge) {
            resetEdgeLayerImmediate();
        }
        activeLayerEdge = edge;
        View layer = layerForEdge(edge);
        if (layer == null) return;
        hideOtherEdgeLayers(layer);
        layer.setVisibility(View.VISIBLE);
        layerDim.setVisibility(View.VISIBLE);
        if (Build.VERSION.SDK_INT >= 28) layer.setAccessibilityPaneTitle(layerName(edge));
        refreshEdgeLayer(edge);
        layerThresholdPulse = layerProgress >= .42f;
        edgeGesture.setState(edge, layerProgress);
        applyEdgeLayerProgress(edge, layerProgress);
        SoundEngine.layerGrab(edge);
        Haptics.press(this);
    }

    private void applyEdgeLayerProgress(int edge, float value) {
        View layer = layerForEdge(edge);
        if (layer == null) return;
        float p = Math.max(0f, Math.min(1f, value));
        layerProgress = p;
        int width = Math.max(1, layer.getWidth() > 0 ? layer.getWidth() : edgeGesture.getWidth());
        int height = Math.max(1, layer.getHeight() > 0 ? layer.getHeight() : edgeGesture.getHeight());
        layer.setTranslationX(0f);
        layer.setTranslationY(0f);
        if (edge == HomeEdgeGestureView.LEFT_APPS) layer.setTranslationX(-width * (1f - p));
        else if (edge == HomeEdgeGestureView.RIGHT_AKARI) layer.setTranslationX(width * (1f - p));
        else if (edge == HomeEdgeGestureView.TOP_SIGNAL) layer.setTranslationY(-height * (1f - p));
        else if (edge == HomeEdgeGestureView.BOTTOM_TOOLS) layer.setTranslationY(height * (1f - p));
        layer.setAlpha(.68f + .32f * p);
        float layerScale = 1.015f - .015f * p;
        layer.setScaleX(layerScale);
        layer.setScaleY(layerScale);
        float angle = 1.15f * (1f - p);
        if (edge == HomeEdgeGestureView.LEFT_APPS || edge == HomeEdgeGestureView.BOTTOM_TOOLS) angle = -angle;
        layer.setRotation(angle);

        ImageView art = artForEdge(edge);
        if (art != null) {
            float imageScale = 1.10f - .035f * p;
            art.setScaleX(imageScale);
            art.setScaleY(imageScale);
            art.setTranslationX(edge == HomeEdgeGestureView.LEFT_APPS ? -dp(34f) * (1f - p)
                    : edge == HomeEdgeGestureView.RIGHT_AKARI ? dp(34f) * (1f - p) : 0f);
            art.setTranslationY(edge == HomeEdgeGestureView.TOP_SIGNAL ? -dp(30f) * (1f - p)
                    : edge == HomeEdgeGestureView.BOTTOM_TOOLS ? dp(30f) * (1f - p) : 0f);
        }
        layerDim.setAlpha(.56f * p);
        content.setAlpha(1f - .22f * p);
        content.setScaleX(1f - .018f * p);
        content.setScaleY(1f - .018f * p);
        content.setTranslationX(edge == HomeEdgeGestureView.LEFT_APPS ? dp(18f) * p
                : edge == HomeEdgeGestureView.RIGHT_AKARI ? -dp(18f) * p : 0f);
        content.setTranslationY(edge == HomeEdgeGestureView.TOP_SIGNAL ? dp(14f) * p
                : edge == HomeEdgeGestureView.BOTTOM_TOOLS ? -dp(14f) * p : 0f);
        edgeGesture.setState(edge, p);
        SoundEngine.layerSlide(edge, p);

        boolean above = p >= .42f;
        if (above != layerThresholdPulse) {
            layerThresholdPulse = above;
            Haptics.tap(this);
            SoundEngine.layerThreshold(above);
        }
    }

    private void settleEdgeLayer(final int edge, boolean open, float velocityAlong, boolean allowPartial) {
        if (edge != activeLayerEdge) return;
        cancelLayerAnimator();
        final float start = layerProgress;
        float axisSize = edge == HomeEdgeGestureView.LEFT_APPS || edge == HomeEdgeGestureView.RIGHT_AKARI
                ? edgeGesture.getWidth() : edgeGesture.getHeight();
        final float target = LayerMotion.settleTarget(start, open, velocityAlong, axisSize, allowPartial);
        boolean pinPartial = target > .01f && target < .99f;
        float distance = Math.abs(target - start);
        long duration = (long) Math.max(150L, Math.min(380L,
                150L + distance * 230L - Math.min(80f, Math.abs(velocityAlong) * .025f)));
        ValueAnimator animator = ValueAnimator.ofFloat(start, target);
        layerAnimator = animator;
        animator.setDuration(Prefs.motionLevel() == 0 ? Math.min(220L, duration) : duration);
        animator.setInterpolator(open ? new OvershootInterpolator(.72f) : new DecelerateInterpolator(1.35f));
        animator.addUpdateListener(value -> applyEdgeLayerProgress(edge, (Float) value.getAnimatedValue()));
        animator.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
                if (layerAnimator != animation) return;
                layerAnimator = null;
                if (target <= 0f) resetEdgeLayerImmediate();
                else {
                    layerProgress = 1f;
                    applyEdgeLayerProgress(edge, 1f);
                    refreshEdgeLayer(edge);
                }
            }
        });
        animator.start();
        SoundEngine.layerRelease(target > .01f, edge);
        if (pinPartial) Haptics.press(this);
        else if (open) Haptics.success(this);
        else Haptics.tap(this);
    }

    private void openEdgeLayer(int edge) {
        if (riftOpen || riftTransition) {
            closeRift();
            handler.postDelayed(() -> openEdgeLayer(edge), 390L);
            return;
        }
        if (activeLayerEdge != HomeEdgeGestureView.NONE && activeLayerEdge != edge) {
            resetEdgeLayerImmediate();
        }
        if (activeLayerEdge == edge && layerProgress >= .99f) return;
        layerProgress = activeLayerEdge == edge ? layerProgress : 0f;
        beginEdgeLayer(edge);
        settleEdgeLayer(edge, true, 0f, false);
    }

    private void closeEdgeLayer() {
        if (activeLayerEdge == HomeEdgeGestureView.NONE) return;
        settleEdgeLayer(activeLayerEdge, false, 0f, false);
    }

    private void resetEdgeLayerImmediate() {
        cancelLayerAnimator();
        if (layerApps != null) layerApps.setVisibility(View.GONE);
        if (layerAkari != null) layerAkari.setVisibility(View.GONE);
        if (layerSignal != null) layerSignal.setVisibility(View.GONE);
        if (layerTools != null) layerTools.setVisibility(View.GONE);
        if (layerDim != null) {
            layerDim.setAlpha(0f);
            layerDim.setVisibility(View.GONE);
        }
        content.setAlpha(1f);
        content.setScaleX(1f);
        content.setScaleY(1f);
        content.setTranslationX(0f);
        content.setTranslationY(0f);
        layerProgress = 0f;
        activeLayerEdge = HomeEdgeGestureView.NONE;
        layerThresholdPulse = false;
        if (edgeGesture != null) edgeGesture.setState(HomeEdgeGestureView.NONE, 0f);
        hideLayerKeyboard();
    }

    private void cancelLayerAnimator() {
        if (layerAnimator == null) return;
        ValueAnimator old = layerAnimator;
        layerAnimator = null;
        old.cancel();
    }

    private View layerForEdge(int edge) {
        if (edge == HomeEdgeGestureView.LEFT_APPS) return layerApps;
        if (edge == HomeEdgeGestureView.RIGHT_AKARI) return layerAkari;
        if (edge == HomeEdgeGestureView.TOP_SIGNAL) return layerSignal;
        if (edge == HomeEdgeGestureView.BOTTOM_TOOLS) return layerTools;
        return null;
    }

    private ImageView artForEdge(int edge) {
        if (edge == HomeEdgeGestureView.LEFT_APPS) return layerAppsArt;
        if (edge == HomeEdgeGestureView.RIGHT_AKARI) return layerAkariArt;
        if (edge == HomeEdgeGestureView.TOP_SIGNAL) return layerSignalArt;
        if (edge == HomeEdgeGestureView.BOTTOM_TOOLS) return layerToolsArt;
        return null;
    }

    private String layerName(int edge) {
        if (edge == HomeEdgeGestureView.LEFT_APPS) return "Aplicaciones nativas";
        if (edge == HomeEdgeGestureView.RIGHT_AKARI) return "AKARI personalizada";
        if (edge == HomeEdgeGestureView.TOP_SIGNAL) return "Avisos y señales";
        return "Herramientas rápidas";
    }

    private void hideOtherEdgeLayers(View selected) {
        View[] layers = {layerApps, layerAkari, layerSignal, layerTools};
        for (View layer : layers) if (layer != null && layer != selected) layer.setVisibility(View.GONE);
    }

    private void refreshEdgeLayer(int edge) {
        if (edge == HomeEdgeGestureView.LEFT_APPS) renderLayerApps(layerAppsSearch.getText().toString());
        else if (edge == HomeEdgeGestureView.RIGHT_AKARI) refreshLayerAkari();
        else if (edge == HomeEdgeGestureView.TOP_SIGNAL) refreshSignalLayer();
    }

    private void renderLayerApps(String query) {
        if (layerAppsAdapter == null) return;
        if (allApps == null || allApps.isEmpty()) allApps = AppRepository.loadLaunchable(this);
        List<AppInfo> filtered = AppRepository.filter(allApps, query == null ? "" : query);
        layerAppsAdapter.setData(filtered);
        if (layerAppsMeta != null) layerAppsMeta.setText(filtered.size() == 1 ? "1 APP" : filtered.size() + " APPS");
    }

    private void selectLayerAkariArt(int index) {
        layerAkariArtIndex = Math.max(0, Math.min(2, index));
        int[] art = {R.drawable.cg_face, R.drawable.cg_rain, R.drawable.cg_jacket};
        String[] lines = {
                "Mi perfil responde al ángulo de la ventana. Acércame o déjame observar el tablero.",
                "La lluvia cambia mi ritmo y el parallax; cada capa sigue unida a tu movimiento.",
                "Modo chaqueta: una composición más firme para tus accesos y escenas guardadas."
        };
        layerAkariArt.animate().cancel();
        layerAkariArt.animate().alpha(.18f).setDuration(90L).withEndAction(() -> {
            layerAkariArt.setImageResource(art[layerAkariArtIndex]);
            layerAkariArt.animate().alpha(1f).setDuration(230L).start();
        }).start();
        layerAkariQuote.setText(lines[layerAkariArtIndex]);
        int[] ids = {R.id.layerAkariFace, R.id.layerAkariRain, R.id.layerAkariJacket};
        for (int i = 0; i < ids.length; i++) {
            View chip = findViewById(ids[i]);
            chip.setBackgroundResource(i == layerAkariArtIndex ? R.drawable.bg_chip_selected : R.drawable.bg_chip);
            if (chip instanceof TextView) ((TextView) chip).setTextColor(i == layerAkariArtIndex ? 0xFF2EF0FF : 0xFF9B93B3);
        }
        SoundEngine.portalShift(layerAkariArtIndex);
        Haptics.tap(this);
    }

    private void refreshLayerAkari() {
        if (layerAkariMeters != null) layerAkariMeters.setText("BOND " + Prefs.bond() + "  ·  HEAT " + Prefs.heat()
                + "  ·  " + Identity.rank().toUpperCase(Locale.getDefault()));
        if (layerAkariState != null) {
            String[] modes = {"CALMA", "PULSO", "GUARDIA"};
            layerAkariState.setText(modes[Math.max(0, Math.min(2, Prefs.poseMode()))]);
        }
        if (layerAkariQuote != null && layerAkariQuote.getText().length() == 0) {
            layerAkariQuote.setText("La ventana y mi imagen responden a la misma trayectoria del dedo.");
        }
    }

    private void refreshSignalLayer() {
        if (layerSignalWeather != null) {
            String solar = weather.hasSolar() ? "\n" + weather.uvLabel() + "  ·  " + weather.lightRemainingLabel()
                    + "  ·  " + weather.dayRemainingLabel() : "\nToca el clima de HOME para sincronizar UV y sol.";
            layerSignalWeather.setText(weather.line() + solar);
        }
        if (layerSignalList == null) return;
        layerSignalList.removeAllViews();
        boolean access = AkariNotificationService.hasAccess(this);
        List<NotificationEntry> entries = AkariNotificationService.snapshot(this);
        int visible = 0;
        for (NotificationEntry entry : entries) if (!entry.groupSummary) visible++;
        layerSignalCount.setText(access ? (visible + (visible == 1 ? " AVISO" : " AVISOS")) : "OFF");
        layerSignalCount.setTextColor(access ? 0xFFFF2ED9 : 0xFF9B93B3);
        if (!access) {
            addSignalCard("CENTRO DESCONECTADO", "Toca para autorizar el acceso protegido de Android.", null, true);
            return;
        }
        int shown = 0;
        for (NotificationEntry entry : entries) {
            if (entry.groupSummary) continue;
            String title = entry.call ? "LLAMADA · " + entry.appName : entry.appName;
            String bodyText = Prefs.notificationPrivacy() ? "Contenido oculto por privacidad"
                    : (entry.title + (entry.text == null || entry.text.isEmpty() ? "" : " · " + entry.text));
            addSignalCard(title, bodyText, entry, false);
            if (++shown >= 4) break;
        }
        if (shown == 0) addSignalCard("SEÑAL LIMPIA", "No hay avisos activos. AKARI seguirá escuchando.", null, false);
    }

    private void addSignalCard(String title, String bodyText, final NotificationEntry entry, boolean permission) {
        TextView card = new TextView(this);
        card.setBackgroundResource(R.drawable.bg_layer_card);
        card.setText(title.toUpperCase(Locale.getDefault()) + "\n" + bodyText);
        card.setTextColor(0xFFF4F0FF);
        card.setTextSize(11f);
        card.setMaxLines(3);
        card.setPadding((int) dp(11f), (int) dp(9f), (int) dp(11f), (int) dp(9f));
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.bottomMargin = (int) dp(7f);
        layerSignalList.addView(card, lp);
        if (permission) {
            card.setOnClickListener(v -> AkariNotificationService.showAccessGuide(HomeActivity.this));
        } else if (entry != null) {
            card.setContentDescription(title + ". " + bodyText + ". Toca para abrir; mantén para descartar.");
            card.setOnClickListener(v -> {
                SoundEngine.open();
                if (!AkariNotificationService.open(HomeActivity.this, entry.key)) openNotificationCenterFull();
            });
            card.setOnLongClickListener(v -> {
                boolean dismissed = AkariNotificationService.dismiss(entry.key);
                if (dismissed) {
                    SoundEngine.back();
                    Haptics.success(HomeActivity.this);
                    refreshSignalLayer();
                }
                return dismissed;
            });
        }
        DockMotion.bind(card);
    }

    private void launchFromLayer(final Intent intent) {
        SoundEngine.open();
        closeEdgeLayer();
        handler.postDelayed(() -> startActivity(intent), 170L);
    }

    private void hideLayerKeyboard() {
        if (layerAppsSearch == null) return;
        layerAppsSearch.clearFocus();
        InputMethodManager keyboard = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (keyboard != null) keyboard.hideSoftInputFromWindow(layerAppsSearch.getWindowToken(), 0);
    }

    private void wireRift() {
        if (riftView == null || riftHud == null || riftHandle == null) return;
        setRiftStyle(Prefs.riftStyle(), false);
        if (akariAvatar != null) akariAvatar.setPoseMode(Prefs.poseMode());

        riftHandle.setOnClickListener(v -> openRift());
        riftHandle.setOnLongClickListener(v -> {
            Prefs.setRiftStyle((Prefs.riftStyle() + 1) % 4);
            openRift();
            return true;
        });
        DockMotion.bind(riftHandle);

        findViewById(R.id.riftClose).setOnClickListener(v -> closeRift());
        findViewById(R.id.riftOutfit).setOnClickListener(v -> performRiftAction(PortalRiftView.ACTION_OUTFIT));
        findViewById(R.id.riftScenes).setOnClickListener(v -> performRiftAction(PortalRiftView.ACTION_SCENES));
        findViewById(R.id.riftApps).setOnClickListener(v -> performRiftAction(PortalRiftView.ACTION_APPS));
        findViewById(R.id.riftMusic).setOnClickListener(v -> performRiftAction(PortalRiftView.ACTION_MUSIC));
        riftState.setOnClickListener(v -> cycleRiftPose());
        riftTitle.setOnClickListener(v -> cycleRiftPose());
        riftLine.setOnClickListener(v -> {
            SoundEngine.soft();
            Voice.init(HomeActivity.this);
            Voice.speak(riftLine.getText().toString());
        });

        int[] styleIds = {R.id.riftStyleNexus, R.id.riftStyleViolet,
                R.id.riftStyleDawn, R.id.riftStyleCrimson};
        for (int i = 0; i < styleIds.length; i++) {
            final int selected = i;
            View chip = findViewById(styleIds[i]);
            chip.setOnClickListener(v -> setRiftStyle(selected, true));
            DockMotion.bind(chip);
        }

        int[] routeIds = {R.id.riftOutfit, R.id.riftScenes, R.id.riftApps, R.id.riftMusic, R.id.riftClose};
        for (int routeId : routeIds) DockMotion.bind(findViewById(routeId));

        riftView.setListener(action -> performRiftAction(action));
    }

    private void openRift() {
        if (riftOpen && !riftTransition) return;
        if (activeLayerEdge != HomeEdgeGestureView.NONE) resetEdgeLayerImmediate();
        if (edgeGesture != null) edgeGesture.setLayersEnabled(false);
        hideKeyboard();
        if (riftAnimator != null) riftAnimator.cancel();
        content.animate().cancel();
        riftHud.animate().cancel();
        riftHandle.animate().cancel();

        riftOpen = true;
        riftTransition = true;
        Prefs.incPortalVisits();
        setRiftStyle(Prefs.riftStyle(), false);
        updateRiftState();
        if (riftTitle != null) riftTitle.setText("AKARI // RIFT " + String.format(Locale.US, "%02d", Prefs.portalVisits()));

        String greeting = AkariLines.portalGreeting(Prefs.riftStyle());
        riftLine.setText(greeting);
        Prefs.setLastSay(greeting);
        riftView.setVisibility(View.VISIBLE);
        riftView.setProgress(0f);
        riftHud.setVisibility(View.VISIBLE);
        riftHud.setAlpha(0f);

        riftHandle.animate().alpha(0f).translationX(dp(52)).setDuration(160L)
                .withEndAction(() -> riftHandle.setVisibility(View.GONE)).start();
        content.setVisibility(View.VISIBLE);
        content.animate().alpha(0f).translationX(-dp(56)).translationY(dp(12)).rotation(-1.4f)
                .setDuration(300L).withEndAction(() -> {
                    if (riftOpen) content.setVisibility(View.INVISIBLE);
                }).start();
        riftHud.animate().alpha(1f).setStartDelay(150L).setDuration(300L).start();
        if (akariAvatar != null) {
            akariAvatar.setPortalStyle(Prefs.riftStyle());
            akariAvatar.setPoseMode(Prefs.poseMode());
            akariAvatar.setPortalActive(true);
            akariAvatar.impulse(0f, -92f);
        }

        riftAnimator = ValueAnimator.ofFloat(0f, 1f);
        riftAnimator.setDuration(Prefs.motionLevel() == 0 ? 380L : 520L);
        riftAnimator.addUpdateListener(animation -> riftView.setProgress((Float) animation.getAnimatedValue()));
        riftAnimator.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
                if (riftOpen) {
                    riftView.setProgress(1f);
                    riftTransition = false;
                }
            }
        });
        riftAnimator.start();
        SoundEngine.portalOpen();
        Haptics.rift(this);
    }

    private void closeRift() {
        if (!riftOpen && !riftTransition) return;
        if (riftAnimator != null) riftAnimator.cancel();
        content.animate().cancel();
        riftHud.animate().cancel();
        riftHandle.animate().cancel();

        riftOpen = false;
        riftTransition = true;
        float from = riftView == null ? 1f : Math.max(.05f, riftView.getProgress());
        riftHud.animate().alpha(0f).setStartDelay(0L).setDuration(180L).start();
        content.setVisibility(View.VISIBLE);
        content.setAlpha(0f);
        content.setTranslationX(-dp(48));
        content.setTranslationY(dp(10));
        content.setRotation(-1.2f);
        content.animate().alpha(1f).translationX(0f).translationY(0f).rotation(0f)
                .setStartDelay(90L).setDuration(310L).start();
        if (akariAvatar != null) {
            akariAvatar.setPortalActive(false);
            akariAvatar.impulse(0f, 65f);
        }

        riftAnimator = ValueAnimator.ofFloat(from, 0f);
        riftAnimator.setDuration(Prefs.motionLevel() == 0 ? 260L : 360L);
        riftAnimator.addUpdateListener(animation -> riftView.setProgress((Float) animation.getAnimatedValue()));
        riftAnimator.addListener(new AnimatorListenerAdapter() {
            @Override public void onAnimationEnd(Animator animation) {
                if (!riftOpen) {
                    riftTransition = false;
                    riftView.setProgress(0f);
                    riftView.setVisibility(View.GONE);
                    riftHud.setVisibility(View.GONE);
                    riftHud.setAlpha(1f);
                    riftHandle.setVisibility(View.GONE);
                    if (edgeGesture != null) {
                        edgeGesture.setLayersEnabled(true);
                        edgeGesture.setState(HomeEdgeGestureView.NONE, 0f);
                    }
                }
            }
        });
        riftAnimator.start();
        SoundEngine.portalClose();
        Haptics.tap(this);
    }

    private void performRiftAction(int action) {
        if (!riftOpen || riftTransition) return;
        if (action == PortalRiftView.ACTION_POSE) {
            cycleRiftPose();
            return;
        }
        final int destinationEdge;
        final int artMode;
        String line;
        if (action == PortalRiftView.ACTION_OUTFIT) {
            destinationEdge = HomeEdgeGestureView.RIGHT_AKARI;
            artMode = 2;
            line = "La lámina de vestuario sale desde el mismo borde. Jálala o cámbiala sin abandonar HOME.";
        } else if (action == PortalRiftView.ACTION_SCENES) {
            destinationEdge = HomeEdgeGestureView.RIGHT_AKARI;
            artMode = 0;
            line = "Abro mi ventana personal dentro del tablero. Desde ahí eliges perfil, lluvia o escenas.";
        } else if (action == PortalRiftView.ACTION_APPS) {
            destinationEdge = HomeEdgeGestureView.LEFT_APPS;
            artMode = -1;
            line = "Tus aplicaciones reales entran desde la izquierda. Cada icono abre su APK instalado.";
        } else {
            destinationEdge = HomeEdgeGestureView.BOTTOM_TOOLS;
            artMode = -1;
            line = "El control sube desde abajo con música, brújula, alarma y herramientas directas.";
        }
        riftLine.setText(line);
        Prefs.setLastSay(line);
        SoundEngine.portalShift(Prefs.riftStyle());
        Haptics.success(this);
        if (akariAvatar != null) akariAvatar.impulse(action == PortalRiftView.ACTION_SCENES ? 85f : -60f, -55f);
        closeRift();
        handler.postDelayed(() -> {
            openEdgeLayer(destinationEdge);
            if (artMode >= 0) handler.postDelayed(() -> selectLayerAkariArt(artMode), 120L);
        }, 410L);
    }

    private void shiftRiftStyle(int delta) {
        int next = (Prefs.riftStyle() + delta + 4) % 4;
        setRiftStyle(next, true);
    }

    private void setRiftStyle(int style, boolean react) {
        style = Math.max(0, Math.min(3, style));
        Prefs.setRiftStyle(style);
        if (riftView != null) riftView.setStyle(style);
        if (akariAvatar != null) akariAvatar.setPortalStyle(style);
        int[] ids = {R.id.riftStyleNexus, R.id.riftStyleViolet,
                R.id.riftStyleDawn, R.id.riftStyleCrimson};
        for (int i = 0; i < ids.length; i++) {
            View chip = findViewById(ids[i]);
            if (chip == null) continue;
            chip.animate().cancel();
            chip.animate().alpha(i == style ? 1f : .48f)
                    .scaleX(i == style ? 1.05f : .96f)
                    .scaleY(i == style ? 1.05f : .96f).setDuration(160L).start();
        }
        if (riftView != null) {
            int accent = riftView.getAccentColor();
            int[] routeIds = {R.id.riftOutfit, R.id.riftScenes, R.id.riftApps, R.id.riftMusic};
            for (int routeId : routeIds) {
                View route = findViewById(routeId);
                if (route instanceof TextView) ((TextView) route).setTextColor(accent);
            }
        }
        updateRiftState();
        if (react && riftOpen) {
            String line = AkariLines.portalGreeting(style);
            riftLine.setText(line);
            Prefs.setLastSay(line);
            SoundEngine.portalShift(style);
            Haptics.tap(this);
            if (riftView != null) riftView.pulse(getWindow().getDecorView().getWidth() * .5f,
                    getWindow().getDecorView().getHeight() * .47f);
        }
    }

    private void cycleRiftPose() {
        int pose = (Prefs.poseMode() + 1) % 3;
        Prefs.setPoseMode(pose);
        if (akariAvatar != null) akariAvatar.setPoseMode(pose);
        updateRiftState();
        String line = AkariLines.pose(pose);
        if (riftLine != null) riftLine.setText(line);
        Prefs.setLastSay(line);
        SoundEngine.portalShift(Prefs.riftStyle());
        Haptics.press(this);
    }

    private void updateRiftState() {
        if (riftState == null) return;
        String[] styles = {"NEXUS", "VIOLETA", "DAWN", "CRIMSON"};
        String[] poses = {"CALMA", "PULSO", "GUARDIA"};
        riftState.setText(styles[Prefs.riftStyle()] + " · " + poses[Prefs.poseMode()]
                + " · H" + Prefs.heat());
        if (riftView != null) riftState.setTextColor(riftView.getAccentColor());
    }

    private void hideKeyboard() {
        if (searchBar == null) return;
        searchBar.clearFocus();
        InputMethodManager keyboard = (InputMethodManager) getSystemService(INPUT_METHOD_SERVICE);
        if (keyboard != null) keyboard.hideSoftInputFromWindow(searchBar.getWindowToken(), 0);
    }

    private void wireCompanion() {
        if (akariAvatar == null) return;
        akariAvatar.setListener(new AkariAvatarView.Listener() {
            @Override public void onBodyTouch(AkariAvatarView.Zone zone, float normalizedY, boolean hold) {
                onTapZone(normalizedY, hold);
            }

            @Override public void onGesture(AkariAvatarView.Gesture gesture) {
                if (riftOpen) {
                    if (gesture == AkariAvatarView.Gesture.LEFT) shiftRiftStyle(-1);
                    else if (gesture == AkariAvatarView.Gesture.RIGHT) shiftRiftStyle(1);
                    else if (gesture == AkariAvatarView.Gesture.UP) cycleRiftPose();
                    else closeRift();
                    return;
                }
                if (gesture == AkariAvatarView.Gesture.LEFT) {
                    openEdgeLayer(HomeEdgeGestureView.RIGHT_AKARI);
                } else if (gesture == AkariAvatarView.Gesture.RIGHT) {
                    openEdgeLayer(HomeEdgeGestureView.LEFT_APPS);
                } else if (gesture == AkariAvatarView.Gesture.UP) {
                    Prefs.addBond(1);
                    say("El control sube contigo desde la parte inferior.");
                    body.impulse(0f, -115f);
                    openEdgeLayer(HomeEdgeGestureView.BOTTOM_TOOLS);
                } else {
                    say("Bajo señales, clima y avisos sobre la misma pantalla.");
                    body.impulse(0f, 75f);
                    openEdgeLayer(HomeEdgeGestureView.TOP_SIGNAL);
                }
                refreshMeters();
            }

            @Override public void onDoubleTap() {
                if (riftOpen) closeRift();
                else openRift();
            }

            @Override public void onScale(float scale) {
                TextView target = riftOpen ? riftLine : akariLine;
                if (target == null) return;
                if (scale > 1.10f) target.setText("Más cerca. El cuerpo, la abertura y tu gesto siguen enlazados.");
                else if (scale < .86f) target.setText("Me das espacio, pero sigo anclada al wallpaper real.");
                if (!riftOpen) pulseDialogue();
            }
        });
    }

    private void onTapZone(float ny, boolean hold) {
        Prefs.incTouches();
        if (riftOpen) {
            String portalLine = AkariLines.portalZone(ny, hold, Prefs.poseMode(), Prefs.riftStyle());
            if (riftLine != null) {
                riftLine.setText(portalLine);
                riftLine.animate().cancel();
                riftLine.setAlpha(.72f);
                riftLine.setScaleX(.96f);
                riftLine.setScaleY(.96f);
                riftLine.animate().alpha(1f).scaleX(1f).scaleY(1f).setDuration(190L).start();
            }
            Prefs.setLastSay(portalLine);
            Launcher.haptic(this);
            SoundEngine.heat();
            if (hold || Prefs.heat() > 60) SoundEngine.breath();
            if (akariAvatar != null) {
                if (hold) akariAvatar.squash();
                else akariAvatar.jiggle();
            }
            if (riftView != null && akariAvatar != null) {
                riftView.pulse(akariAvatar.getLastTouchX(), akariAvatar.getLastTouchY());
            }
            refreshMeters();
            return;
        }
        String line = AkariLines.zone(ny);
        akariLine.setText(hold ? "Contacto sostenido. " + line : line);
        Launcher.haptic(this);
        SoundEngine.heat();
        if (hold || Prefs.heat() > 60) SoundEngine.breath();
        body.jiggle();
        if (akariAvatar != null) {
            if (hold) akariAvatar.squash();
            else akariAvatar.jiggle();
        }
        if (particles != null && akariAvatar != null) {
            particles.burst(akariAvatar.getLastTouchX(), akariAvatar.getLastTouchY());
        }
        placeDialogueAwayFromTouch();
        pulseDialogue();
        refreshMeters();
        if (Prefs.heat() >= 80 && Prefs.bond() >= 18 && !Prefs.unlocked("jacket")) {
            Prefs.unlock("jacket");
            SoundEngine.unlock();
            Toast.makeText(this, "CG Jacket Off desbloqueado", Toast.LENGTH_SHORT).show();
        }
    }

    private void refreshMeters() {
        bondBar.setProgress(Prefs.bond());
        heatBar.setProgress(Prefs.heat());
        bondValue.setText(String.valueOf(Prefs.bond()));
        heatValue.setText(String.valueOf(Prefs.heat()));
        int a = Math.min(80, (int) (Prefs.heat() * 0.62f));
        heatVignette.setBackground(new ColorDrawable((a << 24) | 0x00FF2ED9));
        updateAtmosphere();
        if (akariAvatar != null) {
            akariAvatar.setHeat(Prefs.heat());
            akariAvatar.setBond(Prefs.bond());
        }
        if (activeLayerEdge == HomeEdgeGestureView.RIGHT_AKARI) refreshLayerAkari();
        if (riftOpen) updateRiftState();
    }

    private void refreshHud() {
        batteryLine.setText(SystemHud.battery(this));
        refreshNotificationStatus();
        sayBatt(false);
    }

    private void loadWeather(final boolean force) {
        weather.city = Prefs.city();
        weather.lat = Prefs.lat();
        weather.lon = Prefs.lon();
        final String cache = Prefs.weatherCache();
        if (!force && cache != null && !cache.isEmpty()
                && System.currentTimeMillis() - Prefs.weatherCacheAt() < 20 * 60 * 1000L) {
            try {
                weather = Weather.parse(cache, Prefs.city(), Prefs.lat(), Prefs.lon());
                weatherLine.setText(weather.line());
                if (solarArc != null) solarArc.setWeather(weather);
                if (activeLayerEdge == HomeEdgeGestureView.TOP_SIGNAL) refreshSignalLayer();
                updateAtmosphere();
                if (weather.hasSolar()) return;
            } catch (Exception ignored) {}
        }
        if (weatherLoading) {
            if (force) showLine("La sincronización ya está en curso.", false);
            return;
        }
        weatherLoading = true;
        weatherLine.setText(Prefs.city() + " · midiendo…");
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    final String json = Net.get(weather.forecastUrl());
                    Prefs.setWeatherCache(json);
                    final Weather w = Weather.parse(json, Prefs.city(), Prefs.lat(), Prefs.lon());
                    handler.post(new Runnable() {
                        @Override public void run() {
                            weatherLoading = false;
                            weather = w;
                            weatherLine.setText(w.line());
                            if (solarArc != null) solarArc.setWeather(w);
                            if (activeLayerEdge == HomeEdgeGestureView.TOP_SIGNAL) refreshSignalLayer();
                            updateAtmosphere();
                            if (force) say(AkariNarrator.weather(w));
                        }
                    });
                } catch (Exception e) {
                    handler.post(new Runnable() {
                        @Override public void run() {
                            weatherLoading = false;
                            if (cache != null && !cache.isEmpty()) {
                                try {
                                    weather = Weather.parse(cache, Prefs.city(), Prefs.lat(), Prefs.lon());
                                    weatherLine.setText(weather.line() + "  ·  CACHÉ");
                                    if (solarArc != null) solarArc.setWeather(weather);
                                    if (activeLayerEdge == HomeEdgeGestureView.TOP_SIGNAL) refreshSignalLayer();
                                    updateAtmosphere();
                                    if (force) say("No hubo red. Conservo la última lectura válida.");
                                    return;
                                } catch (Exception ignored) {}
                            }
                            weatherLine.setText(Prefs.city() + " · sin red  ·  toca para reintentar");
                            if (force) say("No pude actualizar el clima. No voy a inventar una lectura.");
                        }
                    });
                }
            }
        }).start();
    }

    private void loadNews(boolean force) {
        final String cache = Prefs.newsCache();
        if (!force && cache != null && !cache.isEmpty()
                && System.currentTimeMillis() - Prefs.newsCacheAt() < 15 * 60 * 1000L) {
            applyNews(cache);
            return;
        }
        new Thread(new Runnable() {
            @Override public void run() {
                try {
                    final String xml = Net.get(NewsActivity.RSS);
                    Prefs.setNewsCache(xml);
                    handler.post(new Runnable() {
                        @Override public void run() { applyNews(xml); }
                    });
                } catch (Exception ignored) {
                    handler.post(new Runnable() {
                        @Override public void run() {
                            if (cache != null && !cache.isEmpty()) applyNews(cache);
                        }
                    });
                }
            }
        }).start();
    }

    private void applyNews(String xml) {
        java.util.List<NewsItem> headlines = NewsItem.parseRss(xml);
        if (headlines == null || headlines.isEmpty()) {
            newsTicker.setText("Noticias · toca para abrir el feed");
            return;
        }
        StringBuilder sb = new StringBuilder("  +  ");
        int n = Math.min(6, headlines.size());
        for (int i = 0; i < n; i++) {
            if (i > 0) sb.append("    ·    ");
            sb.append(headlines.get(i).title);
        }
        newsTicker.setText(sb.toString());
        newsTicker.setSelected(true);
        showLine(AkariNarrator.news(headlines.get(0).title), false);
        if (Prefs.voiceAuto()) Voice.readNews(headlines);
    }

    private void maybeDaily() {
        String day = new SimpleDateFormat("yyyyMMdd", Locale.US).format(new Date());
        if (!day.equals(Prefs.lastDaily())) {
            Prefs.setLastDaily(day);
            Prefs.addBond(3);
            akariLine.setText(AkariLines.daily());
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        applyHomeChrome();
        registerNotificationReceiver();
        AkariNotificationService.requestReconnect(this);
        SoundEngine.init(this);
        SoundEngine.startAmbient(this);
        handler.removeCallbacks(frame);
        handler.post(frame);
        reloadApps();
        refreshMeters();
        refreshHud();
        refreshAlarm();
        applyCommandDeck(false);
        String pending = Prefs.lastSay();
        if (pending != null && !pending.isEmpty()) showLine(pending, false);
        reactToPendingNotification();
        if (tilt != null) tilt.start();
        maybePerms();
        int h = AkariNarrator.hourNow();
        if (h != lastHour) {
            lastHour = h;
            if ((h == 8 || h == 13 || h == 21 || h == 1)) say(AkariNarrator.hour(h));
        }
    }

    @Override
    protected void onPause() {
        super.onPause();
        unregisterNotificationReceiver();
        handler.removeCallbacks(hideNotificationPeek);
        handler.removeCallbacks(searchPreview);
        handler.removeCallbacks(frame);
        SoundEngine.stopAmbient();
        Voice.stopListen();
        if (tilt != null) tilt.stop();
    }

    @Override
    public void onBackPressed() {
        if (activeLayerEdge != HomeEdgeGestureView.NONE) closeEdgeLayer();
        else if (riftOpen || riftTransition) closeRift();
        else if (Prefs.commandDeckExpanded()) {
            Prefs.setCommandDeckExpanded(false);
            applyCommandDeck(true);
        }
    }

    private void updateClock() {
        String shown = SystemHud.time(this, Prefs.showSeconds());
        clock.setTextSize(shown.length() > 8 ? 42f : 52f);
        clock.setText(shown);
        dateLine.setText(SystemHud.dateLine());
        updateAtmosphere();
    }

    private void refreshAlarm(){
        if(alarmMini==null)return;
        alarmMini.setText(AlarmScheduler.label());
        alarmMini.setTextColor(Prefs.alarmEnabled()?0xFF2EF0FF:0xFF9B93B3);
    }

    private void reloadApps() {
        allApps = AppRepository.loadLaunchable(this);
        renderDock(AppRepository.pickDock(allApps));
        renderQuick(AppRepository.suggestions(allApps, 8));
        defaultAssist = AppRepository.suggestions(allApps, 6);
        if (defaultAssist.isEmpty()) defaultAssist = allApps;
        String query = searchBar == null ? "" : searchBar.getText().toString().trim();
        if (!query.isEmpty()) updateSearchPreview(query);
        else {
            searchPreviewActive = false;
            assist = defaultAssist;
            assistIndex = 0;
            renderAssist();
        }
        if (layerAppsAdapter != null && activeLayerEdge == HomeEdgeGestureView.LEFT_APPS) {
            renderLayerApps(layerAppsSearch == null ? "" : layerAppsSearch.getText().toString());
        }
    }

    private void renderDock(List<AppInfo> dock) {
        dockRow.removeAllViews();
        LayoutInflater inf = getLayoutInflater();
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f);
        for (final AppInfo a : dock) {
            View item = inf.inflate(R.layout.item_dock, dockRow, false);
            item.setTag(a.packageName);
            ((ImageView) item.findViewById(R.id.icon)).setImageDrawable(a.icon);
            ((TextView) item.findViewById(R.id.label)).setText(a.label);
            item.setContentDescription(a.label + ". App del dock. Toca para abrir; mantén para acciones.");
            item.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    DockMotion.launchWave(v);
                    showLine(AkariNarrator.openApp(a), true);
                    body.jiggle();
                    if (particles != null) particles.burst(v.getX() + 40, 900);
                    v.postDelayed(new Runnable() {
                        @Override public void run() { Launcher.open(HomeActivity.this, a); }
                    }, 105);
                }
            });
            item.setOnLongClickListener(new View.OnLongClickListener() {
                @Override public boolean onLongClick(View v) {
                    AppActions.show(HomeActivity.this, a, () -> reloadApps());
                    return true;
                }
            });
            DockMotion.bind(item);
            dockRow.addView(item, lp);
        }
    }

    private void renderQuick(List<AppInfo> all) {
        quickRow.removeAllViews();
        LayoutInflater inf = getLayoutInflater();
        for (final AppInfo a : all) {
            View item = inf.inflate(R.layout.item_dock, quickRow, false);
            item.setTag(a.packageName);
            ((ImageView) item.findViewById(R.id.icon)).setImageDrawable(a.icon);
            ((TextView) item.findViewById(R.id.label)).setText(a.label);
            item.setContentDescription(a.label + ". App frecuente. Toca para abrir; mantén para acciones.");
            item.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    DockMotion.launchWave(v);
                    showLine(AkariNarrator.openApp(a), true);
                    body.jiggle();
                    v.postDelayed(new Runnable() {
                        @Override public void run() { Launcher.open(HomeActivity.this, a); }
                    }, 105);
                }
            });
            item.setOnLongClickListener(v -> {
                AppActions.show(HomeActivity.this, a, () -> reloadApps());
                return true;
            });
            DockMotion.bind(item);
            quickRow.addView(item);
        }
    }

    private void say(String s) {
        if (!showLine(s, true)) return;
        Voice.init(this);
        Voice.speak(s);
    }

    private boolean showLine(String s, boolean persist) {
        if (s == null || s.trim().isEmpty() || akariLine == null) return false;
        akariLine.setText(s);
        pulseDialogue();
        if (persist) Prefs.setLastSay(s);
        return true;
    }

    private void pulseDialogue() {
        if (dialogueBubble == null) return;
        dialogueBubble.animate().cancel();
        dialogueBubble.setAlpha(.82f);
        dialogueBubble.setScaleX(.95f);
        dialogueBubble.setScaleY(.95f);
        dialogueBubble.animate().alpha(1f).scaleX(1f).scaleY(1f)
                .setDuration(210L).start();
    }

    private void placeDialogueAwayFromTouch() {
        if (dialogueBubble == null || akariAvatar == null) return;
        if (!(dialogueBubble.getLayoutParams() instanceof FrameLayout.LayoutParams)) return;
        FrameLayout.LayoutParams lp = (FrameLayout.LayoutParams) dialogueBubble.getLayoutParams();
        boolean touchedRight = akariAvatar.getLastTouchX() > akariAvatar.getWidth() * .5f;
        int horizontal = touchedRight ? Gravity.START : Gravity.END;
        if (lp.gravity != (Gravity.BOTTOM | horizontal)) {
            lp.gravity = Gravity.BOTTOM | horizontal;
            dialogueBubble.setLayoutParams(lp);
        }
    }

    private void sayBatt(boolean force) {
        try {
            android.content.Intent bat = registerReceiver(null,
                    new android.content.IntentFilter(android.content.Intent.ACTION_BATTERY_CHANGED));
            if (bat == null) return;
            int level = bat.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
            int scale = bat.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100);
            int pct = scale > 0 ? Math.round(level * 100f / scale) : -1;
            int st = bat.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1);
            boolean chg = st == android.os.BatteryManager.BATTERY_STATUS_CHARGING
                    || st == android.os.BatteryManager.BATTERY_STATUS_FULL;
            if (force || pct != lastBatt) {
                if (force || pct <= 15 || chg || (lastBatt > 0 && Math.abs(pct - lastBatt) >= 8)) {
                    say(AkariNarrator.battery(pct, chg));
                    if (pct <= 15) body.jiggle();
                }
                lastBatt = pct;
            }
        } catch (Exception ignored) {}
    }

    private void cycleAssist(boolean next) {
        if (assist == null || assist.isEmpty()) return;
        assistIndex = (assistIndex + (next ? 1 : -1) + assist.size()) % assist.size();
        AppInfo a = assist.get(assistIndex);
        String why = searchPreviewActive ? "Coincidencia de tu búsqueda."
                : (next ? "Siguiente que uso mucho." : "Te la dejé a mano.");
        say(AkariNarrator.assist(a, why));
        body.impulse(next ? -70 : 70, -20);
        SoundEngine.click();
        renderAssist();
    }


    private void startListen() {
        Voice.init(this);
        if (Build.VERSION.SDK_INT >= 23 &&
                checkSelfPermission(Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.RECORD_AUDIO}, 77);
            say("Dame permiso de micrófono para oírte.");
            return;
        }
        say("Te escucho. Di abre WhatsApp, RIFT, avisos, noticias, clima u hora…");
        Voice.listen(this, new Voice.Listener() {
            @Override public void onHeard(String text) { onVoiceCommand(text); }
            @Override public void onListenState(String state) {
                if (assistHint != null) assistHint.setText("MIC · " + state);
            }
        });
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == 77 && grantResults.length > 0
                && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
            startListen();
        }
    }

    private void onVoiceCommand(String text) {
        String r = Voice.handleCommand(this, text);
        if (r.equals("NEWS")) {
            say("Leo el boletín y te lo dejo en el portal.");
            String cache = Prefs.newsCache();
            if (cache != null) Voice.readNews(NewsItem.parseRss(cache));
            Launcher.openPortal(this, "https://news.google.com/?hl=es-419&gl=MX&ceid=MX:es-419", "News");
        } else if (r.equals("WEATHER")) {
            showLine("Actualizo clima, UV y trayectoria solar…", false);
            loadWeather(true);
        } else if (r.equals("TIME")) {
            say(SpeechStyle.naturalTime());
        } else if (r.equals("BATTERY")) {
            sayBatt(true);
        } else if (r.equals("RIFT")) {
            openRift();
        } else if (r.equals("EROGE")) {
            say("Vamos a la sesión.");
            startActivity(new Intent(this, ErogeHubActivity.class));
        } else if (r.equals("SETTINGS")) {
            startActivity(new Intent(this, SettingsActivity.class));
        } else if (r.equals("TORCH")) {
            QuickActions.toggleTorch(this);
            say("Linterna.");
        } else if (r.equals("PHONE")) {
            QuickActions.phone(this);
            say("Marcador.");
        } else if (r.equals("WIFI")) {
            QuickActions.wifi(this);
        } else if (r.equals("DRAWER") || r.equals("STUDIO")) {
            startActivity(new Intent(this, StudioActivity.class));
        } else if (r.equals("DOSSIER")) {
            startActivity(new Intent(this, DossierActivity.class));
        } else if (r.equals("CALC")) {
            startActivity(new Intent(this, CalcActivity.class));
        } else if (r.equals("ARCADE")) {
            startActivity(new Intent(this, ArcadeActivity.class));
        } else if (r.equals("PULSE")) {
            startActivity(new Intent(this, PulseActivity.class));
        } else if (r.equals("LOUNGE")) {
            startActivity(new Intent(this, LoungeActivity.class));
        } else if (r.equals("CHESS")) {
            startActivity(new Intent(this, ChessActivity.class));
        } else if (r.equals("ALARM")) {
            say("Abro Dawn Link. Pon la hora y yo me encargo de llamarte.");
            startActivity(new Intent(this, AlarmActivity.class));
        } else if (r.equals("COMPASS")) {
            say("Abro Vector. Yo compenso el norte magnético.");
            startActivity(new Intent(this, CompassActivity.class));
        } else if (r.equals("VOLUME")) {
            startActivity(new Intent(this, VolumeActivity.class));
        } else if (r.equals("LOCK")) {
            startActivity(new Intent(this, LockActivity.class));
        } else if (r.equals("PERMS")) {
            startActivity(new Intent(this, PermsActivity.class));
        } else if (r.equals("NOTIFICATIONS")) {
            openNotificationCenter();
        } else if (r.startsWith("OPEN:")) {
            showLine("Listo. Abrí " + r.substring(5) + ". No tardes.", true);
            body.jiggle();
        } else if (r.startsWith("ASK:") || r.startsWith("SEARCH:") || r.startsWith("MISS:")) {
            String q = r.substring(r.indexOf(':') + 1).trim();
            say("Te lo busco aquí mismo. " + q);
            Launcher.openPortal(this, AppPortals.searchUrl(q), q);
        } else {
            say(r);
        }
    }

    private void maybePerms() {
        if (Prefs.permsPrompted()) return;
        boolean miss = checkSelfPermission(android.Manifest.permission.RECORD_AUDIO)
                != android.content.pm.PackageManager.PERMISSION_GRANTED;
        if (miss) {
            Prefs.setPermsPrompted(true);
            startActivity(new Intent(this, PermsActivity.class));
        }
    }

    private void updateSearchPreview(String query) {
        String q = query == null ? "" : query.trim();
        assistIndex = 0;
        if (q.isEmpty()) {
            searchPreviewActive = false;
            assist = defaultAssist;
        } else {
            searchPreviewActive = true;
            assist = AppRepository.filter(allApps, q);
        }
        renderAssist();
    }

    private void renderAssist() {
        if (assistRow == null) return;
        assistRow.removeAllViews();
        if (assist == null || assist.isEmpty()) {
            if (assistHint != null) assistHint.setText(searchPreviewActive
                    ? "SIN APPS · pulsa buscar para consultar la web"
                    : "SIN SUGERENCIAS · abre TALLER para revisar aplicaciones");
            return;
        }
        LayoutInflater inf = getLayoutInflater();
        int n = Math.min(4, assist.size());
        for (int i = 0; i < n; i++) {
            final AppInfo a = assist.get((assistIndex + i) % assist.size());
            View item = inf.inflate(R.layout.item_dock, assistRow, false);
            item.setTag(a.packageName);
            ((ImageView) item.findViewById(R.id.icon)).setImageDrawable(a.icon);
            ((TextView) item.findViewById(R.id.label)).setText(a.label);
            item.setContentDescription(a.label + (searchPreviewActive
                    ? ". Resultado de búsqueda." : ". Sugerencia de AKARI.")
                    + " Toca para abrir; mantén para acciones.");
            item.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    showLine(AkariNarrator.assist(a, "Te la abrí yo."), true);
                    body.jiggle();
                    if (particles != null) particles.burst(200, 400);
                    DockMotion.launchWave(v);
                    v.postDelayed(new Runnable() {
                        @Override public void run() { Launcher.open(HomeActivity.this, a); }
                    }, 105);
                }
            });
            item.setOnLongClickListener(v -> {
                AppActions.show(HomeActivity.this, a, () -> reloadApps());
                return true;
            });
            DockMotion.bind(item);
            assistRow.addView(item);
        }
        if (assistHint != null && !assist.isEmpty()) {
            assistHint.setText(searchPreviewActive
                    ? assist.size() + (assist.size() == 1 ? " RESULTADO · " : " RESULTADOS · ")
                        + assist.get(assistIndex).label
                    : "AKARI TE PASA · " + assist.get(assistIndex).label + " · desliza");
        }
    }

    private void toggleCommandDeck() {
        boolean expanded = !Prefs.commandDeckExpanded();
        Prefs.setCommandDeckExpanded(expanded);
        SoundEngine.confirm();
        Haptics.tap(this);
        applyCommandDeck(true);
        showLine(expanded
                ? "Herramientas desplegadas. Todo vuelve a estar a mano."
                : "Modo limpio. Dejo visibles el dock, mi cuerpo y la información esencial.", false);
    }

    private void applyCommandDeck(boolean animate) {
        if (deckHandle == null) return;
        final boolean expanded = Prefs.commandDeckExpanded();
        View[] views = new View[]{assistHint, assistRow, toolScroller, primaryActionsRow, quickRowSys, quickScroller};
        for (final View view : views) {
            if (view == null) continue;
            view.animate().cancel();
            if (expanded) {
                view.setVisibility(View.VISIBLE);
                if (animate) {
                    view.setAlpha(0f);
                    view.setTranslationY(dp(10));
                    view.animate().alpha(1f).translationY(0f).setDuration(220L).start();
                } else {
                    view.setAlpha(1f);
                    view.setTranslationY(0f);
                }
            } else if (animate && view.getVisibility() == View.VISIBLE) {
                view.animate().alpha(0f).translationY(dp(8)).setDuration(150L)
                        .withEndAction(() -> {
                            if (!Prefs.commandDeckExpanded()) view.setVisibility(View.GONE);
                        }).start();
            } else {
                view.setVisibility(View.GONE);
                view.setAlpha(1f);
                view.setTranslationY(0f);
            }
        }
        deckHandle.setText(expanded ? "▽  OCULTAR HERRAMIENTAS" : "△  MOSTRAR HERRAMIENTAS");
        deckHandle.setTextColor(expanded ? 0xFF2EF0FF : 0xFFFF2ED9);
        deckHandle.setContentDescription(expanded
                ? "Ocultar herramientas y ampliar el escenario de AKARI"
                : "Mostrar herramientas del launcher");
    }

    private void updateAtmosphere() {
        int hour = java.util.Calendar.getInstance().get(java.util.Calendar.HOUR_OF_DAY);
        int phase;
        String name;
        int color;
        long now = System.currentTimeMillis();
        if (weather != null && weather.hasSolar()) {
            long transition = 75L * 60L * 1000L;
            if (now >= weather.sunriseAt - transition && now < weather.sunriseAt + transition) hour = 6;
            else if (now >= weather.sunriseAt + transition && now < weather.sunsetAt - transition) hour = 12;
            else if (now >= weather.sunsetAt - transition && now < weather.sunsetAt + transition) hour = 18;
            else hour = 23;
        }
        if (hour >= 5 && hour < 8) {
            phase = 0; name = "AMANECER"; color = 0x143A74FF;
        } else if (hour >= 8 && hour < 17) {
            phase = 1; name = "DÍA"; color = 0x0800D9FF;
        } else if (hour >= 17 && hour < 20) {
            phase = 2; name = "OCASO"; color = 0x18FF397E;
        } else {
            phase = 3; name = "NOCHE"; color = 0x1B07122C;
        }
        sysStatus.setText((Prefs.heat() > 70 ? "OVERHEAT" : "NEXUS") + " · " + name);
        if (dayTint != null && phase != lastPhase) {
            lastPhase = phase;
            dayTint.animate().cancel();
            dayTint.setAlpha(0f);
            dayTint.setBackgroundColor(color);
            dayTint.animate().alpha(1f).setDuration(700L).start();
        }
    }

    private void wireNotificationPeek() {
        if (notificationPeek == null) return;
        notificationPeek.setOnClickListener(v -> openNotificationCenter());
        notificationPeek.setOnLongClickListener(v -> {
            dismissNotificationPeek(1f);
            return true;
        });
        notificationPeek.setOnTouchListener((view, event) -> {
            switch (event.getActionMasked()) {
                case MotionEvent.ACTION_DOWN:
                    peekDownX = event.getRawX();
                    peekDownY = event.getRawY();
                    handler.removeCallbacks(hideNotificationPeek);
                    view.animate().cancel();
                    return true;
                case MotionEvent.ACTION_MOVE:
                    float dx = event.getRawX() - peekDownX;
                    float dy = event.getRawY() - peekDownY;
                    if (Math.abs(dx) > Math.abs(dy)) {
                        view.setTranslationX(dx);
                        view.setAlpha(Math.max(.35f, 1f - Math.abs(dx) / Math.max(1f, view.getWidth())));
                    }
                    return true;
                case MotionEvent.ACTION_UP:
                    float totalX = event.getRawX() - peekDownX;
                    float totalY = event.getRawY() - peekDownY;
                    if (Math.abs(totalX) > dp(72)) {
                        dismissNotificationPeek(totalX < 0 ? -1f : 1f);
                    } else {
                        view.animate().translationX(0f).alpha(1f).setDuration(180L).start();
                        if (Math.hypot(totalX, totalY) < dp(14)) view.performClick();
                        else handler.postDelayed(hideNotificationPeek, 4_000L);
                    }
                    return true;
                case MotionEvent.ACTION_CANCEL:
                    view.animate().translationX(0f).alpha(1f).setDuration(180L).start();
                    handler.postDelayed(hideNotificationPeek, 4_000L);
                    return true;
                default:
                    return true;
            }
        });
    }

    private void dismissNotificationPeek(float direction) {
        if (notificationPeek == null) return;
        handler.removeCallbacks(hideNotificationPeek);
        float distance = Math.max(notificationPeek.getWidth(), dp(240)) * (direction < 0 ? -1f : 1f);
        notificationPeek.animate().translationX(distance).alpha(0f).rotation(direction * 2f)
                .setDuration(190L).withEndAction(() -> {
                    notificationPeek.setVisibility(View.GONE);
                    notificationPeek.setTranslationX(0f);
                    notificationPeek.setTranslationY(0f);
                    notificationPeek.setRotation(0f);
                    notificationPeek.setAlpha(1f);
                }).start();
        Haptics.tap(this);
        SoundEngine.soft();
    }

    private float dp(float value) {
        return value * getResources().getDisplayMetrics().density;
    }

    private void openNotificationCenter() {
        openEdgeLayer(HomeEdgeGestureView.TOP_SIGNAL);
    }

    private void openNotificationCenterFull() {
        SoundEngine.open();
        closeEdgeLayer();
        handler.postDelayed(() -> startActivity(new Intent(this, NotificationCenterActivity.class)), 160L);
    }

    private void registerNotificationReceiver() {
        if (notificationReceiverRegistered) return;
        IntentFilter filter = new IntentFilter(AkariNotificationService.ACTION_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(notificationChanges, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(notificationChanges, filter);
        notificationReceiverRegistered = true;
    }

    private void unregisterNotificationReceiver() {
        if (!notificationReceiverRegistered) return;
        try { unregisterReceiver(notificationChanges); } catch (Exception ignored) {}
        notificationReceiverRegistered = false;
    }

    private void refreshNotificationStatus() {
        if (notificationPill == null || quickNotification == null) return;
        if (!AkariNotificationService.hasAccess(this)) {
            notificationPill.setText("CENTRO · OFF");
            notificationPill.setTextColor(0xFF9B93B3);
            quickNotification.setText("Avisos!");
            if (activeLayerEdge == HomeEdgeGestureView.TOP_SIGNAL) refreshSignalLayer();
            return;
        }
        int total = AkariNotificationService.activeCount(this);
        int unread = AkariNotificationService.unreadCount(this);
        if (unread > 0) {
            notificationPill.setText("● " + unread + " NUEVOS");
            notificationPill.setTextColor(0xFFFF2ED9);
        } else {
            notificationPill.setText("CENTRO · " + total);
            notificationPill.setTextColor(0xFF2EF0FF);
        }
        quickNotification.setText(total > 0 ? "Avisos " + total : "Avisos");
        if (activeLayerEdge == HomeEdgeGestureView.TOP_SIGNAL) refreshSignalLayer();
    }

    private void onAkariNotification(String app, String title, String kind) {
        int active = AkariNotificationService.activeCount(this);
        String line = AkariNotificationNarrator.posted(app, title, kind, active);
        if (akariLine != null) akariLine.setText(line);
        pulseDialogue();
        if (Prefs.notificationVoice()) Voice.speak(line);
        Prefs.setLastNotificationReactedAt(Prefs.lastNotificationAt());
        body.impulse("call".equals(kind) ? 110f : 55f, -70f);
        body.squash();
        if (particles != null && akariAvatar != null) {
            particles.burst(akariAvatar.getCharacterCenterX(), akariAvatar.getCharacterCenterY());
        }
        showNotificationPeek(app, title, kind);
        if (notificationPill != null) {
            notificationPill.animate().cancel();
            notificationPill.setScaleX(0.88f);
            notificationPill.setScaleY(0.88f);
            notificationPill.animate().scaleX(1f).scaleY(1f).setDuration(260).start();
        }
    }

    private void showNotificationPeek(String app, String title, String kind) {
        if (notificationPeek == null) return;
        boolean call = "call".equals(kind);
        notificationPeek.setBackgroundResource(call ? R.drawable.bg_notification_call : R.drawable.bg_notification);
        notificationPeekApp.setText((call ? "LLAMADA // " : "SEÑAL // ")
                + (app == null || app.isEmpty() ? "APP" : app.toUpperCase(Locale.getDefault())));
        String shown = Prefs.notificationPrivacy() ? "Contenido oculto · toca para abrir mi Centro"
                : title == null || title.trim().isEmpty() ? "Toca para abrir mi Centro" : title;
        notificationPeekText.setText(shown);
        notificationPeek.setContentDescription((call ? "Llamada. " : "Aviso. ") + shown
                + ". Toca para abrir el Centro AKARI o desliza para ocultar.");
        notificationPeek.setVisibility(View.VISIBLE);
        notificationPeek.setAlpha(0f);
        notificationPeek.setTranslationY(-22f);
        notificationPeek.setTranslationX(0f);
        notificationPeek.setRotation(0f);
        notificationPeek.animate().alpha(1f).translationY(0f).setDuration(220).start();
        handler.removeCallbacks(hideNotificationPeek);
        handler.postDelayed(hideNotificationPeek, call ? 12000 : 7000);
    }

    private void positionNotificationPeek() {
        if (notificationPeek == null || Build.VERSION.SDK_INT < 20) return;
        notificationPeek.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override public android.view.WindowInsets onApplyWindowInsets(View v, android.view.WindowInsets insets) {
                android.widget.FrameLayout.LayoutParams lp =
                        (android.widget.FrameLayout.LayoutParams) v.getLayoutParams();
                lp.topMargin = insets.getSystemWindowInsetTop()
                        + Math.round(42 * getResources().getDisplayMetrics().density);
                v.setLayoutParams(lp);
                return insets;
            }
        });
        notificationPeek.requestApplyInsets();
    }

    private void applyHomeChrome() {
        if (Build.VERSION.SDK_INT >= 30) {
            android.view.WindowInsetsController controller = getWindow().getInsetsController();
            if (controller == null) return;
            if (Prefs.immersiveHome()) {
                controller.hide(android.view.WindowInsets.Type.statusBars());
                controller.setSystemBarsBehavior(
                        android.view.WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            } else {
                controller.show(android.view.WindowInsets.Type.statusBars());
            }
        } else {
            int flags = Prefs.immersiveHome()
                    ? View.SYSTEM_UI_FLAG_FULLSCREEN | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                    : View.SYSTEM_UI_FLAG_VISIBLE;
            getWindow().getDecorView().setSystemUiVisibility(flags);
        }
        if (notificationPeek != null) notificationPeek.requestApplyInsets();
    }

    private void reactToPendingNotification() {
        long at = Prefs.lastNotificationAt();
        if (at <= Prefs.lastNotificationReactedAt() || System.currentTimeMillis() - at > 10 * 60 * 1000L) return;
        Prefs.setLastNotificationReactedAt(at);
        String line = AkariNotificationNarrator.returning(Prefs.lastNotificationApp(), Prefs.lastNotificationKind());
        if (akariLine != null) akariLine.setText(line);
        pulseDialogue();
        body.jiggle();
    }
}
