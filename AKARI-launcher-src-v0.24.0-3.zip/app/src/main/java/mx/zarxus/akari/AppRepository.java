package mx.zarxus.akari;

import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.text.Normalizer;

public final class AppRepository {
    private static final String[] PREFERRED_PACKAGES = new String[]{
            "com.android.chrome", "org.mozilla.firefox",
            "com.google.android.apps.messaging", "com.android.mms",
            "com.google.android.dialer", "com.android.dialer",
            "com.whatsapp", "com.android.camera2", "com.android.camera",
            "com.google.android.youtube", "com.spotify.music", "com.android.settings"
    };

    private AppRepository() {}

    public static List<AppInfo> loadLaunchable(Context ctx) {
        return loadLaunchable(ctx, false);
    }

    /** Includes apps hidden from the normal shelves so the user can always restore them. */
    public static List<AppInfo> loadAllLaunchable(Context ctx) {
        return loadLaunchable(ctx, true);
    }

    private static List<AppInfo> loadLaunchable(Context ctx, boolean includeHidden) {
        PackageManager pm = ctx.getPackageManager();
        Intent probe = new Intent(Intent.ACTION_MAIN);
        probe.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> raw = pm.queryIntentActivities(probe, 0);
        List<AppInfo> out = new ArrayList<>();
        String self = ctx.getPackageName();
        for (ResolveInfo ri : raw) {
            if (ri.activityInfo == null) continue;
            if (self.equals(ri.activityInfo.packageName)) continue;
            if (!includeHidden && Prefs.hidden(ri.activityInfo.packageName)) continue;
            ComponentName cn = new ComponentName(ri.activityInfo.packageName, ri.activityInfo.name);
            out.add(new AppInfo(
                    ri.loadLabel(pm),
                    ri.loadIcon(pm),
                    cn,
                    ri.activityInfo.packageName
            ));
        }
        Collections.sort(out, new Comparator<AppInfo>() {
            @Override
            public int compare(AppInfo a, AppInfo b) {
                return a.label.toString().compareToIgnoreCase(b.label.toString());
            }
        });
        return out;
    }

    public static List<AppInfo> filter(List<AppInfo> src, String q) {
        if (q == null || q.trim().isEmpty()) return new ArrayList<>(src);
        String n = normalized(q.trim());
        List<RankedApp> ranked = new ArrayList<>();
        for (AppInfo a : src) {
            int score = matchScore(a, n);
            if (score >= 0) ranked.add(new RankedApp(a, score));
        }
        Collections.sort(ranked, new Comparator<RankedApp>() {
            @Override public int compare(RankedApp left, RankedApp right) {
                int score = left.score - right.score;
                if (score != 0) return score;
                return left.app.label.toString().compareToIgnoreCase(right.app.label.toString());
            }
        });
        List<AppInfo> out = new ArrayList<>();
        for (RankedApp item : ranked) out.add(item.app);
        return out;
    }

    private static int matchScore(AppInfo app, String query) {
        String label = normalized(String.valueOf(app.label));
        String pkg = normalized(app.packageName == null ? "" : app.packageName);
        int score = 0;
        for (String token : query.split("\\s+")) {
            if (token.isEmpty()) continue;
            if (label.equals(token)) score += 0;
            else if (label.startsWith(token)) score += 1;
            else if (wordStarts(label, token)) score += 2;
            else if (label.contains(token)) score += 4;
            else if (pkg.contains(token)) score += 6;
            else if (token.length() >= 3 && subsequence(label, token)) score += 9;
            else return -1;
        }
        return score + Math.min(4, Math.abs(label.length() - query.length()) / 6);
    }

    static String normalized(String value) {
        if (value == null) return "";
        String base = Normalizer.normalize(value, Normalizer.Form.NFD)
                .replaceAll("\\p{M}+", "")
                .toLowerCase(Locale.ROOT);
        return base.replaceAll("[^a-z0-9]+", " ").trim();
    }

    private static boolean wordStarts(String label, String token) {
        if (label.startsWith(token)) return true;
        int at = label.indexOf(' ');
        while (at >= 0 && at + 1 < label.length()) {
            if (label.startsWith(token, at + 1)) return true;
            at = label.indexOf(' ', at + 1);
        }
        return false;
    }

    private static boolean subsequence(String label, String token) {
        int at = 0;
        for (int i = 0; i < label.length() && at < token.length(); i++) {
            if (label.charAt(i) == token.charAt(at)) at++;
        }
        return at == token.length();
    }

    private static final class RankedApp {
        final AppInfo app;
        final int score;
        RankedApp(AppInfo app, int score) {
            this.app = app;
            this.score = score;
        }
    }

    public static List<AppInfo> pickDock(List<AppInfo> all) {
        List<AppInfo> dock = new ArrayList<>();
        String pins = Prefs.dockPins();
        if (pins != null && !pins.isEmpty()) {
            for (String pkg : pins.split(",")) {
                for (AppInfo a : all) {
                    if (pkg.equals(a.packageName) && !containsPkg(dock, pkg)) {
                        dock.add(a);
                        break;
                    }
                }
            }
        }
        for (AppInfo a : UsageStore.frequentUsed(all, 8)) {
            if (dock.size() >= 5) break;
            if (!containsPkg(dock, a.packageName)) dock.add(a);
        }
        for (String pkg : PREFERRED_PACKAGES) {
            if (dock.size() >= 5) break;
            for (AppInfo a : all) {
                if (pkg.equals(a.packageName) && !containsPkg(dock, pkg)) {
                    dock.add(a);
                    break;
                }
            }
        }
        for (AppInfo a : all) {
            if (dock.size() >= 5) break;
            if (!containsPkg(dock, a.packageName)) dock.add(a);
        }
        return dock;
    }

    /** Useful first-run shelf: real usage first, then common phone tools, then alphabetical. */
    public static List<AppInfo> suggestions(List<AppInfo> all, int limit) {
        List<AppInfo> out = new ArrayList<>();
        for (AppInfo app : UsageStore.frequentUsed(all, limit)) {
            if (!containsPkg(out, app.packageName)) out.add(app);
        }
        for (String pkg : PREFERRED_PACKAGES) {
            if (out.size() >= limit) break;
            for (AppInfo app : all) {
                if (pkg.equals(app.packageName) && !containsPkg(out, pkg)) {
                    out.add(app);
                    break;
                }
            }
        }
        for (AppInfo app : all) {
            if (out.size() >= limit) break;
            if (!containsPkg(out, app.packageName)) out.add(app);
        }
        return out;
    }

    private static boolean containsPkg(List<AppInfo> list, String pkg) {
        for (AppInfo a : list) if (a.packageName.equals(pkg)) return true;
        return false;
    }
}
