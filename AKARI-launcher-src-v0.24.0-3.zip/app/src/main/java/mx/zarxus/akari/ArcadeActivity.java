package mx.zarxus.akari;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Calendar;
import java.util.List;
import java.util.Random;

public class ArcadeActivity extends Activity {
    private List<AppInfo> games;
    private int idx;
    private final Random rng = new Random();
    private TextView name, why;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_arcade);

        Insets.attach(this);        Voice.init(this);
        games = GameLib.games(this);
        name = findViewById(R.id.featureName);
        why = findViewById(R.id.featureWhy);
        ((TextView) findViewById(R.id.arcadeCount)).setText(games.size() + " juegos");
        ImageView art = findViewById(R.id.arcadeArt);
        if (Prefs.heat() >= 50) art.setImageResource(R.drawable.cg_face);

        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { SoundEngine.back(); finish(); }
        });
        findViewById(R.id.btnPlayPick).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { playCurrent(); }
        });
        findViewById(R.id.btnNextPick).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { next(1); }
        });
        findViewById(R.id.btnSurprise).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                if (!games.isEmpty()) idx = rng.nextInt(games.size());
                show();
                Voice.speak("Sorpresa. Cierra los ojos… ya no, abre ese.");
            }
        });
        findViewById(R.id.featureCard).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { playCurrent(); }
        });

        AppAdapter ad = new AppAdapter(this, R.layout.item_app);
        ad.setData(games);
        GridView grid = findViewById(R.id.gameGrid);
        grid.setAdapter(ad);
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                idx = pos;
                show();
                playCurrent();
            }
        });

        if (games.isEmpty()) {
            name.setText("Vacío");
            why.setText("No veo juegos instalados. Baja uno y vuelvo a curar la estantería.");
            Voice.speak("No tienes juegos. Instala uno y yo te lo sirvo.");
        } else {
            List<AppInfo> freq = UsageStore.frequent(games, 1);
            idx = freq.isEmpty() ? 0 : games.indexOf(freq.get(0));
            if (idx < 0) idx = 0;
            show();
        }
    }

    private void next(int d) {
        if (games.isEmpty()) return;
        idx = (idx + d + games.size()) % games.size();
        show();
    }

    private void show() {
        if (games.isEmpty()) return;
        AppInfo a = games.get(idx);
        name.setText(a.label);
        ((ImageView) findViewById(R.id.featureIcon)).setImageDrawable(a.icon);
        int h = Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
        String line = GameLib.why(a, h);
        why.setText(line);
        Voice.speak(line);
    }

    private void playCurrent() {
        if (games.isEmpty()) return;
        AppInfo a = games.get(idx);
        Voice.speak("Arranco " + a.label + ". Si ganas, me tocas. Si pierdes, también.");
        Launcher.open(this, a);
    }
}
