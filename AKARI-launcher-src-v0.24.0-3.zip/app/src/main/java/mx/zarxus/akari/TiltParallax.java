package mx.zarxus.akari;

import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.view.View;

public class TiltParallax implements SensorEventListener {
    private final SensorManager sm;
    private final Sensor sensor;
    private View far, mid;
    private AkariAvatarView avatar;
    private float tx, ty;
    private boolean running;

    public TiltParallax(Context ctx) {
        sm = (SensorManager) ctx.getSystemService(Context.SENSOR_SERVICE);
        sensor = sm != null ? sm.getDefaultSensor(Sensor.TYPE_GAME_ROTATION_VECTOR) : null;
        if (sensor == null && sm != null) {
            // fallback
        }
    }

    public void attach(View wallpaper, View card) {
        this.far = wallpaper;
        this.mid = card;
    }

    public void attachAvatar(AkariAvatarView value) {
        avatar = value;
        far = null;
        mid = null;
    }

    public void start() {
        if (!Prefs.physics() || sm == null) return;
        Sensor s = sensor != null ? sensor : sm.getDefaultSensor(Sensor.TYPE_ACCELEROMETER);
        if (s == null) return;
        sm.registerListener(this, s, SensorManager.SENSOR_DELAY_GAME);
        running = true;
    }

    public void stop() {
        if (sm != null && running) sm.unregisterListener(this);
        running = false;
        if (avatar != null) avatar.setTilt(0f, 0f);
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float ax, ay;
        if (event.sensor.getType() == Sensor.TYPE_ACCELEROMETER) {
            ax = event.values[0];
            ay = event.values[1];
        } else {
            ax = event.values.length > 0 ? event.values[0] * 8f : 0;
            ay = event.values.length > 1 ? event.values[1] * 8f : 0;
        }
        tx = tx * 0.86f + (-ax) * 2.4f;
        ty = ty * 0.86f + ay * 1.6f;
        if (far != null) {
            far.setTranslationX(tx * 1.8f);
            far.setTranslationY(ty * 1.2f);
        }
        if (mid != null) {
            mid.setTranslationX(mid.getTranslationX() * 0.4f + tx * 0.35f);
            mid.setRotation(tx * 0.12f);
        }
        if (avatar != null) {
            avatar.setTilt(clamp(tx / 18f), clamp(ty / 15f));
        }
    }

    private static float clamp(float value) {
        return Math.max(-1f, Math.min(1f, value));
    }

    @Override public void onAccuracyChanged(Sensor sensor, int accuracy) {}
}
