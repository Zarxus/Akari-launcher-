package mx.zarxus.akari;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.speech.RecognitionListener;
import android.speech.RecognizerIntent;
import android.speech.SpeechRecognizer;
import android.speech.tts.TextToSpeech;
import android.speech.tts.UtteranceProgressListener;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Set;

public final class Voice {
    public interface Listener {
        void onHeard(String text);
        void onListenState(String state);
    }

    private static TextToSpeech tts;
    private static boolean ready;
    private static String profile = "Voz del sistema · iniciando";
    private static SpeechRecognizer rec;
    private static final Handler H = new Handler(Looper.getMainLooper());

    private Voice() {}

    public static void init(Context ctx) {
        if (tts != null) return;
        final Context app = ctx.getApplicationContext();
        TextToSpeech.OnInitListener boot = new TextToSpeech.OnInitListener() {
            @Override public void onInit(int status) {
                if (status != TextToSpeech.SUCCESS || tts == null) {
                    ready = false;
                    return;
                }
                Locale[] tries = new Locale[]{
                        new Locale("es", "MX"),
                        new Locale("es", "ES"),
                        new Locale("es"),
                        Locale.getDefault()
                };
                for (Locale loc : tries) {
                    int r = tts.setLanguage(loc);
                    if (r != TextToSpeech.LANG_MISSING_DATA && r != TextToSpeech.LANG_NOT_SUPPORTED) {
                        break;
                    }
                }
                selectBestVoice();
                // Variación mínima: tonos altos y cambios bruscos hacen que el TTS suene sintético.
                tts.setPitch(1.04f);
                tts.setSpeechRate(0.96f);
                tts.setOnUtteranceProgressListener(new UtteranceProgressListener() {
                    @Override public void onStart(String utteranceId) { SoundEngine.duck(true); }
                    @Override public void onDone(String utteranceId) { SoundEngine.duck(false); }
                    @Override public void onError(String utteranceId) { SoundEngine.duck(false); }
                });
                ready = true;
            }
        };
        // Respeta el motor elegido por el propietario del teléfono.
        tts = new TextToSpeech(app, boot);
    }

    public static boolean ready() { return ready && Prefs.voice(); }

    public static String profile() { return profile; }

    public static void tune() {
        if (tts == null || !ready) return;
        float heat = Prefs.heat() / 100f;
        // Heat cambia la intención sin deformar la dicción.
        tts.setPitch(1.02f + heat * 0.07f);
        tts.setSpeechRate(0.98f - heat * 0.04f);
    }

    public static void speak(String text) {
        utter(text, true);
    }

    public static void speakQueue(String text) {
        utter(text, false);
    }

    private static void utter(String text, boolean flush) {
        if (text == null || text.trim().isEmpty()) return;
        if (!Prefs.voice() || tts == null || !ready) return;
        try {
            tune();
            SoundEngine.duck(true);
            List<String> bits = SpeechStyle.chunks(text);
            boolean first = flush;
            int i = 0;
            for (String bit : bits) {
                int mode = first ? TextToSpeech.QUEUE_FLUSH : TextToSpeech.QUEUE_ADD;
                first = false;
                tts.speak(SpeechStyle.spoken(bit), mode, null, "akari-" + (i++));
            }
        } catch (Exception ignored) {}
    }

    private static void selectBestVoice() {
        if (tts == null || Build.VERSION.SDK_INT < 21) return;
        try {
            Set<android.speech.tts.Voice> available = tts.getVoices();
            if (available == null || available.isEmpty()) return;
            android.speech.tts.Voice best = null;
            int bestScore = Integer.MIN_VALUE;
            for (android.speech.tts.Voice candidate : available) {
                Locale locale = candidate.getLocale();
                if (locale == null || !"es".equalsIgnoreCase(locale.getLanguage())) continue;
                String name = candidate.getName() == null ? "" : candidate.getName().toLowerCase(Locale.ROOT);
                int score = candidate.getQuality();
                if ("MX".equalsIgnoreCase(locale.getCountry())) score += 900;
                else if ("US".equalsIgnoreCase(locale.getCountry())) score += 450;
                else if ("ES".equalsIgnoreCase(locale.getCountry())) score += 300;
                if (name.contains("neural") || name.contains("natural") || name.contains("wavenet")
                        || name.contains("premium")) score += 500;
                if (!candidate.isNetworkConnectionRequired()) score += 80;
                if (score > bestScore) {
                    bestScore = score;
                    best = candidate;
                }
            }
            if (best != null && tts.setVoice(best) == TextToSpeech.SUCCESS) {
                Locale locale = best.getLocale();
                String place = locale == null ? "español" : locale.toLanguageTag();
                profile = "Voz instalada · " + place + " · " + best.getName();
            } else {
                profile = "Voz predeterminada · español";
            }
        } catch (Exception ignored) {
            profile = "Voz predeterminada · español";
        }
    }

    public static void readNews(List<NewsItem> items) {
        if (items == null || items.isEmpty()) {
            speak("No hay titulares para leer.");
            return;
        }
        speak("Soy AKARI. Titulares de ahora.");
        int n = Math.min(6, items.size());
        for (int i = 0; i < n; i++) {
            speakQueue("Noticia " + (i + 1) + ". " + items.get(i).title);
        }
        speakQueue("Fin del boletín. ¿Abro alguna app?");
    }

    public static void stop() {
        try { if (tts != null) tts.stop(); } catch (Exception ignored) {}
        stopListen();
    }

    public static void shutdown() {
        stop();
        try { if (tts != null) tts.shutdown(); } catch (Exception ignored) {}
        tts = null;
        ready = false;
    }

    public static boolean canListen(Context c) {
        return SpeechRecognizer.isRecognitionAvailable(c);
    }

    public static void listen(Activity act, final Listener cb) {
        stopListen();
        if (!canListen(act)) {
            if (cb != null) cb.onListenState("sin reconocedor");
            Toast.makeText(act, "Este teléfono no tiene reconocimiento de voz", Toast.LENGTH_SHORT).show();
            return;
        }
        rec = SpeechRecognizer.createSpeechRecognizer(act);
        rec.setRecognitionListener(new RecognitionListener() {
            @Override public void onReadyForSpeech(Bundle params) {
                if (cb != null) cb.onListenState("escuchando…");
            }
            @Override public void onBeginningOfSpeech() {}
            @Override public void onRmsChanged(float rmsdB) {}
            @Override public void onBufferReceived(byte[] buffer) {}
            @Override public void onEndOfSpeech() {
                if (cb != null) cb.onListenState("procesando");
            }
            @Override public void onError(int error) {
                if (cb != null) cb.onListenState("error " + error);
            }
            @Override public void onResults(Bundle results) {
                ArrayList<String> list = results.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION);
                String text = (list != null && !list.isEmpty()) ? list.get(0) : "";
                if (cb != null) cb.onHeard(text);
            }
            @Override public void onPartialResults(Bundle partialResults) {}
            @Override public void onEvent(int eventType, Bundle params) {}
        });
        Intent i = new Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM);
        i.putExtra(RecognizerIntent.EXTRA_LANGUAGE, "es-MX");
        i.putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3);
        i.putExtra(RecognizerIntent.EXTRA_PROMPT, "AKARI te escucha");
        try {
            rec.startListening(i);
            if (cb != null) cb.onListenState("mic on");
        } catch (Exception e) {
            if (cb != null) cb.onListenState("no se inició el mic");
        }
    }

    public static void stopListen() {
        if (rec != null) {
            try { rec.cancel(); } catch (Exception ignored) {}
            try { rec.destroy(); } catch (Exception ignored) {}
            rec = null;
        }
    }

    public static String handleCommand(Context ctx, String raw) {
        if (raw == null) return "No te oí.";
        String s = raw.toLowerCase(Locale.ROOT).trim();
        if (s.isEmpty()) return "No te oí.";

        if (contains(s, "noticia", "noticias", "bóletin", "boletin", "news", "lee el feed")) {
            return "NEWS";
        }
        if (contains(s, "notificaciones", "mis avisos", "centro akari", "qué llegó", "que llego",
                "mensajes nuevos", "avisos de llamada")) {
            return "NOTIFICATIONS";
        }
        if (contains(s, "alarma", "despertador", "despiértame", "despiertame", "dawn link")) return "ALARM";
        if (contains(s, "clima", "tiempo", "temperatura")) {
            return "WEATHER";
        }
        if (contains(s, "hora", "qué hora", "que hora")) {
            return "TIME";
        }
        if (contains(s, "bater", "carga")) {
            return "BATTERY";
        }
        if (contains(s, "rift", "segunda capa", "portal akari", "abre tu capa", "abre la capa")) {
            return "RIFT";
        }
        if (contains(s, "eroge", "escena", "galería", "galeria", "hentai")) {
            return "EROGE";
        }
        if (contains(s, "ajuste", "settings", "config")) {
            return "SETTINGS";
        }
        if (contains(s, "linterna", "flashlight", "luz")) {
            return "TORCH";
        }
        if (contains(s, "llama", "marcar", "teléfono", "telefono")) {
            return "PHONE";
        }
        if (contains(s, "wifi", "wi-fi")) {
            return "WIFI";
        }
        if (contains(s, "aplicaciones", "cajón", "cajon", "drawer", "taller", "atelier")) {
            return "STUDIO";
        }
        if (contains(s, "dossier", "quién eres", "quien eres", "tu ficha", "sobre ti")) {
            return "DOSSIER";
        }
        if (contains(s, "calcul", "cuánto es", "cuanto es")) {
            return "CALC";
        }
        if (contains(s, "arcade", "mis juegos", "un juego", "juegos instal")) {
            return "ARCADE";
        }
        if (contains(s, "pulse", "minijuego", "juguemos", "minijueg")) {
            return "PULSE";
        }
        if (contains(s, "ajedrez", "chess", "mate link")) {
            return "CHESS";
        }
        if (contains(s, "brújula", "brujula", "compass", "norte", "rumbo")) {
            return "COMPASS";
        }
        if (contains(s, "música", "musica", "canción", "cancion", "lounge", "pon música")) {
            return "LOUNGE";
        }
        if (contains(s, "volumen", "súbelo", "subelo", "bájalo", "bajalo", "mute")) {
            return "VOLUME";
        }
        if (contains(s, "bloquea", "bloquear", "lock screen", "apaga pantalla")) {
            return "LOCK";
        }
        if (contains(s, "permiso", "accesos", "autoriza")) {
            return "PERMS";
        }
        if (SpeechStyle.isQuestion(s) || contains(s, "busca", "búscame", "googlea", "investiga")) {
            return "ASK:" + raw;
        }

        String q = stripLaunch(s);
        List<AppInfo> all = AppRepository.loadLaunchable(ctx);
        List<AppInfo> hits = AppRepository.filter(all, q);
        if (hits.size() == 1) {
            Launcher.open(ctx, hits.get(0));
            return "OPEN:" + hits.get(0).label;
        }
        if (hits.size() > 1) {
            // pick best starts-with
            for (AppInfo a : hits) {
                if (a.label.toString().toLowerCase(Locale.ROOT).startsWith(q)) {
                    Launcher.open(ctx, a);
                    return "OPEN:" + a.label;
                }
            }
            Launcher.open(ctx, hits.get(0));
            return "OPEN:" + hits.get(0).label;
        }
        return "ASK:" + raw;
    }

    private static String stripLaunch(String s) {
        String[] prefixes = {
                "abre la app ", "abre el ", "abre la ", "abre ", "abrir ", "lanza ",
                "abre aplicación ", "abre aplicacion ", "open ", "inicia ", "pon "
        };
        for (String p : prefixes) {
            if (s.startsWith(p)) return s.substring(p.length()).trim();
        }
        return s;
    }

    private static boolean contains(String s, String... keys) {
        for (String k : keys) if (s.contains(k)) return true;
        return false;
    }

    private static String clean(String t) {
        return t.replace("·", ",").replace("✦", "").replace("⚡", "cargando ")
                .replace("🔋", "batería ").replace("☀", "sol ").replace("🌧", "lluvia ");
    }
}
