package mx.zarxus.akari;

import android.view.View;
import android.view.animation.DecelerateInterpolator;

/**
 * Spring-ish return + idle float. Not a full RK4 solver — a damped
 * harmonic feel tuned for a launcher HUD.
 */
public final class SpringSim {
    private SpringSim() {}

    public static void flingBack(final View v, float vx, float vy) {
        if (!Prefs.physics()) {
            v.animate().translationX(0).translationY(0).rotation(0)
                    .setDuration(180).start();
            return;
        }
        float dist = (float) Math.hypot(v.getTranslationX(), v.getTranslationY());
        long dur = (long) Math.max(280, Math.min(620, 260 + dist * 1.1f + Math.abs(vx + vy) * 0.02f));
        v.animate()
                .translationX(0)
                .translationY(0)
                .rotation(0)
                .scaleX(1f)
                .scaleY(1f)
                .setDuration(dur)
                .setInterpolator(new OvershootDamp())
                .start();
        SoundEngine.spring();
    }

    public static void press(View v) {
        v.animate().scaleX(0.92f).scaleY(0.92f).setDuration(80).start();
    }

    public static void release(View v) {
        v.animate().scaleX(1f).scaleY(1f).setDuration(160)
                .setInterpolator(new OvershootDamp()).start();
    }

    public static final class OvershootDamp implements android.view.animation.Interpolator {
        @Override
        public float getInterpolation(float t) {
            // e^-4t * cos(3πt) blended into settle
            float d = (float) Math.exp(-4.2 * t);
            float o = (float) Math.cos(3.1 * Math.PI * t);
            return 1f - d * (1f - t) + (1f - t) * 0.12f * o;
        }
    }

    public static final class Decel extends DecelerateInterpolator {
        public Decel() { super(1.6f); }
    }
}
