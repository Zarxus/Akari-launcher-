package mx.zarxus.akari;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.SeekBar;
import android.widget.TextView;

public class ErogeHubActivity extends Activity {
    private TextView stats;
    private TextView line;
    private AkariAvatarView avatar;
    private PortalRiftView rift;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_eroge);

        Insets.attach(this);        SoundEngine.init(this);
        SoundEngine.open();

        stats = findViewById(R.id.erogeStats);
        line = findViewById(R.id.erogeLine);
        avatar = findViewById(R.id.erogeAvatar);
        rift = findViewById(R.id.erogeRift);
        setupLiveBody();
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.back();
                finish();
            }
        });
        findViewById(R.id.btnGallery).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.click();
                startActivity(new Intent(ErogeHubActivity.this, GalleryActivity.class));
            }
        });
        findViewById(R.id.btnPlay).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.click();
                String id = nextPlayable();
                Intent i = new Intent(ErogeHubActivity.this, SceneActivity.class);
                i.putExtra(SceneActivity.EXTRA_ID, id);
                startActivity(i);
            }
        });
        findViewById(R.id.btnCooldown).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Prefs.setHeat(Math.max(0, Prefs.heat() - 25));
                SoundEngine.back();
                refresh();
            }
        });

        SeekBar heat = findViewById(R.id.cheatHeat);
        heat.setProgress(Prefs.heat());
        heat.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (fromUser) Prefs.setHeat(progress);
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) {}
            @Override public void onStopTrackingTouch(SeekBar seekBar) { refresh(); }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refresh();
    }

    private void refresh() {
        stats.setText("BOND " + Prefs.bond() + "   ·   HEAT " + Prefs.heat()
                + "\nTOQUES " + Prefs.touches() + "   ·   ESCENAS " + Prefs.scenesDone()
                + "\nRIFT " + styleName(Prefs.riftStyle()) + "   ·   POSTURA " + poseName(Prefs.poseMode())
                + "\nSiguiente desbloqueo: " + nextLockedNeed());
        if (avatar != null) {
            avatar.setHeat(Prefs.heat());
            avatar.setBond(Prefs.bond());
        }
    }

    private void setupLiveBody() {
        if (avatar == null || rift == null) return;
        rift.setProgress(1f);
        rift.setStyle(Prefs.riftStyle());
        avatar.setPortalStyle(Prefs.riftStyle());
        avatar.setPoseMode(Prefs.poseMode());
        avatar.setPortalActive(true);
        avatar.setListener(new AkariAvatarView.Listener() {
            @Override public void onBodyTouch(AkariAvatarView.Zone zone, float normalizedY, boolean hold) {
                Prefs.incTouches();
                String reaction = AkariLines.portalZone(normalizedY, hold, Prefs.poseMode(), Prefs.riftStyle());
                line.setText(reaction);
                Prefs.setLastSay(reaction);
                SoundEngine.heat();
                if (hold) SoundEngine.breath();
                Haptics.press(ErogeHubActivity.this);
                rift.pulse(avatar.getLastTouchX(), avatar.getLastTouchY());
                refresh();
            }

            @Override public void onGesture(AkariAvatarView.Gesture gesture) {
                if (gesture == AkariAvatarView.Gesture.LEFT || gesture == AkariAvatarView.Gesture.RIGHT) {
                    int delta = gesture == AkariAvatarView.Gesture.RIGHT ? 1 : -1;
                    int style = (Prefs.riftStyle() + delta + 4) % 4;
                    Prefs.setRiftStyle(style);
                    rift.setStyle(style);
                    avatar.setPortalStyle(style);
                    line.setText(AkariLines.portalGreeting(style));
                    SoundEngine.portalShift(style);
                } else if (gesture == AkariAvatarView.Gesture.UP) {
                    changePose();
                } else {
                    Prefs.setHeat(Math.max(0, Prefs.heat() - 5));
                    line.setText("Bajo un poco la intensidad sin cerrar la sesión.");
                }
                refresh();
            }

            @Override public void onDoubleTap() { changePose(); }

            @Override public void onScale(float scale) {
                line.setText(scale > 1.08f
                        ? "Acercamiento guardado. La próxima vez volveré a esta distancia."
                        : "Escala guardada. El cuerpo sigue ocupando el escenario, no una tarjeta.");
            }
        });
        line.setOnClickListener(v -> {
            Voice.init(ErogeHubActivity.this);
            Voice.speak(line.getText().toString());
        });
    }

    private void changePose() {
        int pose = (Prefs.poseMode() + 1) % 3;
        Prefs.setPoseMode(pose);
        avatar.setPoseMode(pose);
        line.setText(AkariLines.pose(pose));
        SoundEngine.portalShift(Prefs.riftStyle());
        Haptics.rift(this);
        refresh();
    }

    private String styleName(int value) {
        return new String[]{"NEXUS", "VIOLETA", "DAWN", "CRIMSON"}[Math.max(0, Math.min(3, value))];
    }

    private String poseName(int value) {
        return new String[]{"CALMA", "PULSO", "GUARDIA"}[Math.max(0, Math.min(2, value))];
    }

    private String nextPlayable() {
        SceneCatalog.Scene best = SceneCatalog.all().get(0);
        for (SceneCatalog.Scene s : SceneCatalog.all()) {
            if (Prefs.bond() >= s.needBond) best = s;
        }
        return best.id;
    }

    private String nextLockedNeed() {
        for (SceneCatalog.Scene s : SceneCatalog.all()) {
            if (Prefs.bond() < s.needBond) return s.title + " @ bond " + s.needBond;
        }
        return "todo desbloqueado";
    }
}
