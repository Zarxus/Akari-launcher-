#!/usr/bin/env sh
# Fallback for compact Java runtimes that ship jdk.compiler but omit the javac launcher.
exec java -m jdk.compiler/com.sun.tools.javac.Main "$@"
