package mx.zarxus.akari;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.view.MotionEvent;
import android.view.View;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;

import java.util.Random;

public class PulseActivity extends Activity {
    private static final String[] ZONES = {"cabeza", "pecho", "cadera", "piernas"};
    private final Handler h = new Handler(Looper.getMainLooper());
    private final Random rng = new Random();
    private TextView call, scoreTv, hint;
    private ProgressBar bar;
    private ImageView art;
    private boolean running;
    private int target, score, combo, round, left;
    private long until;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_pulse);

        Insets.attach(this);        Voice.init(this);
        call = findViewById(R.id.pulseCall);
        scoreTv = findViewById(R.id.pulseScore);
        hint = findViewById(R.id.pulseHint);
        bar = findViewById(R.id.pulseBar);
        art = findViewById(R.id.pulseArt);
        ((TextView) findViewById(R.id.pulseBest)).setText("récord " + Prefs.pulseBest());
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { SoundEngine.back(); finish(); }
        });
        findViewById(R.id.btnPulseGo).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { startRun(); }
        });
        art.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                if (e.getAction() != MotionEvent.ACTION_DOWN || !running) return true;
                float ny = e.getY() / Math.max(1, v.getHeight());
                int zone = ny < 0.22f ? 0 : ny < 0.48f ? 1 : ny < 0.72f ? 2 : 3;
                hit(zone);
                return true;
            }
        });
        Voice.speak("Pulse Link. Toca donde yo diga. No te adelantes.");
    }

    private void startRun() {
        running = true;
        score = combo = round = 0;
        Prefs.addHeat(2);
        nextBeat();
    }

    private void nextBeat() {
        if (!running) return;
        if (round >= 12) {
            endRun();
            return;
        }
        round++;
        target = rng.nextInt(4);
        int window = Math.max(700, 1400 - round * 55);
        until = System.currentTimeMillis() + window;
        left = window;
        call.setText("¡" + ZONES[target].toUpperCase() + "!");
        Voice.speak(ZONES[target]);
        if (target >= 2 && Prefs.heat() >= 40) art.setImageResource(R.drawable.cg_jacket);
        if (Prefs.heat() >= 70) art.setImageResource(R.drawable.cg_face);
        tickBar();
    }

    private void tickBar() {
        if (!running) return;
        long rem = until - System.currentTimeMillis();
        if (rem <= 0) {
            miss("Se acabó el pulso.");
            return;
        }
        bar.setProgress((int) (rem * 100 / Math.max(1, left)));
        h.postDelayed(new Runnable() {
            @Override public void run() { tickBar(); }
        }, 16);
    }

    private void hit(int zone) {
        if (zone == target) {
            combo++;
            score += 100 + combo * 20;
            Prefs.addHeat(1);
            hint.setText("Bien. " + ZONES[zone] + ".");
            Launcher.haptic(this);
            SoundEngine.heat();
            scoreTv.setText(score + "  ·  combo " + combo);
            nextBeat();
        } else {
            miss("Esa no. Pedí " + ZONES[target] + ".");
        }
    }

    private void miss(String why) {
        combo = 0;
        hint.setText(why);
        scoreTv.setText(score + "  ·  combo 0");
        Voice.speak(why);
        if (round >= 12) endRun();
        else nextBeat();
    }

    private void endRun() {
        running = false;
        h.removeCallbacksAndMessages(null);
        if (score > Prefs.pulseBest()) Prefs.setPulseBest(score);
        ((TextView) findViewById(R.id.pulseBest)).setText("récord " + Prefs.pulseBest());
        call.setText("Fin. " + score + " pts.");
        Voice.speak("Se acabó el link. Hiciste " + score + " puntos. ¿Otra ronda o un juego de verdad?");
        Prefs.addBond(1);
    }

    @Override
    protected void onPause() {
        super.onPause();
        running = false;
        h.removeCallbacksAndMessages(null);
    }
}
