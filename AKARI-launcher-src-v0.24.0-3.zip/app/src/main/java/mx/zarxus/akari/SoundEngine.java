package mx.zarxus.akari;

import android.content.Context;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.media.SoundPool;

public final class SoundEngine {
    private static SoundPool pool;
    private static int click, open, back, heat, unlock, spring, breath, scene, dock, move, capture, calc, news;
    private static MediaPlayer ambient;
    private static boolean loaded;
    private static int lastLayerStep = -1;
    private static long lastLayerAt;

    public static void init(Context ctx) {
        if (loaded) return;
        AudioAttributes aa = new AudioAttributes.Builder()
                .setUsage(AudioAttributes.USAGE_GAME)
                .setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION)
                .build();
        pool = new SoundPool.Builder().setMaxStreams(6).setAudioAttributes(aa).build();
        Context c = ctx.getApplicationContext();
        click = pool.load(c, R.raw.sfx_click, 1);
        open = pool.load(c, R.raw.sfx_open, 1);
        back = pool.load(c, R.raw.sfx_back, 1);
        heat = pool.load(c, R.raw.sfx_heat, 1);
        unlock = pool.load(c, R.raw.sfx_unlock, 1);
        spring = pool.load(c, R.raw.sfx_spring, 1);
        breath = pool.load(c, R.raw.sfx_breath, 1);
        scene = pool.load(c, R.raw.sfx_scene, 1);
        dock = pool.load(c, R.raw.sfx_dock, 1);
        move = pool.load(c, R.raw.sfx_move, 1);
        capture = pool.load(c, R.raw.sfx_capture, 1);
        calc = pool.load(c, R.raw.sfx_calc, 1);
        news = pool.load(c, R.raw.sfx_news, 1);
        loaded = true;
    }

    private static void play(int id, float vol) {
        play(id, vol, 1f);
    }

    private static void play(int id, float vol, float rate) {
        if (!loaded || !Prefs.sound() || pool == null) return;
        float scaled = Math.max(0f, Math.min(1f, vol * Prefs.soundScale()));
        if (scaled <= .001f) return;
        pool.play(id, scaled, scaled, 1, 0, Math.max(.5f, Math.min(1.7f, rate)));
    }

    public static void click() { play(click, 0.55f); }
    public static void open() { play(open, 0.65f); }
    public static void back() { play(back, 0.55f); }
    public static void heat() { play(heat, 0.7f); }
    public static void unlock() { play(unlock, 0.8f); }
    public static void spring() { play(spring, 0.4f); }
    public static void breath() { play(breath, 0.75f); }
    public static void scene() { play(scene, 0.7f); }
    public static void dock() { play(dock, .68f, .96f + (float)Math.random()*.08f); }
    public static void move() { play(move, .65f, .96f + (float)Math.random()*.06f); }
    public static void capture() { play(capture, .82f); }
    public static void calc() { play(calc, .48f, .94f + (float)Math.random()*.12f); }
    public static void news() { play(news, .58f); }
    public static void compass() { play(move, .20f, 1.42f); }
    public static void soft() { play(click, .24f, 1.12f); }
    public static void confirm() {
        play(move, .34f, 1.08f);
        play(open, .24f, 1.22f);
    }

    public static void portalOpen() {
        play(spring, .42f, .74f);
        play(open, .64f, 1.16f);
        play(move, .28f, 1.44f);
    }

    public static void portalShift(int style) {
        float rate = .86f + Math.max(0, Math.min(3, style)) * .14f;
        play(move, .42f, rate);
        play(click, .24f, Math.min(1.62f, rate * 1.18f));
    }

    public static void portalClose() {
        play(back, .48f, .88f);
        play(spring, .25f, .68f);
    }

    public static void layerGrab(int edge) {
        lastLayerStep = -1;
        lastLayerAt = 0L;
        float tone = .82f + Math.max(1, Math.min(4, edge)) * .11f;
        play(move, .22f, tone);
        play(click, .12f, Math.min(1.6f, tone * 1.12f));
    }

    public static void layerThreshold(boolean opening) {
        play(spring, .22f, opening ? 1.16f : .84f);
    }

    public static void layerSlide(int edge, float progress) {
        int step = Math.max(0, Math.min(10, Math.round(progress * 10f)));
        long now = System.currentTimeMillis();
        if (step == lastLayerStep || now - lastLayerAt < 42L) return;
        lastLayerStep = step;
        lastLayerAt = now;
        float edgeTone = .72f + Math.max(1, Math.min(4, edge)) * .08f;
        play(move, .075f, Math.min(1.62f, edgeTone + step * .045f));
    }

    public static void layerRelease(boolean openLayer, int edge) {
        float signature = .88f + Math.max(1, Math.min(4, edge)) * .075f;
        if (openLayer) {
            play(open, .45f, signature);
            play(move, .24f, Math.min(1.62f, signature * 1.22f));
        } else {
            play(back, .38f, Math.max(.62f, signature * .82f));
            play(spring, .17f, .72f);
        }
    }

    public static void appTouch(String packageName) {
        float tone = signature(packageName, .88f, 1.18f);
        play(click, .24f, tone);
        play(move, .13f, Math.min(1.65f, tone * 1.18f));
    }

    public static void appHold(String packageName) {
        float tone = signature(packageName, .76f, 1.08f);
        play(heat, .28f, tone);
        play(spring, .20f, Math.min(1.65f, tone * 1.24f));
    }

    public static void appLaunch(String packageName) {
        float tone = signature(packageName, .90f, 1.12f);
        play(dock, .54f, tone);
        play(open, .43f, Math.min(1.65f, tone * 1.07f));
    }

    private static float signature(String value, float low, float high) {
        int hash = value == null ? 0 : value.hashCode();
        float unit = (hash & 0x7fffffff) % 997 / 996f;
        return low + unit * (high - low);
    }

    public static void startAmbient(Context ctx) {
        if (!Prefs.sound() || !Prefs.ambient()) return;
        stopAmbient();
        try {
            ambient = MediaPlayer.create(ctx.getApplicationContext(), R.raw.sfx_ambient);
            if (ambient == null) return;
            ambient.setLooping(true);
            float base = ambientVolume();
            ambient.setVolume(base, base);
            ambient.start();
        } catch (Exception ignored) {}
    }

    public static void duck(boolean on) {
        if (ambient == null) return;
        try {
            float base = ambientVolume();
            float v = on ? base * .22f : base;
            ambient.setVolume(v, v);
        } catch (Exception ignored) {}
    }

    public static void refreshAmbientVolume() {
        if (ambient == null) return;
        try {
            float value = ambientVolume();
            ambient.setVolume(value, value);
        } catch (Exception ignored) {}
    }

    private static float ambientVolume() {
        float base = Prefs.heat() > 70 ? .19f : .25f;
        return Math.max(0f, Math.min(.30f, base * Prefs.ambientScale()));
    }

    public static void stopAmbient() {
        if (ambient != null) {
            try { ambient.stop(); } catch (Exception ignored) {}
            try { ambient.release(); } catch (Exception ignored) {}
            ambient = null;
        }
    }
}
