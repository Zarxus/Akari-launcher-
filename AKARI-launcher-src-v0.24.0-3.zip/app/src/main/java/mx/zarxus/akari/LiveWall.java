package mx.zarxus.akari;

import android.graphics.drawable.AnimationDrawable;
import android.graphics.drawable.Drawable;
import android.view.View;
import android.widget.ImageView;

public final class LiveWall {
    private LiveWall() {}

    public static void apply(ImageView iv) {
        if (iv == null) return;
        if (!Prefs.liveWall()) {
            iv.setImageResource(Prefs.wallpaper() == 1
                    ? R.drawable.wallpaper_room : R.drawable.wallpaper_nexus);
            return;
        }
        iv.setImageResource(R.drawable.wallpaper_live);
        Drawable d = iv.getDrawable();
        if (d instanceof AnimationDrawable) {
            final AnimationDrawable ad = (AnimationDrawable) d;
            iv.post(new Runnable() {
                @Override public void run() { ad.start(); }
            });
        }
    }

    public static void stop(ImageView iv) {
        if (iv == null) return;
        Drawable d = iv.getDrawable();
        if (d instanceof AnimationDrawable) ((AnimationDrawable) d).stop();
    }
}
