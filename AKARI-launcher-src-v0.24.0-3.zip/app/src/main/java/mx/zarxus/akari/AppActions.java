package mx.zarxus.akari;

import android.app.Activity;
import android.app.AlertDialog;
import android.widget.Toast;

/** One consistent long-press menu for every application shelf. */
public final class AppActions {
    public interface Callback { void onAppsChanged(); }

    private AppActions() {}

    public static void show(final Activity activity, final AppInfo app, final Callback callback) {
        if (activity == null || app == null) return;
        final boolean pinned = Prefs.pinned(app.packageName);
        final boolean hidden = Prefs.hidden(app.packageName);
        SoundEngine.appHold(app.packageName);
        Haptics.press(activity);

        CharSequence[] actions = new CharSequence[]{
                "Abrir",
                pinned ? "Quitar del dock" : "Fijar en el dock",
                hidden ? "Volver a mostrar" : "Ocultar del launcher",
                "Información y permisos",
                "Desinstalar"
        };
        AlertDialog dialog = new AlertDialog.Builder(activity)
                .setTitle(app.label)
                .setItems(actions, (whichDialog, which) -> {
                    if (which == 0) {
                        Launcher.open(activity, app);
                        return;
                    }
                    if (which == 1) {
                        Prefs.togglePin(app.packageName);
                        SoundEngine.confirm();
                        Haptics.success(activity);
                        toast(activity, pinned ? "Quitada del dock" : "Fijada en el dock");
                        changed(callback);
                    } else if (which == 2) {
                        if (!hidden && Prefs.pinned(app.packageName)) Prefs.togglePin(app.packageName);
                        Prefs.toggleHidden(app.packageName);
                        SoundEngine.confirm();
                        Haptics.success(activity);
                        toast(activity, hidden ? "Visible otra vez: " + app.label : "Oculta: " + app.label);
                        changed(callback);
                    } else if (which == 3) {
                        QuickActions.appInfo(activity, app.packageName);
                    } else if (which == 4) {
                        QuickActions.uninstall(activity, app.packageName);
                    }
                })
                .setNegativeButton("CANCELAR", null)
                .create();
        dialog.setOnShowListener(ignored -> SoundEngine.soft());
        dialog.show();
    }

    private static void changed(Callback callback) {
        if (callback != null) callback.onAppsChanged();
    }

    private static void toast(Activity activity, String value) {
        Toast.makeText(activity, value, Toast.LENGTH_SHORT).show();
    }
}
