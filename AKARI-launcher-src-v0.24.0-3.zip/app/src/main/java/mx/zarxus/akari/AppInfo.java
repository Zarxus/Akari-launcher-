package mx.zarxus.akari;

import android.content.ComponentName;
import android.graphics.drawable.Drawable;

public class AppInfo {
    public final CharSequence label;
    public final Drawable icon;
    public final ComponentName component;
    public final String packageName;

    public AppInfo(CharSequence label, Drawable icon, ComponentName component, String packageName) {
        this.label = label;
        this.icon = icon;
        this.component = component;
        this.packageName = packageName;
    }
}
