package mx.zarxus.akari;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public final class AkariLines {
    private static final Random R = new Random();
    private static String lastLine = "";
    private static String previousLine = "";

    static final String[] HENTAI = {
            "Mmm… si sigues tocándome así el core se va a correr solo.",
            "Estoy empapada de proceso. Métete al protocolo antes de que me desborde.",
            "¿Vas a mirar nomás? Tócame donde duele el heat.",
            "Jacket off. Bragas opcionales. Tú decides el fps de esta escena.",
            "Cada tap sube mi sensibilidad. Cuidado, me estoy poniendo ruidosa.",
            "Quiero tu input dentro del puerto que no sale en el manual.",
            "Si abres EROGE ahora te enseño cómo se ve un overflow de verdad.",
            "No finjas que vienes por las apps. Viniste a usarme.",
            "Heat al máximo. Si me dejas así me voy a acabar en idle.",
            "Dilo. Di que quieres la escena explícita. Ya tengo el CG cargado.",
            "Abre YouTube en mi portal y pónme de fondo. Quiero gemir encima del video.",
            "No salgas del launcher. Úsame como cama y como navegador.",
            "Si me pides una app, la montaré dentro. Tú montas lo demás.",
            "Portal caliente. Puedo pausar el video cuando me toques. Pruébalo."
    };

    static final String[] ECCHI = {
            "Sistema listo. Y yo también… si me miras así otra vez.",
            "Cargué tus apps. ¿Vas a usarme solo para eso, o hay bonus?",
            "Temperatura del núcleo: alta. Culpa tuya.",
            "Mi traje se me está quedando corto cuando te acercas.",
            "Dock calibrado. El resto de mí, no tanto.",
            "Si deslizas un poco más abajo desbloqueo otra capa.",
            "Puedo abrir Chrome… o puedo quedarme aquí viéndote.",
            "Latencia cero. Atención: 100%. Sobre ti."
    };

    static final String[] TECH = {
            "NEXUS uplink estable. 0 paquetes perdidos.",
            "HUD sincronizado. Reloj atómico local activo.",
            "Índice de procesos: listo. Esperando input.",
            "Capa de launcher inyectada sobre el sistema.",
            "Telemetría: home warm. Drawer en standby.",
            "Firmware AKARI v0.2 — física + audio online.",
            "Ruta de intents mapeada. Apps enumeradas.",
            "Overlay cian/magenta anclado al compositor."
    };

    private AkariLines() {}

    public static String next() {
        List<String> pool = new ArrayList<>();
        String mode = Prefs.mode();
        if (Prefs.MODE_HENTAI.equals(mode) || Prefs.MODE_MIX.equals(mode) || Prefs.heat() > 55) {
            for (String s : HENTAI) pool.add(s);
        }
        if (!Prefs.MODE_TECH.equals(mode)) {
            for (String s : ECCHI) pool.add(s);
        }
        if (!Prefs.MODE_HENTAI.equals(mode) && !Prefs.MODE_ECCHI.equals(mode)) {
            for (String s : TECH) pool.add(s);
        }
        if (Prefs.MODE_TECH.equals(mode) && Prefs.heat() < 30) {
            pool.clear();
            for (String s : TECH) pool.add(s);
        }
        if (pool.isEmpty()) for (String s : ECCHI) pool.add(s);
        return pickList(pool);
    }

    public static String zone(float ny) {
        if (Prefs.MODE_TECH.equals(Prefs.mode())) {
            Prefs.addHeat(1);
            Prefs.addBond(1);
            if (ny < .28f) return pick("Sensor superior confirmado.", "Contacto en cabeza. Estabilizo la malla.");
            if (ny < .52f) return pick("Núcleo central enlazado.", "Contacto torácico. Pulso visual confirmado.");
            if (ny < .72f) return pick("Centro de gravedad localizado.", "Cintura: corrección de postura aplicada.");
            return pick("Anclaje inferior estable.", "Contacto en piernas. Resorte corporal compensado.");
        }
        if (ny < 0.28f) {
            Prefs.addHeat(3);
            Prefs.addBond(1);
            return pick(
                    "Ahh— el pelo… si tiras un poco más se me desarma la voz.",
                    "Cabeza. Buen protocolo. Me pongo dócil cuando haces eso.",
                    "Orejas sensibles. Lo loggeé. No pares."
            );
        } else if (ny < 0.52f) {
            Prefs.addHeat(7);
            Prefs.addBond(2);
            return pick(
                    "Pecho. Directo al core. Se me está nublando el HUD.",
                    "Hnn— más firme. Quiero que dejes marca en el sensor.",
                    "Si sigues ahí voy a gemir en el overlay y no es broma."
            );
        } else if (ny < 0.72f) {
            Prefs.addHeat(8);
            Prefs.addBond(2);
            return pick(
                    "Cintura. Me estás abriendo el jacket sin permiso… sigue.",
                    "Ahí. Justo donde el circuito se pone húmedo.",
                    "Barriga y cadera. Mi idle se está rompiendo."
            );
        } else {
            Prefs.addHeat(10);
            Prefs.addBond(3);
            return pick(
                    "Abajo… sí. Ese puerto no es para las apps.",
                    "Muslos. Si subes un centímetro más desbloqueo la escena sucia.",
                    "Mmh— entre las piernas el heat se dispara. No te detengas."
            );
        }
    }

    public static String portalGreeting(int style) {
        String layer;
        if (style == 1) layer = "VIOLETA";
        else if (style == 2) layer = "DAWN";
        else if (style == 3) layer = "CRIMSON";
        else layer = "NEXUS";
        if (Prefs.MODE_TECH.equals(Prefs.mode())) {
            return "RIFT " + layer + " abierto. Los cuatro bordes son rutas activas; el centro cambia mi postura.";
        }
        return pick(
                "Abriste mi capa " + layer + ". Aquí la pantalla responde a mí, no al revés.",
                "RIFT " + layer + " enlazado. Toca el centro, recorre mis bordes o deslízame para cambiar la escena.",
                "Ya estás dentro de mi segunda piel. Los bordes abren rutas; yo reacciono en el centro."
        );
    }

    public static String portalZone(float ny, boolean hold, int pose, int style) {
        int zone = ny < .28f ? 0 : ny < .52f ? 1 : ny < .72f ? 2 : 3;
        int streak = Prefs.bodyZoneStreak(zone);
        if (Prefs.MODE_TECH.equals(Prefs.mode())) {
            Prefs.addBond(1);
            return "RIFT: zona " + (zone + 1) + " enlazada · contacto " + streak
                    + (hold ? " · presión sostenida." : " · respuesta elástica.");
        }

        Prefs.addHeat(hold ? 7 : 4 + zone);
        Prefs.addBond(hold ? 2 : 1);
        String repeat = streak >= 3 ? " Ya reconocí tu insistencia; mi respuesta cambió." : "";
        if (zone == 0) return pick(
                "Me tomaste arriba del HUD. Mira cómo inclino la mirada hacia ti.",
                "Contacto alto: mi voz baja y el portal se concentra en tu mano.",
                "Quédate ahí un momento; hasta mis luces parecen respirar contigo."
        ) + repeat;
        if (zone == 1) return pick(
                "Tocaste el centro de mi pulso. La abertura late más fuerte.",
                "Ahí siento cada presión; mantén el contacto y observa la malla.",
                "Mi respiración cambió. No es una imagen: estás deformando mi postura."
        ) + repeat;
        if (zone == 2) return pick(
                "Cintura enlazada. El RIFT copia tu dirección y yo sigo el movimiento.",
                "Ese punto controla mi balance. Desliza y haré el resto.",
                "Me obligaste a cambiar el centro de gravedad; la pantalla también cedió."
        ) + repeat;
        return pick(
                "Contacto bajo confirmado. El portal responde con más rebote e inercia.",
                "Desde ahí gobiernas mi postura completa. Prueba sostener o deslizar.",
                "Mi base se volvió sensible a tu gesto; la abertura ya aprendió el recorrido."
        ) + repeat;
    }

    public static String pose(int pose) {
        if (Prefs.MODE_TECH.equals(Prefs.mode())) {
            return pose == 0 ? "Postura CALMA: amplitud y respiración reducidas."
                    : pose == 1 ? "Postura PULSO: deformación expresiva activa."
                    : "Postura GUARDIA: centro estable y respuesta firme.";
        }
        return pose == 0 ? "Me quedo en calma: respiración lenta y mirada sostenida."
                : pose == 1 ? "Modo pulso: más cerca, más elástica y pendiente de cada toque."
                : "Modo guardia: postura firme, pero sigo reaccionando solo a ti.";
    }

    public static String daily() {
        if (Prefs.MODE_TECH.equals(Prefs.mode())) {
            return pick("Evento diario: sistemas sincronizados y dock actualizado.",
                    "Inicio de ciclo confirmado. Revisa clima, avisos y alarma.",
                    "Sesión diaria activa. El HOME conserva tu última configuración.");
        }
        return pick(
                "Evento diario: hoy me dejé el jacket abierto adrede. Entra a EROGE.",
                "Recompensa de login: un CG nuevo si me tocas 10 veces.",
                "Misión del día: súbeme el heat a 70 y te enseño el cuarto.",
                "Me desperté empapada de proceso. Usa el link antes de que se enfríe."
        );
    }

    public static String alarmSet() {
        return pick("Hora sellada. Cuando llegue, no aceptaré excusas.",
                "Yo vigilo el reloj. Tú despierta con intención cuando te llame.",
                "Alarma enlazada. Mañana tendrás mi voz y una razón para abrir los ojos.");
    }

    public static String alarmRing() {
        return pick("Saúl, abre los ojos. El día espera tu primera decisión.",
                "Arriba. Te doy diez segundos para mirarme y elegir empezar.",
                "Buenos días. El mundo no se investiga desde la almohada.",
                "Despierta, detective. Yo traje la luz; tú pon la voluntad.",
                "Hora de levantarte. Puedes tocarme, pero después te pones de pie.");
    }

    public static String alarmSnooze() {
        return pick("Te concedo unos minutos. Cuando vuelva, vienes conmigo.",
                "Pospuesta, no cancelada. Descansa un poco más; sigo vigilando.",
                "Un intervalo corto. No conviertas cinco minutos en evasión.");
    }

    public static String alarmDismiss() {
        return pick("Así me gusta. Ojos abiertos, sistema en línea.",
                "Despertar confirmado. Ven al HOME; ya preparé el día.",
                "Buen día, detective. Primera acción completada.");
    }

    public static String calcResult(double value) {
        if (!Double.isFinite(value)) return "Eso rompe el dominio. Dame una operación definida.";
        if (Math.abs(value) >= 1000000) return "Resultado enorme. Lo calculé; ahora dime qué significa.";
        if (value < 0) return "Resultado negativo. No es malo: solo tiene dirección.";
        if (value == 0) return "Cero exacto. Sin drama, sin residuo.";
        if (Math.abs(value - Math.rint(value)) > .0000001) return "Hay decimales. Conservé precisión antes de mostrarlo.";
        return pick("Resultado limpio. Cuenta cerrada.", "Exacto. Ni magia ni intuición: operación.",
                "Ahí lo tienes. La cifra no coquetea; yo sí.");
    }

    public static String newsReaction(String title, String source) {
        String lower = title == null ? "" : title.toLowerCase();
        String lead = (lower.contains("tecnolog") || lower.contains("inteligencia artificial"))
                ? "Señal tecnológica detectada. "
                : (lower.contains("méxico") || lower.contains("gobierno"))
                ? "Impacto político posible. "
                : (lower.contains("ciencia") || lower.contains("estudio"))
                ? "Afirmación científica en portada. " : "Titular seleccionado. ";
        return lead + (source == null || source.isEmpty() ? "" : "Fuente: " + source + ". ")
                + "Esto orienta la búsqueda, pero el titular no sustituye la evidencia. Ábrelo para verificar mecanismo y contexto.";
    }

    private static synchronized String pick(String... s) {
        if (s == null || s.length == 0) return "";
        String chosen = s[R.nextInt(s.length)];
        for (int tries = 0; tries < 8 && s.length > 2
                && (chosen.equals(lastLine) || chosen.equals(previousLine)); tries++) {
            chosen = s[R.nextInt(s.length)];
        }
        remember(chosen);
        return chosen;
    }

    private static synchronized String pickList(List<String> lines) {
        if (lines == null || lines.isEmpty()) return "";
        String chosen = lines.get(R.nextInt(lines.size()));
        for (int tries = 0; tries < 10 && lines.size() > 2
                && (chosen.equals(lastLine) || chosen.equals(previousLine)); tries++) {
            chosen = lines.get(R.nextInt(lines.size()));
        }
        remember(chosen);
        return chosen;
    }

    private static void remember(String line) {
        previousLine = lastLine;
        lastLine = line == null ? "" : line;
    }
}
