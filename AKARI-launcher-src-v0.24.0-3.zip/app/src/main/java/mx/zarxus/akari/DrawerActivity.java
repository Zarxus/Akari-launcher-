package mx.zarxus.akari;

import android.app.Activity;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.KeyEvent;
import android.view.View;
import android.view.inputmethod.EditorInfo;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.TextView;

import java.util.List;

public class DrawerActivity extends Activity {
    public static final String EXTRA_QUERY = "q";

    private List<AppInfo> all;
    private AppAdapter adapter;
    private TextView count;
    private EditText search;
    private List<AppInfo> filtered;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_drawer);

        Insets.attach(this);
        SoundEngine.init(this);
        all = AppRepository.loadLaunchable(this);
        adapter = new AppAdapter(this, R.layout.item_app);
        adapter.setData(all);

        GridView grid = findViewById(R.id.grid);
        grid.setAdapter(adapter);
        grid.setEmptyView(findViewById(R.id.emptyApps));
        grid.setContentDescription("Aplicaciones instaladas. Toca para abrir y mantén para ver acciones.");
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final AppInfo app = adapter.getItem(position);
                DockMotion.launchWave(view);
                Haptics.press(DrawerActivity.this);
                view.postDelayed(new Runnable() {
                    @Override public void run() { Launcher.open(DrawerActivity.this, app); }
                }, 105);
            }
        });
        grid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override public boolean onItemLongClick(AdapterView<?> parent, View view, int position, long id) {
                final AppInfo app = adapter.getItem(position);
                AppActions.show(DrawerActivity.this, app, () -> {
                    all = AppRepository.loadLaunchable(DrawerActivity.this);
                    applyFilter(search.getText().toString());
                });
                return true;
            }
        });

        count = findViewById(R.id.appCount);
        updateCount(all.size());
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { SoundEngine.back(); finish(); }
        });

        search = findViewById(R.id.search);
        search.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {}
            @Override public void afterTextChanged(Editable s) {
                applyFilter(s.toString());
            }
        });
        search.setOnEditorActionListener(new TextView.OnEditorActionListener() {
            @Override public boolean onEditorAction(TextView v, int actionId, KeyEvent event) {
                if (actionId != EditorInfo.IME_ACTION_SEARCH && actionId != EditorInfo.IME_ACTION_DONE) return false;
                if (filtered != null && !filtered.isEmpty()) {
                    Launcher.open(DrawerActivity.this, filtered.get(0));
                    return true;
                }
                return false;
            }
        });
        String q = getIntent().getStringExtra(EXTRA_QUERY);
        if (q != null && !q.isEmpty()) search.setText(q);
        else applyFilter("");
    }

    private void applyFilter(String query) {
        filtered = AppRepository.filter(all, query);
        adapter.setData(filtered);
        updateCount(filtered.size());
        TextView empty = findViewById(R.id.emptyApps);
        if (empty != null) {
            boolean hasQuery = query != null && !query.trim().isEmpty();
            empty.setText(hasQuery
                    ? "SIN COINCIDENCIAS\nPrueba otro nombre o abre la búsqueda web desde HOME."
                    : "SIN APLICACIONES VISIBLES\nPuedes restaurarlas desde el estante OCULTAS del Taller.");
        }
    }

    private void updateCount(int n) {
        count.setText(n == 1 ? "1 APP" : n + " APPS");
    }
}
