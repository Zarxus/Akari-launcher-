package mx.zarxus.akari;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.NotificationManager;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.media.AudioAttributes;
import android.media.MediaPlayer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.VibrationEffect;
import android.os.Vibrator;
import android.view.View;
import android.view.WindowManager;
import android.widget.ImageView;
import android.widget.TextView;
import java.text.DateFormat;
import java.util.Date;

public class AlarmRingActivity extends Activity {
    public static final String EXTRA_TEST = "test";
    private final Handler h = new Handler(Looper.getMainLooper());
    private MediaPlayer player;
    private Vibrator vibrator;
    private ObjectAnimator breathe;
    private float volume;
    private boolean stopped;
    private final Runnable ramp = new Runnable() {
        @Override public void run() {
            if (player == null || stopped) return;
            volume = Math.min(1f, volume + .055f);
            try { player.setVolume(volume, volume); } catch (Exception ignored) {}
            if (volume < 1f) h.postDelayed(this, 2500);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        if (Build.VERSION.SDK_INT >= 27) { setShowWhenLocked(true); setTurnScreenOn(true); }
        else getWindow().addFlags(WindowManager.LayoutParams.FLAG_SHOW_WHEN_LOCKED
                | WindowManager.LayoutParams.FLAG_TURN_SCREEN_ON | WindowManager.LayoutParams.FLAG_DISMISS_KEYGUARD);
        getWindow().addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON);
        setContentView(R.layout.activity_alarm_ring);
        Insets.attach(this);
        SoundEngine.init(this);
        Voice.init(this);
        TextView clock = findViewById(R.id.alarmRingClock);
        TextView label = findViewById(R.id.alarmRingLabel);
        TextView line = findViewById(R.id.alarmRingLine);
        ImageView art = findViewById(R.id.alarmRingArt);
        clock.setText(DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date()));
        label.setText(Prefs.alarmLabel().toUpperCase());
        TextView snoozeButton = findViewById(R.id.alarmSnooze);
        TextView dismissButton = findViewById(R.id.alarmDismiss);
        snoozeButton.setText("POSPONER · " + Prefs.alarmSnoozeMinutes() + " MIN");
        String wake = AkariLines.alarmRing();
        line.setText(wake);
        breathe = ObjectAnimator.ofFloat(art, View.SCALE_X, 1f, 1.035f, 1f);
        breathe.setDuration(2600); breathe.setRepeatCount(ObjectAnimator.INFINITE); breathe.start();
        art.setOnClickListener(v -> { line.setText(AkariLines.alarmRing()); Voice.speak(line.getText().toString()); });
        snoozeButton.setOnClickListener(v -> snooze());
        dismissButton.setOnClickListener(v -> dismiss());
        DockMotion.bind(snoozeButton);
        DockMotion.bind(dismissButton);
        ring();
        h.postDelayed(() -> Voice.speak(Prefs.alarmLabel() + ". " + wake), 1300);
    }

    private void ring() {
        try {
            NotificationManager notices = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
            if (notices != null) notices.cancel(AlarmReceiver.NOTICE);
            player = new MediaPlayer();
            player.setAudioAttributes(new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build());
            AssetFileDescriptor audio = getResources().openRawResourceFd(R.raw.sfx_alarm);
            if (audio == null) throw new IllegalStateException("No alarm audio");
            player.setDataSource(audio.getFileDescriptor(), audio.getStartOffset(), audio.getLength());
            audio.close();
            player.setLooping(true);
            player.prepare();
            volume = Prefs.alarmGradual() ? .12f : .92f;
            player.setVolume(volume, volume);
            player.start();
            if (Prefs.alarmGradual()) h.postDelayed(ramp, 1800);
        } catch (Exception ignored) {}
        if (Prefs.haptic()) try {
            vibrator = (Vibrator) getSystemService(VIBRATOR_SERVICE);
            long[] p = {0,260,160,420,700};
            if (vibrator != null && vibrator.hasVibrator()) {
                if (Build.VERSION.SDK_INT >= 26) vibrator.vibrate(VibrationEffect.createWaveform(p, 0));
                else vibrator.vibrate(p, 0);
            }
        } catch (Exception ignored) {}
    }

    private void snooze() {
        AlarmScheduler.snooze(this);
        Prefs.addBond(1); Prefs.setLastSay(AkariLines.alarmSnooze());
        stopAll(); Haptics.warning(this); finish();
    }

    private void dismiss() {
        Prefs.addBond(2); Prefs.setLastSay(AkariLines.alarmDismiss());
        boolean test = getIntent().getBooleanExtra(EXTRA_TEST, false);
        stopAll(); Haptics.success(this);
        if (!test) startActivity(new Intent(this, HomeActivity.class)
                .addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP));
        finish();
    }

    private void stopAll() {
        if (stopped) return;
        stopped = true; h.removeCallbacksAndMessages(null); Voice.stop();
        if (breathe != null) breathe.cancel();
        if (vibrator != null) try { vibrator.cancel(); } catch (Exception ignored) {}
        if (player != null) {
            try { player.stop(); } catch (Exception ignored) {}
            try { player.release(); } catch (Exception ignored) {}
            player = null;
        }
        NotificationManager n = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        if (n != null) n.cancel(AlarmReceiver.NOTICE);
    }

    @Override public void onBackPressed() {}
    @Override protected void onDestroy() { stopAll(); super.onDestroy(); }
}
