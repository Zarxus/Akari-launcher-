package mx.zarxus.akari;

import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.app.Notification;
import android.app.RemoteInput;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.PackageManager;
import android.graphics.drawable.Drawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.provider.Settings;
import android.text.TextUtils;
import android.text.format.DateUtils;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

/** Full-screen notification hub owned and styled by AKARI. */
public class NotificationCenterActivity extends Activity {
    private static final int FILTER_ALL = 0;
    private static final int FILTER_PRIORITY = 1;
    private static final int FILTER_MESSAGES = 2;
    private static final int FILTER_CALLS = 3;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private LinearLayout list;
    private TextView restrictedStep, access, state, summary, count, empty, privacy;
    private TextView chipAll, chipPriority, chipMessages, chipCalls;
    private ImageView art;
    private int filter = FILTER_ALL;
    private boolean receiverRegistered;
    private ObjectAnimator floatAnimator;

    private final BroadcastReceiver changes = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String event = intent == null ? "" : intent.getStringExtra(AkariNotificationService.EXTRA_EVENT);
            if ("posted".equals(event)) {
                String kind = intent.getStringExtra(AkariNotificationService.EXTRA_KIND);
                react("call".equals(kind));
            }
            render();
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_notification_center);
        Insets.attach(this, findViewById(R.id.notificationRoot));
        SoundEngine.init(this);
        Voice.init(this);

        list = findViewById(R.id.notificationList);
        restrictedStep = findViewById(R.id.btnRestrictedSettings);
        access = findViewById(R.id.btnNotificationAccess);
        state = findViewById(R.id.notificationState);
        summary = findViewById(R.id.notificationSummary);
        count = findViewById(R.id.notificationCount);
        empty = findViewById(R.id.notificationEmpty);
        privacy = findViewById(R.id.btnNotificationPrivacy);
        art = findViewById(R.id.notificationAkari);
        chipAll = findViewById(R.id.filterAll);
        chipPriority = findViewById(R.id.filterPriority);
        chipMessages = findViewById(R.id.filterMessages);
        chipCalls = findViewById(R.id.filterCalls);

        findViewById(R.id.btnNotificationBack).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { SoundEngine.back(); finish(); }
        });
        restrictedStep.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.click();
                AkariNotificationService.openAppDetails(NotificationCenterActivity.this);
            }
        });
        access.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.click();
                if (AkariNotificationService.hasAccess(NotificationCenterActivity.this)) {
                    AkariNotificationService.openAccessSettings(NotificationCenterActivity.this);
                } else {
                    AkariNotificationService.showAccessGuide(NotificationCenterActivity.this);
                }
            }
        });
        findViewById(R.id.btnNotificationRefresh).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.click();
                AkariNotificationService.requestReconnect(NotificationCenterActivity.this);
                AkariNotificationService.refreshNow();
                handler.postDelayed(new Runnable() { @Override public void run() { render(); } }, 450);
            }
        });
        findViewById(R.id.btnNotificationClear).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { confirmClear(); }
        });
        privacy.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                Prefs.setNotificationPrivacy(!Prefs.notificationPrivacy());
                SoundEngine.click();
                render();
            }
        });
        bindFilter(chipAll, FILTER_ALL);
        bindFilter(chipPriority, FILTER_PRIORITY);
        bindFilter(chipMessages, FILTER_MESSAGES);
        bindFilter(chipCalls, FILTER_CALLS);

        art.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                react(true);
                readLatest();
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        registerChanges();
        AkariNotificationService.requestReconnect(this);
        AkariNotificationService.refreshNow();
        render();
        Prefs.setNotificationSeenAt(System.currentTimeMillis());
        animateArt();
        handler.postDelayed(new Runnable() { @Override public void run() { render(); } }, 600);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacksAndMessages(null);
        if (floatAnimator != null) floatAnimator.cancel();
        unregisterChanges();
        super.onPause();
    }

    private void registerChanges() {
        if (receiverRegistered) return;
        IntentFilter filter = new IntentFilter(AkariNotificationService.ACTION_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(changes, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(changes, filter);
        receiverRegistered = true;
    }

    private void unregisterChanges() {
        if (!receiverRegistered) return;
        try { unregisterReceiver(changes); } catch (Exception ignored) {}
        receiverRegistered = false;
    }

    private void bindFilter(TextView chip, final int value) {
        chip.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                filter = value;
                SoundEngine.click();
                render();
            }
        });
    }

    private void render() {
        if (list == null) return;
        boolean granted = AkariNotificationService.hasAccess(this);
        restrictedStep.setVisibility(granted ? View.GONE : View.VISIBLE);
        access.setText(granted ? "ACCESO ACTIVO · GESTIONAR" : "2 · ACTIVAR CENTRO AKARI");
        access.setTextColor(granted ? 0xFF2EF0FF : 0xFFFF2ED9);
        state.setText(!granted ? "OFFLINE · falta autorización"
                : AkariNotificationService.isConnected() ? "NEXUS LINK · EN VIVO" : "AUTORIZADO · ENLAZANDO…");
        privacy.setText(Prefs.notificationPrivacy() ? "PRIVACIDAD · OCULTA" : "PRIVACIDAD · VISIBLE");
        renderFilterState();
        list.removeAllViews();

        if (!granted) {
            count.setText("0 ACTIVOS");
            summary.setText("Android protege este enlace. Completa los dos pasos de abajo y mi bandeja quedará activa.");
            empty.setVisibility(View.VISIBLE);
            empty.setText("Si viste ‘Configuración restringida’: vuelve, pulsa PASO 1, toca ⋮ arriba a la derecha y elige ‘Permitir configuración restringida’. Luego usa PASO 2. AKARI no puede saltarse esta protección del sistema.");
            return;
        }

        List<NotificationEntry> all = AkariNotificationService.snapshot(this);
        List<NotificationEntry> visible = new ArrayList<>();
        int calls = 0;
        int messages = 0;
        int total = 0;
        for (NotificationEntry entry : all) {
            if (entry.groupSummary) continue;
            total++;
            if (entry.call) calls++;
            if (entry.message || entry.isChatApp()) messages++;
            if (matches(entry)) visible.add(entry);
        }
        count.setText(total + (total == 1 ? " ACTIVO" : " ACTIVOS"));
        summary.setText(AkariNotificationNarrator.summary(total, calls, messages));
        NotificationEntry latest = visible.isEmpty() ? null : visible.get(0);
        art.setImageResource(AkariNotificationNarrator.poseRes(latest, calls, messages));

        if (visible.isEmpty()) {
            empty.setVisibility(View.VISIBLE);
            empty.setText(total == 0 ? "Canal limpio. Cuando llegue algo, aparecerá aquí sin abrir la cortina del sistema."
                    : "No hay avisos en este filtro.");
        } else {
            empty.setVisibility(View.GONE);
            int index = 0;
            int limit = Math.min(50, visible.size());
            for (int visibleIndex = 0; visibleIndex < limit; visibleIndex++) {
                NotificationEntry entry = visible.get(visibleIndex);
                View card = createCard(entry);
                list.addView(card);
                card.setAlpha(0f);
                card.setTranslationX(dp(22));
                card.animate().alpha(1f).translationX(0f).setDuration(220).setStartDelay(Math.min(260, index * 32L)).start();
                index++;
            }
        }
        Prefs.setNotificationSeenAt(System.currentTimeMillis());
    }

    private void readLatest() {
        List<NotificationEntry> all = AkariNotificationService.snapshot(this);
        NotificationEntry pick = null;
        for (NotificationEntry e : all) {
            if (e.groupSummary) continue;
            if (e.call || e.message || e.isChatApp()) { pick = e; break; }
            if (pick == null) pick = e;
        }
        String line = AkariNotificationNarrator.readAloud(pick);
        summary.setText(line);
        Voice.speak(line);
        if (pick != null) {
            art.setImageResource(AkariNotificationNarrator.poseRes(pick,
                    pick.call ? 1 : 0, pick.message || pick.isChatApp() ? 1 : 0));
        }
    }

    private boolean matches(NotificationEntry entry) {
        if (filter == FILTER_CALLS) return entry.call;
        if (filter == FILTER_MESSAGES) return entry.message || entry.isChatApp();
        if (filter == FILTER_PRIORITY) return entry.isPriority();
        return true;
    }

    private void renderFilterState() {
        styleChip(chipAll, filter == FILTER_ALL);
        styleChip(chipPriority, filter == FILTER_PRIORITY);
        styleChip(chipMessages, filter == FILTER_MESSAGES);
        styleChip(chipCalls, filter == FILTER_CALLS);
    }

    private void styleChip(TextView chip, boolean selected) {
        chip.setBackgroundResource(selected ? R.drawable.bg_chip_selected : R.drawable.bg_chip);
        chip.setTextColor(selected ? 0xFFF4F0FF : 0xFF9B93B3);
        chip.setContentDescription(chip.getText() + (selected ? ". Filtro seleccionado." : ". Filtro."));
    }

    private View createCard(final NotificationEntry entry) {
        LinearLayout card = new LinearLayout(this);
        card.setOrientation(LinearLayout.VERTICAL);
        card.setPadding(dp(14), dp(12), dp(14), dp(12));
        card.setBackgroundResource(entry.call ? R.drawable.bg_notification_call : R.drawable.bg_notification);
        LinearLayout.LayoutParams cardLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        cardLp.topMargin = dp(10);
        card.setLayoutParams(cardLp);

        LinearLayout head = new LinearLayout(this);
        head.setOrientation(LinearLayout.HORIZONTAL);
        head.setGravity(Gravity.CENTER_VERTICAL);
        ImageView icon = new ImageView(this);
        LinearLayout.LayoutParams iconLp = new LinearLayout.LayoutParams(dp(42), dp(42));
        iconLp.rightMargin = dp(11);
        icon.setLayoutParams(iconLp);
        icon.setScaleType(ImageView.ScaleType.CENTER_INSIDE);
        icon.setContentDescription(null);
        try {
            Drawable drawable = getPackageManager().getApplicationIcon(entry.packageName);
            icon.setImageDrawable(drawable);
        } catch (PackageManager.NameNotFoundException ignored) {
            icon.setImageResource(R.mipmap.ic_launcher);
        }
        head.addView(icon);

        LinearLayout labels = new LinearLayout(this);
        labels.setOrientation(LinearLayout.VERTICAL);
        labels.setLayoutParams(new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));
        TextView app = text(entry.call ? "LLAMADA // " + entry.appName : entry.appName.toUpperCase(Locale.getDefault()),
                entry.call ? 0xFFFF2ED9 : 0xFF2EF0FF, 11, true);
        TextView when = text(relativeTime(entry.postedAt) + (entry.ongoing ? " · activa" : ""),
                0xFF9B93B3, 10, false);
        labels.addView(app);
        labels.addView(when);
        head.addView(labels);
        card.addView(head);

        String shownTitle = entry.secret ? "Contenido protegido por Android"
                : Prefs.notificationPrivacy() ? "Contenido oculto por privacidad" : entry.title;
        String shownText = entry.secret || Prefs.notificationPrivacy() ? "Toca ABRIR para verlo en su aplicación." : entry.text;
        if (!TextUtils.isEmpty(shownTitle) && !shownTitle.equals(entry.appName)) {
            TextView title = text(shownTitle, 0xFFF4F0FF, 15, true);
            LinearLayout.LayoutParams titleLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            titleLp.topMargin = dp(10);
            title.setLayoutParams(titleLp);
            card.addView(title);
        }
        if (!TextUtils.isEmpty(shownText)) {
            TextView body = text(shownText, 0xFFD2CCE0, 13, false);
            LinearLayout.LayoutParams bodyLp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            bodyLp.topMargin = dp(4);
            body.setLayoutParams(bodyLp);
            body.setMaxLines(5);
            body.setEllipsize(TextUtils.TruncateAt.END);
            card.addView(body);
        }

        Notification.Action[] actions = entry.actions();
        if (actions.length > 0) card.addView(actionStrip(entry, actions));
        card.addView(footer(entry));
        card.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { open(entry); }
        });
        card.setOnLongClickListener(new View.OnLongClickListener() {
            @Override public boolean onLongClick(View v) {
                openAppNotificationSettings(entry.packageName);
                return true;
            }
        });
        card.setContentDescription((entry.call ? "Llamada" : "Aviso") + " de " + entry.appName
                + ". Toca para abrir; mantén para configurar sus avisos.");
        DockMotion.bind(card);
        return card;
    }

    private View actionStrip(final NotificationEntry entry, Notification.Action[] actions) {
        HorizontalScrollView scroll = new HorizontalScrollView(this);
        scroll.setHorizontalScrollBarEnabled(false);
        LinearLayout.LayoutParams scrollLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        scrollLp.topMargin = dp(10);
        scroll.setLayoutParams(scrollLp);
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        int n = Math.min(actions.length, 4);
        for (int i = 0; i < n; i++) {
            final int index = i;
            final Notification.Action action = actions[i];
            String label = action.title == null ? "ACCIÓN" : action.title.toString().trim();
            if (label.isEmpty()) label = "ACCIÓN";
            final boolean reply = hasRemoteInput(action);
            TextView button = actionButton((reply ? "↩ " : "") + label.toUpperCase(Locale.getDefault()),
                    entry.call ? 0xFFFF2ED9 : 0xFF2EF0FF);
            button.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    if (reply) showReply(entry, index, action.title == null ? "Responder" : action.title.toString());
                    else runAction(entry, index);
                }
            });
            row.addView(button);
        }
        scroll.addView(row);
        return scroll;
    }

    private View footer(final NotificationEntry entry) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.END | Gravity.CENTER_VERTICAL);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowLp.topMargin = dp(8);
        row.setLayoutParams(rowLp);

        TextView read = actionButton("LEE ESTO", 0xFFFF2ED9);
        read.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                react(entry.call);
                Voice.speak(AkariNotificationNarrator.readAloud(entry));
                summary.setText(AkariNotificationNarrator.readAloud(entry));
                art.setImageResource(AkariNotificationNarrator.poseRes(entry,
                        entry.call ? 1 : 0, entry.message || entry.isChatApp() ? 1 : 0));
            }
        });
        row.addView(read);
        TextView settings = actionButton("AJUSTES", 0xFF9B93B3);
        settings.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openAppNotificationSettings(entry.packageName); }
        });
        row.addView(settings);
        if (entry.clearable) {
            TextView dismiss = actionButton("DESCARTAR", 0xFFFF2ED9);
            dismiss.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    SoundEngine.back();
                    if (!AkariNotificationService.dismiss(entry.key)) toast("No pude descartar ese aviso");
                    render();
                }
            });
            row.addView(dismiss);
        }
        TextView open = actionButton("ABRIR", 0xFF2EF0FF);
        open.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { open(entry); }
        });
        row.addView(open);
        return row;
    }

    private TextView actionButton(String label, int color) {
        TextView button = text(label, color, 10, true);
        button.setGravity(Gravity.CENTER);
        button.setMinHeight(dp(44));
        button.setMinWidth(dp(76));
        button.setPadding(dp(12), dp(7), dp(12), dp(7));
        button.setBackgroundResource(R.drawable.bg_action);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.leftMargin = dp(6);
        button.setLayoutParams(lp);
        DockMotion.bind(button);
        return button;
    }

    private TextView text(String value, int color, int sp, boolean bold) {
        TextView view = new TextView(this);
        view.setText(value);
        view.setTextColor(color);
        view.setTextSize(sp);
        if (bold) view.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return view;
    }

    private boolean hasRemoteInput(Notification.Action action) {
        RemoteInput[] inputs = action == null ? null : action.getRemoteInputs();
        return inputs != null && inputs.length > 0;
    }

    private void showReply(final NotificationEntry entry, final int index, String title) {
        final EditText input = new EditText(this);
        input.setSingleLine(false);
        input.setMaxLines(4);
        input.setHint("Escribe tu respuesta…");
        input.setTextColor(0xFFF4F0FF);
        input.setHintTextColor(0xFF9B93B3);
        int pad = dp(18);
        input.setPadding(pad, pad, pad, pad);
        new AlertDialog.Builder(this)
                .setTitle(TextUtils.isEmpty(title) ? "Respuesta rápida" : title)
                .setView(input)
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Enviar", (dialog, which) -> {
                    String reply = input.getText().toString().trim();
                    if (reply.isEmpty()) return;
                    boolean ok = AkariNotificationService.performAction(this, entry.key, index, reply);
                    toast(ok ? "Respuesta enviada" : "La aplicación rechazó la respuesta");
                    if (ok) {
                        SoundEngine.open();
                        Voice.speak("Enviado.");
                    }
                    handler.postDelayed(new Runnable() { @Override public void run() { render(); } }, 350);
                })
                .show();
    }

    private void runAction(NotificationEntry entry, int index) {
        boolean ok = AkariNotificationService.performAction(this, entry.key, index, null);
        toast(ok ? "Acción ejecutada" : "La acción ya no está disponible");
        if (ok) SoundEngine.open();
        handler.postDelayed(new Runnable() { @Override public void run() { render(); } }, 350);
    }

    private void open(NotificationEntry entry) {
        SoundEngine.open();
        Haptics.press(this);
        if (AkariNotificationService.open(this, entry.key)) return;
        try {
            Intent launch = getPackageManager().getLaunchIntentForPackage(entry.packageName);
            if (launch != null) startActivity(launch);
            else toast("Este aviso no tiene una pantalla para abrir");
        } catch (Exception ignored) {
            toast("No pude abrir ese aviso");
        }
    }

    private void openAppNotificationSettings(String pkg) {
        try {
            Intent intent = new Intent(Settings.ACTION_APP_NOTIFICATION_SETTINGS);
            intent.putExtra(Settings.EXTRA_APP_PACKAGE, pkg);
            startActivity(intent);
        } catch (Exception e) {
            QuickActions.appInfo(this, pkg);
        }
    }

    private void confirmClear() {
        if (!AkariNotificationService.hasAccess(this)) {
            AkariNotificationService.showAccessGuide(this);
            return;
        }
        new AlertDialog.Builder(this)
                .setTitle("Descartar avisos")
                .setMessage("Esto elimina de Android todos los avisos que permiten ser descartados. Las llamadas activas y controles permanentes se conservan.")
                .setNegativeButton("Cancelar", null)
                .setPositiveButton("Descartar", (dialog, which) -> {
                    int cleared = AkariNotificationService.dismissClearable();
                    toast("Descartados: " + cleared);
                    SoundEngine.back();
                    render();
                })
                .show();
    }

    private void animateArt() {
        if (art == null || !Prefs.physics()) return;
        if (floatAnimator != null) floatAnimator.cancel();
        float motion = Prefs.motionScale();
        floatAnimator = ObjectAnimator.ofFloat(art, View.TRANSLATION_Y, -dp(3) * motion, dp(4) * motion);
        floatAnimator.setDuration(1700);
        floatAnimator.setRepeatCount(ObjectAnimator.INFINITE);
        floatAnimator.setRepeatMode(ObjectAnimator.REVERSE);
        floatAnimator.start();
    }

    private void react(boolean urgent) {
        if (art == null) return;
        float motion = Prefs.motionScale();
        float peak = 1f + (urgent ? .13f : .06f) * motion;
        art.animate().cancel();
        art.animate().scaleX(peak).scaleY(peak).rotation(urgent ? -2f : 1f).setDuration(120)
                .withEndAction(new Runnable() {
                    @Override public void run() {
                        art.animate().scaleX(1f).scaleY(1f).rotation(0f).setDuration(260).start();
                    }
                }).start();
        if (urgent) SoundEngine.unlock();
        else SoundEngine.click();
        if (urgent) Haptics.warning(this); else Haptics.tap(this);
    }

    private String relativeTime(long when) {
        return DateUtils.getRelativeTimeSpanString(when, System.currentTimeMillis(), DateUtils.MINUTE_IN_MILLIS)
                .toString();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }

    private void toast(String value) {
        Toast.makeText(this, value, Toast.LENGTH_SHORT).show();
    }
}
