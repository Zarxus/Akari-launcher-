package mx.zarxus.akari;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.os.Handler;
import android.os.Looper;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

public class SettingsActivity extends Activity {
    private TextView notificationAccess;
    private TextView voiceProfile;
    private TextView alarmSettingsState;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_settings);

        Insets.attach(this);
        SoundEngine.init(this);

        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.back();
                finish();
            }
        });
        findViewById(R.id.btnDefault).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.click();
                try {
                    startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_SETTINGS));
                }
            }
        });
        alarmSettingsState = findViewById(R.id.alarmSettingsState);
        findViewById(R.id.btnAlarmSettings).setOnClickListener(v -> {
            SoundEngine.open();
            startActivity(new Intent(SettingsActivity.this, AlarmActivity.class));
        });
        DockMotion.bind(findViewById(R.id.btnAlarmSettings));

        RadioGroup g = findViewById(R.id.modeGroup);
        String mode = Prefs.mode();
        if (Prefs.MODE_ECCHI.equals(mode)) g.check(R.id.modeEcchi);
        else if (Prefs.MODE_TECH.equals(mode)) g.check(R.id.modeTech);
        else if (Prefs.MODE_HENTAI.equals(mode)) g.check(R.id.modeHentai);
        else g.check(R.id.modeMix);

        g.setOnCheckedChangeListener(new RadioGroup.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(RadioGroup group, int checkedId) {
                if (checkedId == R.id.modeEcchi) Prefs.setMode(Prefs.MODE_ECCHI);
                else if (checkedId == R.id.modeTech) Prefs.setMode(Prefs.MODE_TECH);
                else if (checkedId == R.id.modeHentai) Prefs.setMode(Prefs.MODE_HENTAI);
                else Prefs.setMode(Prefs.MODE_MIX);
                SoundEngine.click();
            }
        });

        bindCheck(R.id.chkHaptic, Prefs.haptic(), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean v) { Prefs.setHaptic(v); }
        });
        bindCheck(R.id.chkSound, Prefs.sound(), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setSound(v);
                if (!v) SoundEngine.stopAmbient();
                else SoundEngine.startAmbient(SettingsActivity.this);
            }
        });
        bindCheck(R.id.chkAmbient, Prefs.ambient(), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setAmbient(v);
                if (v) SoundEngine.startAmbient(SettingsActivity.this);
                else SoundEngine.stopAmbient();
            }
        });
        bindCheck(R.id.chkPhysics, Prefs.physics(), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean v) { Prefs.setPhysics(v); }
        });
        bindCheck(R.id.chkDeckExpanded, Prefs.commandDeckExpanded(), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean v) {
                Prefs.setCommandDeckExpanded(v);
            }
        });
        bindInteractionLevels();
        bindRiftPersonalization();
        bindCheck(R.id.chkLiveWall, Prefs.liveWall(), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean v) { Prefs.setLiveWall(v); }
        });
        bindCheck(R.id.chkVoice, Prefs.voice(), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean v) { Prefs.setVoice(v); }
        });
        bindCheck(R.id.chkVoiceAuto, Prefs.voiceAuto(), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean v) { Prefs.setVoiceAuto(v); }
        });
        voiceProfile = findViewById(R.id.voiceProfile);
        findViewById(R.id.btnVoiceTest).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.click();
                Voice.init(SettingsActivity.this);
                Voice.speak("Saúl, esta es mi voz actual. Clara, directa y sin exagerar el tono.");
                voiceProfile.setText(Voice.profile());
            }
        });
        findViewById(R.id.btnVoiceSystem).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                try {
                    startActivity(new Intent("com.android.settings.TTS_SETTINGS"));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_SETTINGS));
                }
            }
        });
        bindCheck(R.id.chkPortal, Prefs.internalBrowser(), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean v) { Prefs.setInternalBrowser(v); }
        });
        bindCheck(R.id.chkNotificationPrivacy, Prefs.notificationPrivacy(), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean v) { Prefs.setNotificationPrivacy(v); }
        });
        bindCheck(R.id.chkNotificationVoice, Prefs.notificationVoice(), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean v) { Prefs.setNotificationVoice(v); }
        });
        bindCheck(R.id.chkImmersiveHome, Prefs.immersiveHome(), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean v) { Prefs.setImmersiveHome(v); }
        });

        findViewById(R.id.btnNotificationCenter).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.open();
                startActivity(new Intent(SettingsActivity.this, NotificationCenterActivity.class));
            }
        });
        notificationAccess = findViewById(R.id.btnNotificationAccessSettings);
        notificationAccess.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                AkariNotificationService.showAccessGuide(SettingsActivity.this);
            }
        });

        findViewById(R.id.btnPerms).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new Intent(SettingsActivity.this, PermsActivity.class));
            }
        });

        TextView wall = findViewById(R.id.btnWallpaper);
        wall.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.click();
                try {
                    Intent picker = new Intent(Intent.ACTION_SET_WALLPAPER);
                    startActivity(Intent.createChooser(picker, "Elegir wallpaper del teléfono"));
                } catch (Exception e) {
                    startActivity(new Intent(Settings.ACTION_DISPLAY_SETTINGS));
                    Toast.makeText(SettingsActivity.this,
                            "Abre Fondo de pantalla en los ajustes del teléfono.", Toast.LENGTH_LONG).show();
                }
            }
        });
        wall.setText("▸  Cambiar wallpaper del teléfono");

        bindCheck(R.id.chkSeconds, Prefs.showSeconds(), new CompoundButton.OnCheckedChangeListener() {
            @Override public void onCheckedChanged(CompoundButton b, boolean v) { Prefs.setShowSeconds(v); }
        });

        final EditText city = findViewById(R.id.cityInput);
        city.setText(Prefs.city());
        findViewById(R.id.btnSaveCity).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                final String name = city.getText().toString().trim();
                if (name.isEmpty()) return;
                Toast.makeText(SettingsActivity.this, "Buscando " + name + "…", Toast.LENGTH_SHORT).show();
                final Handler h = new Handler(Looper.getMainLooper());
                new Thread(new Runnable() {
                    @Override public void run() {
                        try {
                            final String[] g = Weather.geocode(name);
                            Prefs.setPlace(g[0], Double.parseDouble(g[1]), Double.parseDouble(g[2]));
                            Prefs.setWeatherCache("");
                            h.post(new Runnable() {
                                @Override public void run() {
                                    city.setText(g[0]);
                                    Toast.makeText(SettingsActivity.this, "Clima anclado a " + g[0], Toast.LENGTH_SHORT).show();
                                }
                            });
                        } catch (final Exception e) {
                            h.post(new Runnable() {
                                @Override public void run() {
                                    Toast.makeText(SettingsActivity.this, "No se geocodificó: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            });
                        }
                    }
                }).start();
            }
        });

        final TextView eng = findViewById(R.id.btnEngine);
        refreshEngine(eng);
        eng.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                String cur = Prefs.searchEngine();
                if ("ddg".equals(cur)) Prefs.setSearchEngine("google");
                else if ("google".equals(cur)) Prefs.setSearchEngine("bing");
                else Prefs.setSearchEngine("ddg");
                refreshEngine(eng);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshNotificationAccess();
        if (alarmSettingsState != null) {
            alarmSettingsState.setText(AlarmScheduler.label()
                    + (AlarmScheduler.canExact(this) ? " · EXACTA" : " · FALTA PRECISIÓN"));
            alarmSettingsState.setTextColor(Prefs.alarmEnabled() ? 0xFF2EF0FF : 0xFF9B93B3);
        }
    }

    private void refreshNotificationAccess() {
        if (notificationAccess == null) return;
        boolean on = AkariNotificationService.hasAccess(this);
        notificationAccess.setText(on ? "●  Acceso a avisos: ACTIVO" : "○  Acceso a avisos: CONECTAR");
        notificationAccess.setTextColor(on ? 0xFF2EF0FF : 0xFFFF2ED9);
        if (voiceProfile != null) voiceProfile.setText(Voice.profile());
    }

    private void refreshEngine(TextView eng) {
        String e = Prefs.searchEngine();
        if ("google".equals(e)) eng.setText("Buscador: Google");
        else if ("bing".equals(e)) eng.setText("Buscador: Bing");
        else eng.setText("Buscador: DuckDuckGo");
    }

    private void bindCheck(int id, boolean val, CompoundButton.OnCheckedChangeListener l) {
        CheckBox c = findViewById(id);
        c.setChecked(val);
        c.setOnCheckedChangeListener(l);
    }

    private void bindInteractionLevels() {
        final TextView motionValue = findViewById(R.id.motionLevelValue);
        SeekBar motion = findViewById(R.id.motionLevel);
        motion.setMax(2);
        motion.setProgress(Prefs.motionLevel());
        updateMotionLabel(motionValue, Prefs.motionLevel());
        motion.setOnSeekBarChangeListener(new SimpleSeekListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                Prefs.setMotionLevel(value);
                updateMotionLabel(motionValue, value);
            }
            @Override public void onStopTrackingTouch(SeekBar bar) {
                SoundEngine.confirm();
                Haptics.success(SettingsActivity.this);
            }
        });

        final TextView soundValue = findViewById(R.id.soundLevelValue);
        SeekBar sound = findViewById(R.id.soundLevel);
        sound.setProgress(Prefs.soundLevel());
        soundValue.setText("SFX · " + Prefs.soundLevel() + "%");
        sound.setOnSeekBarChangeListener(new SimpleSeekListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                Prefs.setSoundLevel(value);
                soundValue.setText("SFX · " + value + "%");
            }
            @Override public void onStopTrackingTouch(SeekBar bar) { SoundEngine.confirm(); }
        });

        final TextView ambientValue = findViewById(R.id.ambientLevelValue);
        SeekBar ambient = findViewById(R.id.ambientLevel);
        ambient.setProgress(Prefs.ambientLevel());
        ambientValue.setText("AMBIENTE · " + Prefs.ambientLevel() + "%");
        ambient.setOnSeekBarChangeListener(new SimpleSeekListener() {
            @Override public void onProgressChanged(SeekBar bar, int value, boolean fromUser) {
                Prefs.setAmbientLevel(value);
                ambientValue.setText("AMBIENTE · " + value + "%");
                SoundEngine.refreshAmbientVolume();
            }
        });
    }

    private void bindRiftPersonalization() {
        final TextView style = findViewById(R.id.btnRiftStyle);
        final TextView pose = findViewById(R.id.btnPoseMode);
        refreshRiftLabels(style, pose);
        style.setOnClickListener(v -> {
            Prefs.setRiftStyle((Prefs.riftStyle() + 1) % 4);
            refreshRiftLabels(style, pose);
            SoundEngine.portalShift(Prefs.riftStyle());
            Haptics.tap(SettingsActivity.this);
        });
        pose.setOnClickListener(v -> {
            Prefs.setPoseMode((Prefs.poseMode() + 1) % 3);
            refreshRiftLabels(style, pose);
            SoundEngine.portalShift(Prefs.riftStyle());
            Haptics.press(SettingsActivity.this);
        });
        DockMotion.bind(style);
        DockMotion.bind(pose);
    }

    private void refreshRiftLabels(TextView style, TextView pose) {
        String[] styles = {"NEXUS", "VIOLETA", "DAWN", "CRIMSON"};
        String[] poses = {"CALMA", "PULSO", "GUARDIA"};
        style.setText("RIFT · " + styles[Prefs.riftStyle()]);
        pose.setText("POSTURA · " + poses[Prefs.poseMode()]);
    }

    private void updateMotionLabel(TextView view, int value) {
        String name = value <= 0 ? "CALMA" : value == 1 ? "EQUILIBRADA" : "VIBRANTE";
        view.setText("DINÁMICA · " + name);
    }

    private abstract static class SimpleSeekListener implements SeekBar.OnSeekBarChangeListener {
        @Override public void onStartTrackingTouch(SeekBar bar) {}
        @Override public void onStopTrackingTouch(SeekBar bar) {}
    }
}
