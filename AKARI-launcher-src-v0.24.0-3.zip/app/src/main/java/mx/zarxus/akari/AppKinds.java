package mx.zarxus.akari;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class AppKinds {
    private AppKinds() {}

    public static List<AppInfo> filter(List<AppInfo> all, String kind) {
        if (kind == null) kind = "todas";
        List<AppInfo> out = new ArrayList<>();
        if (kind.equals("ocultas")) {
            for (AppInfo app : all) if (Prefs.hidden(app.packageName)) out.add(app);
            return out;
        }
        List<AppInfo> visible = new ArrayList<>();
        for (AppInfo app : all) if (!Prefs.hidden(app.packageName)) visible.add(app);
        if (kind.equals("todas")) return visible;
        if (kind.equals("recientes")) {
            List<AppInfo> used = UsageStore.recentUsed(visible, 16);
            return used.isEmpty() ? AppRepository.suggestions(visible, 16) : used;
        }
        for (AppInfo a : visible) {
            if (match(a, kind)) out.add(a);
        }
        return out;
    }

    public static boolean match(AppInfo a, String kind) {
        String p = a.packageName.toLowerCase(Locale.ROOT);
        String n = a.label.toString().toLowerCase(Locale.ROOT);
        String s = p + " " + n;
        if ("chat".equals(kind))
            return has(s, "whatsapp", "telegram", "signal", "discord", "messenger", "sms",
                    "mms", "message", "mensaje", "chat", "slack", "teams", "line");
        if ("media".equals(kind))
            return has(s, "youtube", "netflix", "spotify", "music", "música", "vlc", "twitch",
                    "podcast", "radio", "player", "reproductor", "tiktok");
        if ("foto".equals(kind))
            return has(s, "camera", "cámara", "cam", "gallery", "galería", "photos", "fotos",
                    "instagram", "snap");
        if ("web".equals(kind))
            return has(s, "chrome", "firefox", "browser", "naveg", "opera", "brave", "edge",
                    "samsung.android.sbrowser");
        if ("tools".equals(kind))
            return has(s, "settings", "ajuste", "clock", "reloj", "calc", "file", "archivo",
                    "drive", "maps", "mail", "gmail", "calendar", "keep", "notes");
        if ("games".equals(kind))
            return p.contains("game") || n.contains("juego") || p.contains("unity")
                    || p.contains("roblox") || p.contains("minecraft") || p.contains("play.games");
        return true;
    }

    private static boolean has(String s, String... keys) {
        for (String k : keys) if (s.contains(k)) return true;
        return false;
    }
}
