package mx.zarxus.akari;

import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.widget.Toast;

public final class Launcher {
    private Launcher() {}

    public static void open(Context ctx, AppInfo app) {
        if (ctx == null || app == null || app.packageName == null || app.component == null) return;
        haptic(ctx);
        SoundEngine.init(ctx);
        SoundEngine.appLaunch(app.packageName);
        try {
            // An app tile always means the installed Android app. Web portals are
            // reserved for explicit links/searches and can never hijack this path.
            PackageManager pm = ctx.getPackageManager();
            Intent nativeIntent = pm.getLaunchIntentForPackage(app.packageName);
            if (nativeIntent == null) {
                nativeIntent = new Intent(Intent.ACTION_MAIN);
                nativeIntent.addCategory(Intent.CATEGORY_LAUNCHER);
                nativeIntent.setComponent(app.component);
            }
            nativeIntent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                    | Intent.FLAG_ACTIVITY_RESET_TASK_IF_NEEDED);
            ctx.startActivity(nativeIntent);

            UsageStore.bump(app.packageName);
            String line = AkariNarrator.openApp(app);
            Prefs.setLastSay(line);
            Voice.speak(line);
        } catch (Exception ignored) {
            String message = "No pude abrir " + app.label + ". Puede estar desactivada o actualizándose.";
            Prefs.setLastSay(message);
            SoundEngine.back();
            Haptics.warning(ctx);
            Voice.speak(message);
            Toast.makeText(ctx, message, Toast.LENGTH_LONG).show();
        }
    }

    public static void openPortal(Context ctx, String url, String title) {
        if (!Prefs.internalBrowser()) {
            try {
                Intent external = new Intent(Intent.ACTION_VIEW, android.net.Uri.parse(url));
                if (!(ctx instanceof android.app.Activity)) external.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
                ctx.startActivity(external);
                return;
            } catch (Exception ignored) {
                // If the phone has no external browser, AKARI's portal remains a safe fallback.
            }
        }
        Intent p = new Intent(ctx, PortalActivity.class);
        p.putExtra(PortalActivity.EXTRA_URL, url);
        p.putExtra(PortalActivity.EXTRA_TITLE, title);
        if (!(ctx instanceof android.app.Activity)) p.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ctx.startActivity(p);
    }

    public static void haptic(Context ctx) {
        Haptics.tap(ctx);
    }
}
