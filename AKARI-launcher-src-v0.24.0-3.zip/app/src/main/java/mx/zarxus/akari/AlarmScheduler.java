package mx.zarxus.akari;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;
import android.provider.Settings;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

/** Reliable repeating wake alarm, including Android's exact-alarm authority flow. */
public final class AlarmScheduler {
    static final String ACTION_FIRE = "mx.zarxus.akari.ALARM_FIRE";
    static final String EXTRA_SNOOZE = "snooze";
    private static final int NORMAL = 6020, SNOOZE = 6021, SHOW = 6022;
    private AlarmScheduler() {}

    public static boolean canExact(Context c) {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager a = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        return a != null && a.canScheduleExactAlarms();
    }

    public static void requestExact(Context c) {
        if (Build.VERSION.SDK_INT < 31) return;
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + c.getPackageName()));
            if (!(c instanceof android.app.Activity)) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Exception e) {
            QuickActions.appInfo(c, c.getPackageName());
        }
    }

    public static boolean canFullScreen(Context c) {
        if (Build.VERSION.SDK_INT < 34) return true;
        NotificationManager notices = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        return notices != null && notices.canUseFullScreenIntent();
    }

    public static void requestFullScreen(Context c) {
        if (Build.VERSION.SDK_INT < 34) return;
        try {
            Intent i = new Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT,
                    Uri.parse("package:" + c.getPackageName()));
            if (!(c instanceof android.app.Activity)) i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
            c.startActivity(i);
        } catch (Exception ignored) {
            QuickActions.appInfo(c, c.getPackageName());
        }
    }

    public static long schedule(Context c) {
        if (!Prefs.alarmEnabled()) { cancel(c); return 0; }
        long at = next(System.currentTimeMillis(), Prefs.alarmHour(), Prefs.alarmMinute(), Prefs.alarmDays());
        set(c, at, false);
        Prefs.setAlarmNextAt(at);
        return at;
    }

    public static long snooze(Context c) {
        long at = System.currentTimeMillis() + Prefs.alarmSnoozeMinutes() * 60_000L;
        set(c, at, true);
        Prefs.setAlarmSnoozeAt(at);
        return at;
    }

    private static void set(Context c, long at, boolean snooze) {
        AlarmManager a = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (a == null) return;
        Intent fire = new Intent(c, AlarmReceiver.class).setAction(ACTION_FIRE)
                .putExtra(EXTRA_SNOOZE, snooze);
        PendingIntent op = PendingIntent.getBroadcast(c, snooze ? SNOOZE : NORMAL, fire,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        try {
            if (canExact(c)) {
                PendingIntent show = PendingIntent.getActivity(c, SHOW,
                        new Intent(c, AlarmActivity.class),
                        PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
                a.setAlarmClock(new AlarmManager.AlarmClockInfo(at, show), op);
            } else {
                a.setWindow(AlarmManager.RTC_WAKEUP, at, 5 * 60_000L, op);
            }
        } catch (SecurityException e) {
            a.setWindow(AlarmManager.RTC_WAKEUP, at, 5 * 60_000L, op);
        }
    }

    public static void cancel(Context c) {
        AlarmManager a = (AlarmManager) c.getSystemService(Context.ALARM_SERVICE);
        if (a == null) return;
        Intent fire = new Intent(c, AlarmReceiver.class).setAction(ACTION_FIRE);
        a.cancel(PendingIntent.getBroadcast(c, NORMAL, fire, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        a.cancel(PendingIntent.getBroadcast(c, SNOOZE, fire, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE));
        Prefs.setAlarmNextAt(0);
        Prefs.setAlarmSnoozeAt(0);
    }

    public static String label() {
        if (!Prefs.alarmEnabled()) return "ALARMA · OFF";
        long at = Prefs.alarmSnoozeAt() > System.currentTimeMillis() ? Prefs.alarmSnoozeAt() : Prefs.alarmNextAt();
        if (at <= System.currentTimeMillis()) at = next(System.currentTimeMillis(),
                Prefs.alarmHour(), Prefs.alarmMinute(), Prefs.alarmDays());
        return (Prefs.alarmSnoozeAt() > System.currentTimeMillis() ? "POSPUESTA · " : "ALARMA · ")
                + DateFormat.getTimeInstance(DateFormat.SHORT).format(new Date(at));
    }

    static long next(long nowMs, int hour, int minute, int mask) {
        Calendar now = Calendar.getInstance();
        now.setTimeInMillis(nowMs);
        for (int add = 0; add <= 7; add++) {
            Calendar c = (Calendar) now.clone();
            c.add(Calendar.DAY_OF_YEAR, add);
            c.set(Calendar.HOUR_OF_DAY, hour);
            c.set(Calendar.MINUTE, minute);
            c.set(Calendar.SECOND, 0);
            c.set(Calendar.MILLISECOND, 0);
            int bit = 1 << (c.get(Calendar.DAY_OF_WEEK) - 1);
            if ((mask & bit) != 0 && c.getTimeInMillis() > nowMs + 1000) return c.getTimeInMillis();
        }
        return nowMs + 24 * 60 * 60_000L;
    }
}
