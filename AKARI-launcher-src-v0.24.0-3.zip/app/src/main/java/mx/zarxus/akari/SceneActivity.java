package mx.zarxus.akari;

import android.app.Activity;
import android.os.Bundle;
import android.view.View;
import android.view.animation.AccelerateDecelerateInterpolator;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

public class SceneActivity extends Activity {
    public static final String EXTRA_ID = "scene_id";

    private SceneCatalog.Scene scene;
    private int page;
    private ImageView art;
    private TextView title;
    private TextView body;
    private TextView btnA;
    private TextView btnB;
    private TextView hint;
    private boolean artRunning;
    private boolean panRight;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_scene);

        Insets.attach(this);        SoundEngine.init(this);

        String id = getIntent().getStringExtra(EXTRA_ID);
        if (id == null) id = "boot";
        scene = SceneCatalog.byId(id);

        if (Prefs.bond() < scene.needBond) {
            Toast.makeText(this, "Bond insuficiente · necesitas " + scene.needBond, Toast.LENGTH_LONG).show();
            finish();
            return;
        }

        art = findViewById(R.id.sceneArt);
        title = findViewById(R.id.sceneTitle);
        body = findViewById(R.id.sceneBody);
        btnA = findViewById(R.id.btnA);
        btnB = findViewById(R.id.btnB);
        hint = findViewById(R.id.sceneHint);

        art.setImageResource(scene.art);
        title.setText(scene.title.toUpperCase());
        SoundEngine.scene();
        render();
        DockMotion.bind(btnA);
        DockMotion.bind(btnB);
        DockMotion.bind(findViewById(R.id.btnClose));
        art.setOnClickListener(v -> {
            panRight = !panRight;
            SoundEngine.soft();
            Haptics.tap(SceneActivity.this);
            hint.setText("PARALLAX · DIRECCIÓN CAMBIADA");
            panArt();
        });

        btnA.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { choose(true); }
        });
        btnB.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { choose(false); }
        });
        findViewById(R.id.btnClose).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                SoundEngine.back();
                finish();
            }
        });
    }

    private void render() {
        if (page >= scene.pages.size()) {
            Prefs.unlock(scene.id);
            Prefs.incScenes();
            SoundEngine.unlock();
            body.setText("Escena cerrada. CG desbloqueado en GALERÍA. Bond " + Prefs.bond() + " · Heat " + Prefs.heat() + ".");
            btnA.setText("Volver al HOME");
            btnB.setText("Repetir");
            hint.setText("LINK COMPLETO");
            btnA.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) { finish(); }
            });
            btnB.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    page = 0;
                    btnA.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) { choose(true); }
                    });
                    btnB.setOnClickListener(new View.OnClickListener() {
                        @Override public void onClick(View v) { choose(false); }
                    });
                    render();
                }
            });
            return;
        }
        SceneCatalog.Page p = scene.pages.get(page);
        body.setText(p.text);
        btnA.setText(p.choiceA);
        btnB.setText(p.choiceB);
        hint.setText("PÁGINA " + (page + 1) + " / " + scene.pages.size());
        animatePage();
    }

    private void choose(boolean a) {
        SceneCatalog.Page p = scene.pages.get(page);
        if (a) {
            Prefs.addHeat(p.heatA);
            Prefs.addBond(p.bondA);
        } else {
            Prefs.addHeat(p.heatB);
            Prefs.addBond(p.bondB);
        }
        SoundEngine.heat();
        if (Prefs.heat() > 50) SoundEngine.breath();
        Launcher.haptic(this);
        Haptics.success(this);
        page++;
        render();
    }

    private void animatePage() {
        body.animate().cancel();
        btnA.animate().cancel();
        btnB.animate().cancel();
        body.setAlpha(.25f);
        body.setTranslationY(dp(18));
        btnA.setAlpha(0f);
        btnA.setTranslationX(dp(26));
        btnB.setAlpha(0f);
        btnB.setTranslationX(-dp(26));
        body.animate().alpha(1f).translationY(0f).setDuration(240L).start();
        btnA.animate().alpha(1f).translationX(0f).setStartDelay(90L).setDuration(250L).start();
        btnB.animate().alpha(1f).translationX(0f).setStartDelay(150L).setDuration(250L).start();
    }

    @Override protected void onResume() {
        super.onResume();
        artRunning = true;
        panArt();
    }

    @Override protected void onPause() {
        artRunning = false;
        if (art != null) art.animate().cancel();
        super.onPause();
    }

    private void panArt() {
        if (!artRunning || art == null) return;
        art.animate().cancel();
        art.animate()
                .scaleX(panRight ? 1.15f : 1.09f)
                .scaleY(panRight ? 1.15f : 1.09f)
                .translationX(panRight ? dp(12) : -dp(12))
                .translationY(panRight ? -dp(7) : dp(5))
                .setInterpolator(new AccelerateDecelerateInterpolator())
                .setDuration(7600L)
                .withEndAction(() -> {
                    if (!artRunning) return;
                    panRight = !panRight;
                    panArt();
                }).start();
    }

    private int dp(int value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
