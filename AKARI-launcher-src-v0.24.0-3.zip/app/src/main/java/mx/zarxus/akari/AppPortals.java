package mx.zarxus.akari;

import java.util.Locale;

public final class AppPortals {
    private AppPortals() {}

    public static String urlFor(AppInfo app) {
        if (app == null) return null;
        return urlFor(app.packageName, app.label.toString());
    }

    public static String urlFor(String pkg, String label) {
        String p = pkg == null ? "" : pkg.toLowerCase(Locale.ROOT);
        String n = label == null ? "" : label.toLowerCase(Locale.ROOT);
        if (has(p, n, "youtube")) return "https://m.youtube.com";
        if (has(p, n, "gmail") || p.contains("gm")) return "https://mail.google.com";
        if (has(p, n, "chrome") || has(p, n, "firefox") || has(p, n, "browser") || has(p, n, "opera") || has(p, n, "brave"))
            return "https://www.google.com";
        if (has(p, n, "whatsapp")) return "https://web.whatsapp.com";
        if (has(p, n, "telegram")) return "https://web.telegram.org";
        if (has(p, n, "instagram")) return "https://www.instagram.com";
        if (has(p, n, "facebook") || p.contains("fb.")) return "https://m.facebook.com";
        if (has(p, n, "twitter") || p.equals("com.twitter.android") || n.equals("x")) return "https://mobile.twitter.com";
        if (has(p, n, "reddit")) return "https://www.reddit.com";
        if (has(p, n, "tiktok")) return "https://www.tiktok.com";
        if (has(p, n, "spotify")) return "https://open.spotify.com";
        if (has(p, n, "netflix")) return "https://www.netflix.com";
        if (has(p, n, "maps") || p.contains("maps")) return "https://maps.google.com";
        if (has(p, n, "translate")) return "https://translate.google.com";
        if (has(p, n, "drive")) return "https://drive.google.com";
        if (has(p, n, "docs")) return "https://docs.google.com";
        if (has(p, n, "discord")) return "https://discord.com/app";
        if (has(p, n, "twitch")) return "https://m.twitch.tv";
        if (has(p, n, "amazon")) return "https://www.amazon.com.mx";
        if (has(p, n, "mercado")) return "https://www.mercadolibre.com.mx";
        if (has(p, n, "github")) return "https://github.com";
        if (has(p, n, "play") && n.contains("store")) return "https://play.google.com/store";
        return null;
    }

    public static String searchUrl(String q) {
        try {
            return "https://www.google.com/search?q=" + java.net.URLEncoder.encode(q, "UTF-8");
        } catch (Exception e) {
            return "https://www.google.com";
        }
    }

    public static boolean hasPortal(AppInfo app) {
        return urlFor(app) != null;
    }

    private static boolean has(String pkg, String label, String key) {
        return pkg.contains(key) || label.contains(key);
    }
}
