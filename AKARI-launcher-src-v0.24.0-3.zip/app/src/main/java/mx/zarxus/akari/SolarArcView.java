package mx.zarxus.akari;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/** Compact real-time solar trajectory driven by the cached weather response. */
public class SolarArcView extends View {
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private Weather weather = new Weather();
    private boolean attached;
    private boolean running;
    private final Runnable minuteTick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            invalidate();
            postDelayed(this, 60_000L);
        }
    };

    public SolarArcView(Context context) { this(context, null); }

    public SolarArcView(Context context, AttributeSet attrs) {
        super(context, attrs);
        setWillNotDraw(false);
        setClickable(true);
        setFocusable(true);
        setContentDescription("Trayectoria solar y nivel ultravioleta");
    }

    public void setWeather(Weather value) {
        weather = value == null ? new Weather() : value;
        setContentDescription(weather.solarNarration());
        invalidate();
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        attached = true;
        syncLoop();
    }

    @Override protected void onDetachedFromWindow() {
        attached = false;
        running = false;
        removeCallbacks(minuteTick);
        super.onDetachedFromWindow();
    }

    @Override protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        running = attached && visibility == VISIBLE;
        syncLoop();
    }

    private void syncLoop() {
        removeCallbacks(minuteTick);
        running = attached && getWindowVisibility() == VISIBLE;
        if (running) post(minuteTick);
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;
        float density = getResources().getDisplayMetrics().density;
        float radius = 15f * density;

        paint.setStyle(Paint.Style.FILL);
        paint.setColor(0xA3090812);
        canvas.drawRoundRect(0, 0, w, h, radius, radius, paint);
        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, density));
        paint.setColor(0x662EF0FF);
        canvas.drawRoundRect(.5f, .5f, w - .5f, h - .5f, radius, radius, paint);

        float left = 15f * density;
        float right = w - left;
        float base = h * .66f;
        float controlX = w * .5f;
        float controlY = h * .03f;
        float progress = weather.sunProgress();
        float lastX = left;
        float lastY = base;
        paint.setStrokeWidth(1.4f * density);
        for (int i = 1; i <= 48; i++) {
            float t = i / 48f;
            float inv = 1f - t;
            float x = inv * inv * left + 2f * inv * t * controlX + t * t * right;
            float y = inv * inv * base + 2f * inv * t * controlY + t * t * base;
            paint.setColor(t <= progress ? 0xFFFFB52E : 0x445A5870);
            canvas.drawLine(lastX, lastY, x, y, paint);
            lastX = x;
            lastY = y;
        }

        float t = progress;
        float inv = 1f - t;
        float sunX = inv * inv * left + 2f * inv * t * controlX + t * t * right;
        float sunY = inv * inv * base + 2f * inv * t * controlY + t * t * base;
        int uvColor = uvColor(weather.uv);
        paint.setStyle(Paint.Style.FILL);
        paint.setColor(Color.argb(weather.sunIsUp() ? 48 : 20,
                Color.red(uvColor), Color.green(uvColor), Color.blue(uvColor)));
        canvas.drawCircle(sunX, sunY, 8.5f * density, paint);
        paint.setColor(uvColor);
        canvas.drawCircle(sunX, sunY, 3.2f * density, paint);

        paint.setStyle(Paint.Style.STROKE);
        paint.setStrokeWidth(Math.max(1f, density));
        paint.setColor(0x552EF0FF);
        canvas.drawLine(left, base, right, base, paint);

        paint.setStyle(Paint.Style.FILL);
        paint.setTypeface(android.graphics.Typeface.create("sans-serif-condensed",
                android.graphics.Typeface.BOLD));
        paint.setTextSize(9.5f * density);
        paint.setColor(uvColor);
        canvas.drawText(weather.uvLabel(), left, h - 4.5f * density, paint);
        paint.setTextAlign(Paint.Align.RIGHT);
        paint.setColor(0xFFF4F0FF);
        canvas.drawText(weather.lightRemainingLabel() + " · " + weather.dayRemainingLabel(),
                right, h - 4.5f * density, paint);
        paint.setTextSize(5.8f * density);
        paint.setColor(0xFF817A98);
        canvas.drawText("DATOS · OPEN-METEO", right, 7f * density, paint);
        paint.setTextAlign(Paint.Align.LEFT);
    }

    private int uvColor(double uv) {
        if (Double.isNaN(uv)) return 0xFF9B93B3;
        if (uv < 3) return 0xFF4FE37C;
        if (uv < 6) return 0xFFFFD34E;
        if (uv < 8) return 0xFFFF9338;
        if (uv < 11) return 0xFFFF2E7A;
        return 0xFFC86BFF;
    }
}
