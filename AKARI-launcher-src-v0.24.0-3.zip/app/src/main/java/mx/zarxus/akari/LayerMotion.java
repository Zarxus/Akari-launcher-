package mx.zarxus.akari;

/** Pure gesture math shared by the Android controller and host-side checks. */
final class LayerMotion {
    private LayerMotion() {}

    static float progress(int edge, float start, float dx, float dy, float width, float height) {
        float value = start;
        if (edge == 1) value += dx / Math.max(1f, width);
        else if (edge == 2) value -= dx / Math.max(1f, width);
        else if (edge == 3) value += dy / Math.max(1f, height);
        else if (edge == 4) value -= dy / Math.max(1f, height);
        return clamp(value);
    }

    static float projected(float progress, float velocityAlong, float size) {
        return progress + velocityAlong / Math.max(1f, size) * .16f;
    }

    static boolean shouldOpen(float progress, float velocityAlong, float size) {
        return projected(progress, velocityAlong, size) >= .42f;
    }

    static float settleTarget(float progress, boolean open, float velocityAlong,
                              float size, boolean allowPartial) {
        boolean partial = allowPartial && Math.abs(velocityAlong) < Math.max(1f, size) * .65f
                && progress >= .30f && progress <= .75f;
        return partial ? .58f : (open ? 1f : 0f);
    }

    static float clamp(float value) {
        return Math.max(0f, Math.min(1f, value));
    }
}
