#!/usr/bin/env bash
set -euo pipefail

ROOT="$(cd "$(dirname "$0")" && pwd)"
SDK="${ANDROID_SDK_ROOT:-${ANDROID_HOME:-/home/workdir/sdk}}"
BT="$SDK/build-tools/34.0.0"
ANDROID_JAR="$SDK/platforms/android-34/android.jar"
PKG="mx.zarxus.akari"
VERSION_CODE="25"
VERSION_NAME="0.24.0"
JAVAC_BIN="${JAVAC:-$(command -v javac || true)}"
if [[ -z "$JAVAC_BIN" && -x "$ROOT/javac-wrapper.sh" ]] && java --list-modules 2>/dev/null | grep -q '^jdk.compiler@'; then
  JAVAC_BIN="$ROOT/javac-wrapper.sh"
fi
BUILD="$ROOT/build"
GEN="$BUILD/gen"
OBJ="$BUILD/obj"
RES_FLAT="$BUILD/res_flat"
OUT="$BUILD/out"

AAPT2="$BT/aapt2"
D8="$BT/d8"
ZIPALIGN="$BT/zipalign"
APKSIGNER="$BT/apksigner"

if [[ ! -x "$AAPT2" ]]; then
  echo "No encuentro aapt2 en $BT"
  exit 1
fi
if [[ -z "$JAVAC_BIN" || ! -x "$JAVAC_BIN" ]]; then
  echo "No encuentro javac. Instala un JDK 11 o superior o define JAVAC=/ruta/bin/javac"
  exit 1
fi

rm -rf "$BUILD"
mkdir -p "$GEN" "$OBJ" "$RES_FLAT" "$OUT" "$BUILD/dex"

echo "[1/6] Compilando recursos…"
find "$ROOT/app/src/main/res" -type f | sort | while read -r f; do
  "$AAPT2" compile -o "$RES_FLAT" "$f"
done

echo "[2/6] Link de recursos + R.java…"
find "$RES_FLAT" -type f | sort > "$BUILD/flats.txt"
# aapt2 link accepts a directory of compiled flats via -R or listed files
set +e
"$AAPT2" link \
  -o "$BUILD/base.apk" \
  -I "$ANDROID_JAR" \
  --manifest "$ROOT/app/src/main/AndroidManifest.xml" \
  --java "$GEN" \
  --auto-add-overlay \
  --min-sdk-version 26 \
  --target-sdk-version 34 \
  --version-code "$VERSION_CODE" \
  --version-name "$VERSION_NAME" \
  $(cat "$BUILD/flats.txt")
LINK_RC=$?
set -e
if [[ $LINK_RC -ne 0 ]]; then
  echo "aapt2 link falló"
  exit $LINK_RC
fi

echo "[3/6] Compilando Java…"
find "$ROOT/app/src/main/java" "$GEN" -name "*.java" | sort > "$BUILD/java.txt"
"$JAVAC_BIN" --release 11 \
  -encoding UTF-8 \
  -classpath "$ANDROID_JAR" \
  -d "$OBJ" \
  @"$BUILD/java.txt"

echo "[4/6] DEX…"
find "$OBJ" -name "*.class" > "$BUILD/classes.txt"
"$D8" --min-api 26 --lib "$ANDROID_JAR" --output "$BUILD/dex" $(cat "$BUILD/classes.txt")

echo "[5/6] Empaquetando APK…"
cp "$BUILD/base.apk" "$BUILD/unsigned.apk"
# d8 may emit classes.dex and optionally more
(
  cd "$BUILD/dex"
  zip -qj "$BUILD/unsigned.apk" ./*.dex
)

echo "[6/6] Align + firma debug…"
"$ZIPALIGN" -f -p 4 "$BUILD/unsigned.apk" "$OUT/akari-unsigned-aligned.apk"

KS="$ROOT/debug.keystore"
if [[ ! -f "$KS" ]]; then
  keytool -genkeypair -v -keystore "$KS" -alias akari \
    -keyalg RSA -keysize 2048 -validity 10000 \
    -storepass android -keypass android \
    -dname "CN=AKARI, OU=Zarxus, O=Zarxus, L=Hermosillo, ST=Sonora, C=MX"
fi

"$APKSIGNER" sign \
  --ks "$KS" \
  --ks-key-alias akari \
  --ks-pass pass:android \
  --key-pass pass:android \
  --out "$OUT/AKARI-v${VERSION_NAME}.apk" \
  "$OUT/akari-unsigned-aligned.apk"

"$APKSIGNER" verify --verbose "$OUT/AKARI-v${VERSION_NAME}.apk"
cp "$OUT/AKARI-v${VERSION_NAME}.apk" "$ROOT/AKARI-v${VERSION_NAME}.apk"
echo
echo "APK listo: $ROOT/AKARI-v${VERSION_NAME}.apk"
ls -lh "$ROOT/AKARI-v${VERSION_NAME}.apk"
