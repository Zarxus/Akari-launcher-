package mx.zarxus.akari;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

/** Thin rain/scan overlay so the wall feels alive even between GIF frames. */
public class ScanView extends View {
    private final Paint p = new Paint();
    private boolean attached;
    private boolean run;
    private float phase;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!run) return;
            phase += 0.04f * Prefs.motionScale();
            invalidate();
            postDelayed(this, Prefs.liveWall() ? (Prefs.motionLevel() == 0 ? 50L : 33L) : 500L);
        }
    };

    public ScanView(Context c) { super(c); boot(); }
    public ScanView(Context c, AttributeSet a) { super(c, a); boot(); }

    private void boot() {
        p.setStyle(Paint.Style.STROKE);
        p.setStrokeWidth(1.2f);
        setWillNotDraw(false);
        setClickable(false);
        setFocusable(false);
    }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        attached = true;
        syncLoop();
    }

    @Override protected void onDetachedFromWindow() {
        attached = false;
        run = false;
        removeCallbacks(tick);
        super.onDetachedFromWindow();
    }

    @Override protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        run = attached && visibility == VISIBLE;
        syncLoop();
    }

    private void syncLoop() {
        removeCallbacks(tick);
        run = attached && getWindowVisibility() == VISIBLE;
        if (run) post(tick);
    }

    @Override protected void onDraw(Canvas c) {
        if (!Prefs.liveWall()) return;
        int w = getWidth();
        int h = getHeight();
        if (w == 0) return;
        float heat = Prefs.heat() / 100f;
        p.setColor(0x22FF2ED9);
        for (int i = 0; i < 10; i++) {
            float x = ((i * 37 + phase * 18) % 1f) * w;
            c.drawLine(x, 0, x + 8, h, p);
        }
        p.setColor(0x182EF0FF);
        float y = (float) ((Math.sin(phase) * 0.5 + 0.5) * h);
        c.drawLine(0, y, w, y, p);
        int vig = (int) (20 + heat * 30);
        p.setStyle(Paint.Style.FILL);
        p.setColor((vig << 24) | 0x00FF2ED9);
        c.drawRect(0, 0, w, h * 0.08f, p);
        p.setStyle(Paint.Style.STROKE);
    }
}
