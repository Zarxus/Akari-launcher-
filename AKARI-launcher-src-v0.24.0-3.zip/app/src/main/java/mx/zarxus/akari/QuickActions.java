package mx.zarxus.akari;

import android.content.Context;
import android.content.Intent;
import android.hardware.camera2.CameraCharacteristics;
import android.hardware.camera2.CameraManager;
import android.net.Uri;
import android.provider.Settings;
import android.widget.Toast;

public final class QuickActions {
    private static boolean torch;

    private QuickActions() {}

    public static void wifi(Context c) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                c.startActivity(new Intent(Settings.Panel.ACTION_WIFI));
                return;
            }
            c.startActivity(new Intent(Settings.ACTION_WIFI_SETTINGS));
        } catch (Exception e) { settings(c); }
    }

    public static void bluetooth(Context c) {
        try {
            if (android.os.Build.VERSION.SDK_INT >= 29) {
                c.startActivity(new Intent(Settings.Panel.ACTION_INTERNET_CONNECTIVITY));
                return;
            }
            c.startActivity(new Intent(Settings.ACTION_BLUETOOTH_SETTINGS));
        } catch (Exception e) { settings(c); }
    }

    public static void settings(Context c) {
        c.startActivity(new Intent(Settings.ACTION_SETTINGS));
    }

    public static void volume(Context c) {
        try {
            c.startActivity(new Intent(Settings.ACTION_SOUND_SETTINGS));
        } catch (Exception e) { settings(c); }
    }

    public static void phone(Context c) {
        try {
            c.startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:")));
        } catch (Exception e) {
            Toast.makeText(c, "Sin marcador", Toast.LENGTH_SHORT).show();
        }
    }

    public static void sms(Context c) {
        try {
            c.startActivity(new Intent(Intent.ACTION_SENDTO, Uri.parse("smsto:")));
        } catch (Exception e) {
            Toast.makeText(c, "Sin mensajes", Toast.LENGTH_SHORT).show();
        }
    }

    public static void webSearch(Context c, String q) {
        String engine = Prefs.searchEngine();
        String url;
        try {
            String enc = java.net.URLEncoder.encode(q, "UTF-8");
            if ("ddg".equals(engine)) url = "https://duckduckgo.com/?q=" + enc;
            else if ("google".equals(engine)) url = "https://www.google.com/search?q=" + enc;
            else url = "https://www.bing.com/search?q=" + enc;
            c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(url)));
        } catch (Exception e) {
            Toast.makeText(c, "Sin navegador", Toast.LENGTH_SHORT).show();
        }
    }

    public static void openLink(Context c, String link) {
        if (link == null || link.isEmpty()) return;
        try {
            c.startActivity(new Intent(Intent.ACTION_VIEW, Uri.parse(link)));
        } catch (Exception e) {
            Toast.makeText(c, "No se pudo abrir", Toast.LENGTH_SHORT).show();
        }
    }

    public static void appInfo(Context c, String pkg) {
        try {
            Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
            i.setData(Uri.parse("package:" + pkg));
            c.startActivity(i);
        } catch (Exception e) { settings(c); }
    }

    public static void uninstall(Context c, String pkg) {
        try {
            c.startActivity(new Intent(Intent.ACTION_DELETE, Uri.parse("package:" + pkg)));
        } catch (Exception e) {
            Toast.makeText(c, "No se puede desinstalar", Toast.LENGTH_SHORT).show();
        }
    }

    public static boolean toggleTorch(Context c) {
        try {
            CameraManager cm = (CameraManager) c.getSystemService(Context.CAMERA_SERVICE);
            if (cm == null) return false;
            for (String id : cm.getCameraIdList()) {
                CameraCharacteristics ch = cm.getCameraCharacteristics(id);
                Boolean flash = ch.get(CameraCharacteristics.FLASH_INFO_AVAILABLE);
                Integer facing = ch.get(CameraCharacteristics.LENS_FACING);
                if (flash != null && flash && facing != null
                        && facing == CameraCharacteristics.LENS_FACING_BACK) {
                    torch = !torch;
                    cm.setTorchMode(id, torch);
                    return torch;
                }
            }
        } catch (Exception e) {
            Toast.makeText(c, "Sin linterna", Toast.LENGTH_SHORT).show();
        }
        return torch;
    }

    public static boolean torchOn() { return torch; }
}
