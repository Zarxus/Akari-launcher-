package mx.zarxus.akari;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Deque;
import java.util.List;
import java.util.Random;

/** Compact chess engine used by Mate Link. Castling and en-passant are intentionally omitted. */
public class ChessBoard {
    public final char[] s = new char[64];
    public boolean white = true;
    public int lastFrom = -1, lastTo = -1;

    private static final int[] N = {-17, -15, -10, -6, 6, 10, 15, 17};
    private static final int[] K = {-9, -8, -7, -1, 1, 7, 8, 9};
    private static final int[] B = {-9, -7, 7, 9};
    private static final int[] R = {-8, -1, 1, 8};
    private static final Random RNG = new Random();
    private final Deque<State> history = new ArrayDeque<>();

    private static class State {
        final char[] pieces;
        final boolean side;
        final int from, to;
        State(char[] pieces, boolean side, int from, int to) {
            this.pieces = pieces;
            this.side = side;
            this.from = from;
            this.to = to;
        }
    }

    public ChessBoard() { reset(); }

    public void reset() {
        String start = "rnbqkbnrpppppppp................................PPPPPPPPRNBQKBNR";
        for (int i = 0; i < 64; i++) s[i] = start.charAt(i);
        white = true;
        lastFrom = lastTo = -1;
        history.clear();
    }

    public char at(int i) { return (i < 0 || i > 63) ? '.' : s[i]; }
    public int historySize() { return history.size(); }
    public ChessBoard snapshot() {
        ChessBoard copy = new ChessBoard();
        System.arraycopy(s, 0, copy.s, 0, 64);
        copy.white = white;
        copy.lastFrom = lastFrom;
        copy.lastTo = lastTo;
        copy.history.clear();
        return copy;
    }
    public static boolean isWhite(char c) { return c >= 'A' && c <= 'Z'; }
    public static boolean isBlack(char c) { return c >= 'a' && c <= 'z'; }

    public List<Integer> movesFrom(int from) {
        List<Integer> out = new ArrayList<>();
        char p = at(from);
        if (p == '.') return out;
        boolean side = isWhite(p);
        char lower = Character.toLowerCase(p);
        if (lower == 'p') pawn(from, side, out);
        else if (lower == 'n') leaps(from, side, N, out);
        else if (lower == 'k') leaps(from, side, K, out);
        else if (lower == 'b') rays(from, side, B, out);
        else if (lower == 'r') rays(from, side, R, out);
        else if (lower == 'q') { rays(from, side, B, out); rays(from, side, R, out); }
        List<Integer> legal = new ArrayList<>();
        for (int to : out) if (safe(from, to, side)) legal.add(to);
        return legal;
    }

    public char play(int from, int to) {
        if (!movesFrom(from).contains(to)) return 0;
        history.push(new State(Arrays.copyOf(s, s.length), white, lastFrom, lastTo));
        char cap = apply(from, to);
        white = !white;
        return cap == '.' ? '.' : cap;
    }

    public boolean undo() {
        if (history.isEmpty()) return false;
        State old = history.pop();
        System.arraycopy(old.pieces, 0, s, 0, 64);
        white = old.side;
        lastFrom = old.from;
        lastTo = old.to;
        return true;
    }

    public boolean inCheck(boolean forWhite) {
        int king = -1;
        char target = forWhite ? 'K' : 'k';
        for (int i = 0; i < 64; i++) if (s[i] == target) king = i;
        if (king < 0) return true;
        for (int i = 0; i < 64; i++) {
            char p = s[i];
            if (p != '.' && isWhite(p) != forWhite && attacks(i, king)) return true;
        }
        return false;
    }

    public boolean hasMove(boolean forWhite) { return !allMoves(forWhite).isEmpty(); }

    /** Returns and plays AKARI's move. Levels map to 1-3 plies plus tactical ordering. */
    public char aiMove(int level) {
        int[] pick = bestMove(false, level);
        if (pick == null) return '.';
        char cap = play(pick[0], pick[1]);
        return cap == 0 ? '.' : cap;
    }

    /** Finds a move without changing the board; used both by the AI and the hint control. */
    public int[] bestMove(boolean forWhite, int level) {
        List<int[]> moves = allMoves(forWhite);
        if (moves.isEmpty()) return null;
        int savedFrom = lastFrom, savedTo = lastTo;
        orderMoves(moves);
        int depth = Math.max(1, Math.min(3, level));
        int best = forWhite ? Integer.MIN_VALUE : Integer.MAX_VALUE;
        List<int[]> choices = new ArrayList<>();
        for (int[] mv : moves) {
            char[] copy = Arrays.copyOf(s, 64);
            apply(mv[0], mv[1]);
            int score = search(depth - 1, !forWhite, -12000, 12000);
            System.arraycopy(copy, 0, s, 0, 64);
            if ((forWhite && score > best) || (!forWhite && score < best)) {
                best = score;
                choices.clear();
                choices.add(mv);
            } else if (score == best) choices.add(mv);
        }
        lastFrom = savedFrom;
        lastTo = savedTo;
        return choices.get(RNG.nextInt(choices.size()));
    }

    private int search(int depth, boolean side, int alpha, int beta) {
        List<int[]> moves = allMoves(side);
        if (moves.isEmpty()) {
            if (!inCheck(side)) return 0;
            return side ? -10000 - depth : 10000 + depth;
        }
        if (depth <= 0) return eval();
        orderMoves(moves);
        if (side) {
            int best = Integer.MIN_VALUE;
            for (int[] mv : moves) {
                char[] copy = Arrays.copyOf(s, 64);
                apply(mv[0], mv[1]);
                best = Math.max(best, search(depth - 1, false, alpha, beta));
                System.arraycopy(copy, 0, s, 0, 64);
                alpha = Math.max(alpha, best);
                if (beta <= alpha) break;
            }
            return best;
        }
        int best = Integer.MAX_VALUE;
        for (int[] mv : moves) {
            char[] copy = Arrays.copyOf(s, 64);
            apply(mv[0], mv[1]);
            best = Math.min(best, search(depth - 1, true, alpha, beta));
            System.arraycopy(copy, 0, s, 0, 64);
            beta = Math.min(beta, best);
            if (beta <= alpha) break;
        }
        return best;
    }

    public int eval() {
        int score = 0;
        for (int i = 0; i < 64; i++) {
            char p = s[i];
            if (p == '.') continue;
            int sign = isWhite(p) ? 1 : -1;
            int row = i / 8, col = i % 8;
            int center = 7 - (Math.abs(3 - col) + Math.abs(3 - row));
            int positional = Character.toLowerCase(p) == 'p'
                    ? (isWhite(p) ? 6 - row : row - 1) : Math.max(0, center);
            score += sign * (val(p) * 10 + positional);
        }
        return score;
    }

    public String materialLabel() {
        int raw = eval() / 10;
        return raw == 0 ? "material igualado" : raw > 0 ? "+" + raw + " para ti" : "+" + (-raw) + " para AKARI";
    }

    public static String square(int i) {
        if (i < 0 || i > 63) return "—";
        return String.valueOf((char) ('a' + i % 8)) + (8 - i / 8);
    }

    public static String moveLabel(int[] mv) {
        return mv == null ? "sin jugada" : square(mv[0]) + " → " + square(mv[1]);
    }

    public static int val(char p) {
        switch (Character.toLowerCase(p)) {
            case 'p': return 1;
            case 'n': case 'b': return 3;
            case 'r': return 5;
            case 'q': return 9;
            case 'k': return 100;
            default: return 0;
        }
    }

    public static String glyph(char p) {
        switch (p) {
            case 'K': return "♔"; case 'Q': return "♕"; case 'R': return "♖";
            case 'B': return "♗"; case 'N': return "♘"; case 'P': return "♙";
            case 'k': return "♚"; case 'q': return "♛"; case 'r': return "♜";
            case 'b': return "♝"; case 'n': return "♞"; case 'p': return "♟";
            default: return "";
        }
    }

    private List<int[]> allMoves(boolean forWhite) {
        List<int[]> out = new ArrayList<>();
        for (int i = 0; i < 64; i++) {
            char p = s[i];
            if (p == '.' || isWhite(p) != forWhite) continue;
            for (int t : movesFrom(i)) out.add(new int[]{i, t});
        }
        return out;
    }

    private void orderMoves(List<int[]> moves) {
        moves.sort((a, b) -> Integer.compare(val(s[b[1]]), val(s[a[1]])));
    }

    private char apply(int from, int to) {
        char piece = s[from], cap = s[to];
        s[to] = piece;
        s[from] = '.';
        if (piece == 'P' && to / 8 == 0) s[to] = 'Q';
        if (piece == 'p' && to / 8 == 7) s[to] = 'q';
        lastFrom = from;
        lastTo = to;
        return cap;
    }

    private boolean safe(int from, int to, boolean side) {
        char[] copy = Arrays.copyOf(s, 64);
        int savedFrom = lastFrom, savedTo = lastTo;
        apply(from, to);
        boolean ok = !inCheck(side);
        System.arraycopy(copy, 0, s, 0, 64);
        lastFrom = savedFrom;
        lastTo = savedTo;
        return ok;
    }

    private void pawn(int from, boolean side, List<Integer> out) {
        int dir = side ? -8 : 8;
        int start = side ? 6 : 1;
        int row = from / 8, file = from % 8;
        int one = from + dir;
        if (on(one) && s[one] == '.') {
            out.add(one);
            int two = from + dir * 2;
            if (row == start && on(two) && s[two] == '.') out.add(two);
        }
        int[] delta = {dir - 1, dir + 1};
        int[] files = {file - 1, file + 1};
        for (int i = 0; i < 2; i++) {
            if (files[i] < 0 || files[i] > 7) continue;
            int to = from + delta[i];
            if (on(to) && s[to] != '.' && isWhite(s[to]) != side) out.add(to);
        }
    }

    private void leaps(int from, boolean side, int[] delta, List<Integer> out) {
        int file = from % 8;
        for (int step : delta) {
            int to = from + step;
            if (!on(to) || Math.abs(to % 8 - file) > 2) continue;
            char q = s[to];
            if (q == '.' || isWhite(q) != side) out.add(to);
        }
    }

    private void rays(int from, boolean side, int[] delta, List<Integer> out) {
        int file = from % 8;
        for (int step : delta) {
            int to = from;
            while (true) {
                to += step;
                if (!on(to) || Math.abs(to % 8 - file) > 1) break;
                file = to % 8;
                char q = s[to];
                if (q == '.') out.add(to);
                else {
                    if (isWhite(q) != side) out.add(to);
                    break;
                }
            }
            file = from % 8;
        }
    }

    private boolean attacks(int from, int to) {
        char p = s[from];
        boolean side = isWhite(p);
        List<Integer> raw = new ArrayList<>();
        char lower = Character.toLowerCase(p);
        if (lower == 'p') {
            int dir = side ? -8 : 8, file = from % 8;
            if (file > 0 && on(from + dir - 1)) raw.add(from + dir - 1);
            if (file < 7 && on(from + dir + 1)) raw.add(from + dir + 1);
        } else if (lower == 'n') leaps(from, side, N, raw);
        else if (lower == 'k') leaps(from, side, K, raw);
        else if (lower == 'b') rays(from, side, B, raw);
        else if (lower == 'r') rays(from, side, R, raw);
        else if (lower == 'q') { rays(from, side, B, raw); rays(from, side, R, raw); }
        return raw.contains(to);
    }

    private static boolean on(int i) { return i >= 0 && i < 64; }
}
