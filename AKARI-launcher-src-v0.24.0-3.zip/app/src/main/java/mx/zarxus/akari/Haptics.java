package mx.zarxus.akari;
import android.content.Context;
import android.os.Build;
import android.os.VibrationEffect;
import android.os.Vibrator;
public final class Haptics {
    private Haptics(){}
    public static void tap(Context c){one(c,14,58);}
    public static void press(Context c){one(c,22,76);}
    public static void success(Context c){wave(c,new long[]{0,28,45,55},new int[]{0,85,0,145});}
    public static void capture(Context c){wave(c,new long[]{0,38,32,80},new int[]{0,125,0,190});}
    public static void warning(Context c){wave(c,new long[]{0,70,55,70},new int[]{0,150,0,150});}
    public static void rift(Context c){wave(c,new long[]{0,18,24,32,26,58},new int[]{0,52,0,96,0,168});}
    private static void one(Context c,long d,int a){if(!Prefs.haptic())return;try{
        Vibrator v=(Vibrator)c.getSystemService(Context.VIBRATOR_SERVICE);if(v==null||!v.hasVibrator())return;
        int strength=Math.max(1,Math.min(255,Math.round(a*Prefs.motionScale())));
        if(Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createOneShot(d,strength));else v.vibrate(d);
    }catch(Exception ignored){}}
    private static void wave(Context c,long[] t,int[] a){if(!Prefs.haptic())return;try{
        Vibrator v=(Vibrator)c.getSystemService(Context.VIBRATOR_SERVICE);if(v==null||!v.hasVibrator())return;
        int[] scaled=a.clone();for(int i=0;i<scaled.length;i++)if(scaled[i]>0)
            scaled[i]=Math.max(1,Math.min(255,Math.round(scaled[i]*Prefs.motionScale())));
        if(Build.VERSION.SDK_INT>=26)v.vibrate(VibrationEffect.createWaveform(t,scaled,-1));else v.vibrate(t,-1);
    }catch(Exception ignored){}}
}
