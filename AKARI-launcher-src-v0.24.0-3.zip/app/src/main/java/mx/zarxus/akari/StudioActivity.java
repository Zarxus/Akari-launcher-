package mx.zarxus.akari;

import android.app.Activity;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.view.animation.DecelerateInterpolator;
import android.widget.AdapterView;
import android.widget.EditText;
import android.widget.GridView;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import java.util.List;

public class StudioActivity extends Activity {
    private static final String[] KINDS = {
            "recientes", "todas", "chat", "media", "foto", "web", "tools", "games", "ocultas"
    };

    private final Handler handler = new Handler(Looper.getMainLooper());
    private final BodyPhysics body = new BodyPhysics();
    private List<AppInfo> all;
    private AppAdapter adapter;
    private String kind = "recientes";
    private TextView line, kindTitle, countTv, featName;
    private ImageView art, featIcon;
    private ParticleView particles;
    private LinearLayout hero, feature;
    private AppInfo featured;
    private int kindIndex = 0;
    private float downX;
    private boolean dragging;
    private long lastTick;

    private final Runnable frame = new Runnable() {
        @Override public void run() {
            long now = System.nanoTime();
            float dt = lastTick == 0 ? 0.016f : (now - lastTick) / 1_000_000_000f;
            lastTick = now;
            if (dt > 0.05f) dt = 0.05f;
            if (!dragging) {
                body.y += (float) Math.sin(now / 400_000_000.0) * 0.15f;
            }
            body.tick(dt);
            handler.postDelayed(this, Prefs.physics() ? (Prefs.motionLevel() == 0 ? 33 : 16) : 500);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_studio);
        Insets.attach(this, findViewById(R.id.studioContent));
        SoundEngine.init(this);
        Voice.init(this);
        all = AppRepository.loadAllLaunchable(this);
        line = findViewById(R.id.studioLine);
        kindTitle = findViewById(R.id.studioKindTitle);
        countTv = findViewById(R.id.studioCount);
        featName = findViewById(R.id.featName);
        featIcon = findViewById(R.id.featIcon);
        art = findViewById(R.id.studioArt);
        particles = findViewById(R.id.studioParticles);
        hero = findViewById(R.id.studioHero);
        feature = findViewById(R.id.studioFeature);
        body.attach(hero);
        ((TextView) findViewById(R.id.studioRank)).setText(Identity.rank());
        pose();

        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { SoundEngine.back(); finish(); }
        });
        feature.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openFeatured(); }
        });
        findViewById(R.id.featGo).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { openFeatured(); }
        });

        hero.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, MotionEvent e) {
                switch (e.getActionMasked()) {
                    case MotionEvent.ACTION_DOWN:
                        dragging = true;
                        downX = e.getRawX();
                        body.grab();
                        body.squash();
                        return true;
                    case MotionEvent.ACTION_MOVE:
                        body.dragBy((e.getRawX() - downX) * 0.02f, 0);
                        return true;
                    case MotionEvent.ACTION_UP:
                    case MotionEvent.ACTION_CANCEL:
                        dragging = false;
                        float dx = e.getRawX() - downX;
                        body.release(dx * 0.15f, -20);
                        if (Math.abs(dx) > 80) {
                            cycleKind(dx < 0 ? 1 : -1);
                        } else if (Math.abs(dx) < 24) {
                            Prefs.addHeat(1);
                            say("Sí, estoy aquí. Elige o deslízame para cambiar de estante.");
                            body.jiggle();
                            if (particles != null) particles.burst(80, 160);
                        }
                        return true;
                }
                return false;
            }
        });

        adapter = new AppAdapter(this, R.layout.item_app);
        GridView grid = findViewById(R.id.studioGrid);
        grid.setAdapter(adapter);
        grid.setOnItemLongClickListener(new AdapterView.OnItemLongClickListener() {
            @Override public boolean onItemLongClick(AdapterView<?> p, View v, int pos, long id) {
                final AppInfo a = adapter.getItem(pos);
                AppActions.show(StudioActivity.this, a, () -> {
                    all = AppRepository.loadAllLaunchable(StudioActivity.this);
                    applyFilter(((EditText) findViewById(R.id.studioSearch)).getText().toString());
                });
                return true;
            }
        });
        grid.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                AppInfo a = adapter.getItem(pos);
                body.jiggle();
                if (particles != null) particles.burst(200, 400);
                String s = "Toma. " + a.label + ". La abrí yo.";
                showLine(s);
                v.animate().scaleX(0.86f).scaleY(0.86f).setDuration(80)
                        .withEndAction(new Runnable() {
                            @Override public void run() {
                                v.animate().scaleX(1f).scaleY(1f).setDuration(140)
                                        .setInterpolator(new DecelerateInterpolator()).start();
                            }
                        }).start();
                Launcher.open(StudioActivity.this, a);
            }
        });

        LinearLayout row = findViewById(R.id.kindRow);
        for (int i = 0; i < KINDS.length; i++) {
            final int idx = i;
            final String k = KINDS[i];
            TextView chip = new TextView(this);
            chip.setText(k.toUpperCase());
            chip.setTextColor(0xFF2EF0FF);
            chip.setTextSize(12);
            chip.setPadding(20, 12, 20, 12);
            chip.setBackgroundResource(R.drawable.bg_dock);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                    LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT);
            lp.setMargins(0, 0, 8, 0);
            chip.setOnClickListener(new View.OnClickListener() {
                @Override public void onClick(View v) {
                    kindIndex = idx;
                    selectKind(k);
                    v.animate().scaleX(0.9f).scaleY(0.9f).setDuration(70)
                            .withEndAction(new Runnable() {
                                @Override public void run() {
                                    v.animate().scaleX(1f).scaleY(1f).setDuration(120).start();
                                }
                            }).start();
                }
            });
            row.addView(chip, lp);
        }

        EditText q = findViewById(R.id.studioSearch);
        q.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int st, int c, int a) {}
            @Override public void onTextChanged(CharSequence s, int st, int b, int c) {}
            @Override public void afterTextChanged(Editable s) {
                applyFilter(s.toString());
                if (s.length() >= 2) {
                    showLine("Filtro «" + s + "» · " + adapter.getCount()
                            + (adapter.getCount() == 1 ? " coincidencia" : " coincidencias"));
                }
            }
        });

        selectKind("recientes");
        hero.setAlpha(0f);
        hero.setTranslationY(30f);
        hero.animate().alpha(1f).translationY(0).setDuration(380)
                .setInterpolator(new DecelerateInterpolator()).start();
        feature.setAlpha(0f);
        feature.animate().alpha(1f).setStartDelay(160).setDuration(320).start();
    }

    private void cycleKind(int dir) {
        kindIndex = (kindIndex + dir + KINDS.length) % KINDS.length;
        selectKind(KINDS[kindIndex]);
    }

    private void selectKind(String k) {
        kind = k;
        kindTitle.setText(k.toUpperCase());
        pose();
        say(Identity.pickLine(k));
        body.impulse(kindIndex % 2 == 0 ? 40 : -40, -30);
        if (particles != null) particles.burst(120, 180);
        applyFilter(((EditText) findViewById(R.id.studioSearch)).getText().toString());
    }

    private void applyFilter(String q) {
        List<AppInfo> base = AppKinds.filter(all, kind);
        if (q != null && q.trim().length() > 0) base = AppRepository.filter(base, q.trim());
        adapter.setData(base);
        countTv.setText(base.size() + " en este estante · desliza mi tarjeta");
        if (base.isEmpty()) {
            featured = null;
            featName.setText("Nada aquí. Cambia de estante.");
            featIcon.setImageDrawable(null);
        } else {
            featured = base.get(0);
            featName.setText(featured.label);
            featIcon.setImageDrawable(featured.icon);
            feature.setTag(featured.packageName);
        }
    }

    private void openFeatured() {
        if (featured == null) {
            say("No hay nada que abrir en este estante.");
            return;
        }
        showLine("Esta. " + featured.label + ".");
        body.jiggle();
        Launcher.open(this, featured);
    }

    private void pose() {
        if (art == null) return;
        if ("foto".equals(kind) || Prefs.heat() >= 70) art.setImageResource(R.drawable.cg_face);
        else if ("games".equals(kind) || "media".equals(kind) || Prefs.heat() >= 40)
            art.setImageResource(R.drawable.cg_jacket);
        else art.setImageResource(R.drawable.akari_portrait);
        ImageView wall = findViewById(R.id.studioWall);
        LiveWall.apply(wall);
    }

    private void say(String s) {
        showLine(s);
        Voice.speak(s);
    }

    private void showLine(String s) {
        if (line != null) line.setText(s);
        if (s != null && !s.isEmpty()) Prefs.setLastSay(s);
    }

    @Override
    protected void onResume() {
        super.onResume();
        handler.removeCallbacks(frame);
        handler.post(frame);
        all = AppRepository.loadAllLaunchable(this);
        EditText q = findViewById(R.id.studioSearch);
        applyFilter(q == null ? "" : q.getText().toString());
    }

    @Override
    protected void onPause() {
        super.onPause();
        handler.removeCallbacks(frame);
    }
}
