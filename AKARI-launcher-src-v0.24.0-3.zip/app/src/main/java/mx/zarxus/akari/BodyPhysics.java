package mx.zarxus.akari;

import android.view.View;

/** Semi-implicit Euler spring. Feels like a body, not a tween. */
public class BodyPhysics {
    public float x, y, vx, vy;
    public float rot, vr;
    public float sx = 1f, sy = 1f, vsx, vsy;
    public boolean dragging;
    public View view;

    private static final float K = 56f;
    private static final float C = 10.8f;
    private static final float KR = 34f;
    private static final float KS = 68f;

    public void attach(View v) { view = v; }

    public void grab() {
        dragging = true;
        vx = vy = vr = 0;
        if (view != null) view.animate().cancel();
    }

    public void dragBy(float dx, float dy) {
        x += dx;
        y += dy;
        rot = clamp(x * 0.05f, -18f, 18f);
        apply();
    }

    public void release(float flingX, float flingY) {
        dragging = false;
        float motion = Prefs.motionScale();
        vx = flingX * 8.5f * motion;
        vy = flingY * 8.5f * motion;
        SoundEngine.spring();
    }

    public void impulse(float ix, float iy) {
        float motion = Prefs.motionScale();
        vx += ix * motion;
        vy += iy * motion;
        vr += ix * 0.15f * motion;
    }

    public void jiggle() {
        impulse((float) (Math.random() * 80 - 40), -55f);
        vsy -= 0.9f;
        vsx += 0.35f;
    }

    public void squash() {
        float motion = Prefs.motionScale();
        sx = 1f - .10f * motion;
        sy = 1f - .14f * motion;
        vsx = 1.1f * motion;
        vsy = 1.4f * motion;
    }

    public void tick(float dt) {
        if (view == null) return;
        if (!Prefs.physics()) {
            x = y = rot = vx = vy = vr = 0;
            sx = sy = 1f;
            apply();
            return;
        }
        if (!dragging) {
            vx += (-K * x - C * vx) * dt;
            vy += (-K * y - C * vy) * dt;
            vr += (-KR * rot - C * vr) * dt;
            vsx += (-KS * (sx - 1f) - 10f * vsx) * dt;
            vsy += (-KS * (sy - 1f) - 10f * vsy) * dt;
            x += vx * dt;
            y += vy * dt;
            rot += vr * dt;
            sx += vsx * dt;
            sy += vsy * dt;
            if (Math.abs(x) < 0.15f && Math.abs(vx) < 2f) { x = 0; vx = 0; }
            if (Math.abs(y) < 0.15f && Math.abs(vy) < 2f) { y = 0; vy = 0; }
        }
        apply();
    }

    public void apply() {
        if (view == null) return;
        view.setTranslationX(x);
        view.setTranslationY(y);
        view.setRotation(rot);
        view.setScaleX(Math.max(0.78f, Math.min(1.18f, sx)));
        view.setScaleY(Math.max(0.78f, Math.min(1.18f, sy)));
    }

    private static float clamp(float v, float a, float b) {
        return Math.max(a, Math.min(b, v));
    }
}
