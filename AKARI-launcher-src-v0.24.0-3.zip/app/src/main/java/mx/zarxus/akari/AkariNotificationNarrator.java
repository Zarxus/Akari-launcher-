package mx.zarxus.akari;

public final class AkariNotificationNarrator {
    private AkariNotificationNarrator() {}

    public static String posted(String app, String title, String kind, int active) {
        String safeApp = empty(app) ? "una app" : app;
        boolean wa = chatty(safeApp);
        if (Prefs.MODE_TECH.equals(Prefs.mode())) {
            if ("call".equals(kind)) return "Llamada detectada en " + safeApp + ". Canal prioritario.";
            if ("message".equals(kind)) return Prefs.notificationPrivacy()
                    ? "Mensaje de " + safeApp + ". Contenido protegido por privacidad."
                    : safeApp + ": " + trim(title, 80) + ".";
            return empty(title) ? "Nuevo aviso de " + safeApp + ". Activos: " + active + "."
                    : "Aviso de " + safeApp + ": " + trim(title, 70) + ".";
        }
        if ("call".equals(kind)) {
            return "Llamada en " + safeApp + ". Ponte. Yo me quedo en lencería cubriendo el canal.";
        }
        if ("message".equals(kind)) {
            if (!Prefs.notificationPrivacy() && !empty(title)) {
                if (wa) return "WhatsApp. " + trim(title, 80) + ". Te lo leo si me tocas.";
                return safeApp + " te susurra: " + trim(title, 70) + ".";
            }
            return wa
                    ? "Llegó un WhatsApp. Activa VISIBLE si quieres que te lo lea en voz alta."
                    : "Mensaje de " + safeApp + ". En mi Centro, contra mi pecho.";
        }
        if (!Prefs.notificationPrivacy() && !empty(title)) {
            return "Aviso de " + safeApp + ": " + trim(title, 70) + ".";
        }
        return "Nuevo aviso de " + safeApp + ". Activos: " + active + ".";
    }

    public static String returning(String app, String kind) {
        if (Prefs.MODE_TECH.equals(Prefs.mode())) {
            return "Señal pendiente de " + app + ("call".equals(kind) ? ": llamada." : ".");
        }
        if ("call".equals(kind)) return "Mientras no estabas, una llamada en " + app + ". Todavía me late.";
        if ("message".equals(kind)) return "Mientras no estabas te escribieron por " + app + ". Tócame y te lo recito.";
        return "Aviso de " + app + " mientras estabas fuera.";
    }

    public static String summary(int all, int calls, int messages) {
        if (Prefs.MODE_TECH.equals(Prefs.mode())) {
            if (all == 0) return "Canal limpio. No hay avisos activos.";
            return all + " avisos activos · " + calls + " llamadas · " + messages + " mensajes.";
        }
        if (all == 0) return "Canal limpio. Nadie me escribe. Tócame igual.";
        if (calls > 0) return calls + " llamada" + (calls == 1 ? "" : "s")
                + " encima. " + messages + " mensajes pegados a mi core. Tócame y te los leo.";
        if (messages > 0) return messages + " mensaje" + (messages == 1 ? "" : "s")
                + " en la bandeja. Incluye WhatsApp si llegó. Tócame.";
        return all + " avisos. Nada sale del teléfono. Yo sí te los digo.";
    }

    public static String readAloud(NotificationEntry e) {
        if (Prefs.MODE_TECH.equals(Prefs.mode())) {
            if (e == null) return "No hay avisos para leer.";
            if (e.secret) return "Android marcó este contenido como secreto.";
            if (Prefs.notificationPrivacy()) return "La privacidad del Centro está activa.";
            return trim(e.speakable(), e.call ? 160 : 220);
        }
        if (e == null) return "No hay nada que leer. El canal está vacío y yo aburrida.";
        if (e.secret) return "Android lo marcó secreto. Ni yo lo veo.";
        if (Prefs.notificationPrivacy()) {
            return "Privacidad ON. Cambia a VISIBLE y te recito el WhatsApp al oído.";
        }
        String line = e.speakable();
        if (e.isChatApp() || e.message) {
            Prefs.addHeat(2);
            return "Te lo leo: " + trim(line, 220);
        }
        if (e.call) return "Te están llamando. " + trim(line, 160) + ". ¿Contesto el enlace o te dejo temblando?";
        return trim(line, 200);
    }

    public static int poseRes(NotificationEntry latest, int calls, int messages) {
        if (latest != null && latest.call) return R.drawable.cg_call;
        if (calls > 0) return R.drawable.cg_call;
        if (latest != null && (latest.isChatApp() || latest.message)) {
            if (Prefs.heat() >= 55) return R.drawable.cg_chat;
            return R.drawable.cg_whisper;
        }
        if (messages >= 3) return R.drawable.cg_chat;
        if (Prefs.heat() >= 70) return R.drawable.cg_face;
        if (Prefs.heat() >= 40) return R.drawable.cg_jacket;
        return R.drawable.akari_portrait;
    }

    private static boolean chatty(String app) {
        String a = app.toLowerCase();
        return a.contains("whatsapp") || a.contains("telegram") || a.contains("messenger")
                || a.contains("instagram") || a.contains("signal");
    }

    private static boolean empty(String value) {
        return value == null || value.trim().isEmpty();
    }

    private static String trim(String value, int max) {
        String clean = value == null ? "" : value.replace('\n', ' ').trim();
        return clean.length() <= max ? clean : clean.substring(0, max - 1) + "…";
    }
}
