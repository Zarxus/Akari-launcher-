package mx.zarxus.akari;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public final class UsageStore {
    private static SharedPreferences p;

    public static void init(Context c) {
        p = c.getSharedPreferences("akari_usage", Context.MODE_PRIVATE);
    }

    public static void bump(String pkg) {
        if (p == null || pkg == null) return;
        p.edit().putInt(pkg, p.getInt(pkg, 0) + 1)
                .putLong("last::" + pkg, System.currentTimeMillis()).apply();
    }

    public static List<AppInfo> frequent(List<AppInfo> all, int n) {
        List<AppInfo> copy = new ArrayList<>(all);
        Collections.sort(copy, new Comparator<AppInfo>() {
            @Override public int compare(AppInfo a, AppInfo b) {
                int d = count(b.packageName) - count(a.packageName);
                if (d != 0) return d;
                return a.label.toString().compareToIgnoreCase(b.label.toString());
            }
        });
        if (copy.size() > n) return new ArrayList<>(copy.subList(0, n));
        return copy;
    }

    /** Returns only apps that have actually been launched through AKARI. */
    public static List<AppInfo> frequentUsed(List<AppInfo> all, int n) {
        List<AppInfo> used = new ArrayList<>();
        for (AppInfo app : all) if (count(app.packageName) > 0) used.add(app);
        Collections.sort(used, new Comparator<AppInfo>() {
            @Override public int compare(AppInfo a, AppInfo b) {
                int difference = count(b.packageName) - count(a.packageName);
                if (difference != 0) return difference;
                return a.label.toString().compareToIgnoreCase(b.label.toString());
            }
        });
        if (used.size() > n) return new ArrayList<>(used.subList(0, n));
        return used;
    }

    public static List<AppInfo> recentUsed(List<AppInfo> all, int n) {
        List<AppInfo> used = new ArrayList<>();
        for (AppInfo app : all) if (lastUsed(app.packageName) > 0L) used.add(app);
        Collections.sort(used, new Comparator<AppInfo>() {
            @Override public int compare(AppInfo a, AppInfo b) {
                return Long.compare(lastUsed(b.packageName), lastUsed(a.packageName));
            }
        });
        if (used.size() > n) return new ArrayList<>(used.subList(0, n));
        return used;
    }

    public static int count(String pkg) {
        return p == null ? 0 : p.getInt(pkg, 0);
    }

    public static long lastUsed(String pkg) {
        return p == null || pkg == null ? 0L : p.getLong("last::" + pkg, 0L);
    }

    public static Map<String, Integer> snapshot() {
        Map<String, Integer> m = new HashMap<>();
        if (p == null) return m;
        for (String k : p.getAll().keySet()) {
            Object v = p.getAll().get(k);
            if (v instanceof Integer) m.put(k, (Integer) v);
        }
        return m;
    }
}
