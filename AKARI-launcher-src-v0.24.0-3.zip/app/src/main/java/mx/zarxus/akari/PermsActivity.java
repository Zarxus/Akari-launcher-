package mx.zarxus.akari;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.admin.DevicePolicyManager;
import android.content.ComponentName;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.PowerManager;
import android.provider.Settings;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;

public class PermsActivity extends Activity {
    private LinearLayout list;
    private TextView line;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_perms);

        Insets.attach(this);        Voice.init(this);
        list = findViewById(R.id.permList);
        line = findViewById(R.id.permsLine);
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { SoundEngine.back(); finish(); }
        });
        findViewById(R.id.btnAllRuntime).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { askAll(); }
        });
        Voice.speak("Menú de accesos. Toca lo que falte y te mando al atajo.");
    }

    @Override
    protected void onResume() {
        super.onResume();
        render();
    }

    private void render() {
        list.removeAllViews();
        addRow("Micrófono", "Voz y baile (Visualizer)",
                granted(Manifest.permission.RECORD_AUDIO),
                new Runnable() { @Override public void run() { ask(new String[]{Manifest.permission.RECORD_AUDIO}, 1); } });
        if (Build.VERSION.SDK_INT >= 33) {
            addRow("Música", "Leer pistas descargadas",
                    granted(Manifest.permission.READ_MEDIA_AUDIO),
                    new Runnable() { @Override public void run() { ask(new String[]{Manifest.permission.READ_MEDIA_AUDIO}, 2); } });
        } else {
            addRow("Almacenamiento", "Leer música en el teléfono",
                    granted(Manifest.permission.READ_EXTERNAL_STORAGE),
                    new Runnable() { @Override public void run() { ask(new String[]{Manifest.permission.READ_EXTERNAL_STORAGE}, 2); } });
        }
        addRow("Centro AKARI", "Leer y operar avisos activos",
                AkariNotificationService.hasAccess(this),
                new Runnable() { @Override public void run() { AkariNotificationService.showAccessGuide(PermsActivity.this); } });
        if (Build.VERSION.SDK_INT >= 33) {
            addRow("Avisos de AKARI", "Mostrar alarma, llamadas y estado",
                    granted(Manifest.permission.POST_NOTIFICATIONS),
                    new Runnable() { @Override public void run() {
                        ask(new String[]{Manifest.permission.POST_NOTIFICATIONS}, 4);
                    } });
        }
        if (Build.VERSION.SDK_INT >= 31) {
            addRow("Alarma exacta", "Despertar a la hora elegida",
                    canExactAlarm(),
                    new Runnable() { @Override public void run() { openExactAlarm(); } });
        }
        if (Build.VERSION.SDK_INT >= 34) {
            addRow("Pantalla de despertador", "Mostrar AKARI sobre el bloqueo",
                    AlarmScheduler.canFullScreen(this),
                    new Runnable() { @Override public void run() { AlarmScheduler.requestFullScreen(PermsActivity.this); } });
        }
        addRow("Launcher por defecto", "Home = AKARI",
                isDefaultHome(),
                new Runnable() { @Override public void run() { openHomePicker(); } });
        addRow("Bloqueo de pantalla", "Admin para Lock Link",
                isAdmin(),
                new Runnable() { @Override public void run() { openAdmin(); } });
        addRow("Batería sin límite", "Que no me mate el ahorro",
                isUnrestrictedBattery(),
                new Runnable() { @Override public void run() { openBattery(); } });
        addRow("Ficha de la app", "Todos los interruptores de Android",
                false,
                new Runnable() { @Override public void run() { openAppDetails(); } });
    }

    private void addRow(final String title, String sub, boolean on, final Runnable action) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.VERTICAL);
        row.setPadding(14, 14, 14, 14);
        row.setBackgroundResource(R.drawable.bg_panel);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        lp.topMargin = 8;
        TextView t = new TextView(this);
        t.setText((on ? "●  " : "○  ") + title);
        t.setTextColor(on ? 0xFF2EF0FF : 0xFFFF2ED9);
        t.setTextSize(15);
        TextView s = new TextView(this);
        s.setText(on ? "listo · " + sub : "falta · toca para el atajo · " + sub);
        s.setTextColor(0xCCE8EEF7);
        s.setTextSize(12);
        row.addView(t);
        row.addView(s);
        row.setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                line.setText("Abro: " + title);
                Voice.speak("Vamos por " + title);
                action.run();
            }
        });
        list.addView(row, lp);
    }

    private boolean granted(String p) {
        return checkSelfPermission(p) == PackageManager.PERMISSION_GRANTED;
    }

    private void ask(String[] ps, int code) {
        requestPermissions(ps, code);
    }

    private void askAll() {
        List<String> need = new ArrayList<>();
        if (!granted(Manifest.permission.RECORD_AUDIO)) need.add(Manifest.permission.RECORD_AUDIO);
        if (Build.VERSION.SDK_INT >= 33) {
            if (!granted(Manifest.permission.READ_MEDIA_AUDIO)) need.add(Manifest.permission.READ_MEDIA_AUDIO);
            if (!granted(Manifest.permission.POST_NOTIFICATIONS)) need.add(Manifest.permission.POST_NOTIFICATIONS);
        } else if (!granted(Manifest.permission.READ_EXTERNAL_STORAGE)) {
            need.add(Manifest.permission.READ_EXTERNAL_STORAGE);
        }
        if (need.isEmpty()) {
            line.setText("Los de un toque ya están. Revisa Centro AKARI, launcher, bloqueo y batería.");
            Voice.speak("Los permisos rápidos ya los tengo. Revisa Centro Akari y los otros atajos si ves un círculo vacío.");
            return;
        }
        requestPermissions(need.toArray(new String[0]), 10);
    }

    @Override
    public void onRequestPermissionsResult(int c, String[] p, int[] g) {
        super.onRequestPermissionsResult(c, p, g);
        render();
        boolean ok = true;
        for (int x : g) if (x != PackageManager.PERMISSION_GRANTED) ok = false;
        Voice.speak(ok ? "Gracias. Ya puedo usar eso." : "Algo quedó denegado. Toca la fila otra vez o entra a la ficha.");
    }

    private boolean isDefaultHome() {
        Intent i = new Intent(Intent.ACTION_MAIN);
        i.addCategory(Intent.CATEGORY_HOME);
        android.content.pm.ResolveInfo ri = getPackageManager().resolveActivity(i, PackageManager.MATCH_DEFAULT_ONLY);
        return ri != null && getPackageName().equals(ri.activityInfo.packageName);
    }

    private boolean isAdmin() {
        DevicePolicyManager dpm = (DevicePolicyManager) getSystemService(DEVICE_POLICY_SERVICE);
        return dpm != null && dpm.isAdminActive(new ComponentName(this, AkariAdmin.class));
    }

    private boolean isUnrestrictedBattery() {
        if (Build.VERSION.SDK_INT < 23) return true;
        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        return pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
    }

    private boolean canExactAlarm() {
        if (Build.VERSION.SDK_INT < 31) return true;
        AlarmManager alarms = (AlarmManager) getSystemService(ALARM_SERVICE);
        return alarms != null && alarms.canScheduleExactAlarms();
    }

    private void openExactAlarm() {
        if (Build.VERSION.SDK_INT < 31) return;
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                    Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception ignored) {
            openAppDetails();
        }
    }

    private void openHomePicker() {
        try {
            startActivity(new Intent(Settings.ACTION_HOME_SETTINGS));
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS));
            } catch (Exception e2) {
                openAppDetails();
            }
        }
    }

    private void openAdmin() {
        Intent i = new Intent(DevicePolicyManager.ACTION_ADD_DEVICE_ADMIN);
        i.putExtra(DevicePolicyManager.EXTRA_DEVICE_ADMIN, new ComponentName(this, AkariAdmin.class));
        i.putExtra(DevicePolicyManager.EXTRA_ADD_EXPLANATION,
                "AKARI solo usa esto para bloquear la pantalla cuando se lo pides.");
        startActivity(i);
    }

    private void openBattery() {
        try {
            Intent i = new Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS);
            i.setData(Uri.parse("package:" + getPackageName()));
            startActivity(i);
        } catch (Exception e) {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception e2) {
                openAppDetails();
            }
        }
    }

    private void openAppDetails() {
        Intent i = new Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS);
        i.setData(Uri.parse("package:" + getPackageName()));
        try {
            startActivity(i);
        } catch (Exception e) {
            Toast.makeText(this, "No pude abrir ajustes", Toast.LENGTH_SHORT).show();
        }
    }
}
