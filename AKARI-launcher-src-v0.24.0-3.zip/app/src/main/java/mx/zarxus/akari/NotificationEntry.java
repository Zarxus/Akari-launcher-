package mx.zarxus.akari;

import android.app.Notification;
import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Bundle;
import android.service.notification.StatusBarNotification;
import android.text.TextUtils;

/** Immutable, display-safe projection of one active Android notification. */
public final class NotificationEntry {
    public final String key;
    public final String packageName;
    public final String appName;
    public final String title;
    public final String text;
    public final String subText;
    public final String category;
    public final long postedAt;
    public final boolean clearable;
    public final boolean ongoing;
    public final boolean call;
    public final boolean message;
    public final boolean groupSummary;
    public final boolean secret;
    public final int priority;
    public final StatusBarNotification source;

    private NotificationEntry(String key, String packageName, String appName,
                              String title, String text, String subText, String category,
                              long postedAt, boolean clearable, boolean ongoing,
                              boolean call, boolean message, boolean groupSummary,
                              boolean secret, int priority, StatusBarNotification source) {
        this.key = key;
        this.packageName = packageName;
        this.appName = appName;
        this.title = title;
        this.text = text;
        this.subText = subText;
        this.category = category;
        this.postedAt = postedAt;
        this.clearable = clearable;
        this.ongoing = ongoing;
        this.call = call;
        this.message = message;
        this.groupSummary = groupSummary;
        this.secret = secret;
        this.priority = priority;
        this.source = source;
    }

    public static NotificationEntry from(Context context, StatusBarNotification sbn) {
        Notification n = sbn.getNotification();
        Bundle extras = n.extras == null ? Bundle.EMPTY : n.extras;
        String app = appLabel(context, sbn.getPackageName());
        String title = first(
                extras.getCharSequence(Notification.EXTRA_CONVERSATION_TITLE),
                extras.getCharSequence(Notification.EXTRA_TITLE),
                extras.getCharSequence(Notification.EXTRA_TITLE_BIG),
                app);
        String text = first(
                extras.getCharSequence(Notification.EXTRA_BIG_TEXT),
                extras.getCharSequence(Notification.EXTRA_TEXT),
                joinLines(extras.getCharSequenceArray(Notification.EXTRA_TEXT_LINES)),
                extras.getCharSequence(Notification.EXTRA_SUMMARY_TEXT),
                "");
        String sub = first(
                extras.getCharSequence(Notification.EXTRA_SUB_TEXT),
                extras.getCharSequence(Notification.EXTRA_INFO_TEXT),
                "");
        String category = n.category == null ? "" : n.category;
        boolean isCall = Notification.CATEGORY_CALL.equals(category);
        boolean isMessage = Notification.CATEGORY_MESSAGE.equals(category)
                || extras.containsKey(Notification.EXTRA_MESSAGES)
                || extras.containsKey(Notification.EXTRA_CONVERSATION_TITLE);
        boolean summary = (n.flags & Notification.FLAG_GROUP_SUMMARY) != 0;
        boolean ongoing = (n.flags & Notification.FLAG_ONGOING_EVENT) != 0;
        boolean secret = n.visibility == Notification.VISIBILITY_SECRET;
        return new NotificationEntry(
                sbn.getKey(), sbn.getPackageName(), app,
                compact(title, 160), compact(text, 520), compact(sub, 160), category,
                sbn.getPostTime(), sbn.isClearable(), ongoing,
                isCall, isMessage, summary, secret, n.priority, sbn);
    }

    public Notification.Action[] actions() {
        Notification n = source == null ? null : source.getNotification();
        return n == null || n.actions == null ? new Notification.Action[0] : n.actions;
    }

    public boolean hasContentIntent() {
        return source != null && source.getNotification() != null
                && source.getNotification().contentIntent != null;
    }

    public boolean isPriority() {
        return call || message || priority >= Notification.PRIORITY_HIGH;
    }

    public String kind() {
        if (call) return "call";
        if (message || isChatApp()) return "message";
        return "notification";
    }

    public boolean isChatApp() {
        String p = packageName == null ? "" : packageName.toLowerCase();
        return p.contains("whatsapp") || p.contains("telegram") || p.contains("org.thoughtcrime.securesms")
                || p.contains("facebook.orca") || p.contains("facebook.mlite")
                || p.contains("instagram") || p.contains("sms") || p.contains("messaging")
                || p.contains("kik") || p.contains("discord") || p.contains("snapchat")
                || p.contains("viber") || p.contains("line.android");
    }

    public String speakable() {
        String who = title == null || title.isEmpty() ? appName : title;
        String body = text == null ? "" : text;
        if (call) return "Llamada de " + who;
        if (body.isEmpty()) return who + " te escribió. Sin texto en el aviso.";
        return who + " dice: " + body;
    }

    private static String appLabel(Context context, String pkg) {
        try {
            PackageManager pm = context.getPackageManager();
            ApplicationInfo ai = pm.getApplicationInfo(pkg, 0);
            CharSequence label = pm.getApplicationLabel(ai);
            return label == null ? pkg : label.toString();
        } catch (Exception ignored) {
            return pkg;
        }
    }

    private static String first(CharSequence... values) {
        for (CharSequence value : values) {
            if (!TextUtils.isEmpty(value)) return value.toString().trim();
        }
        return "";
    }

    private static String joinLines(CharSequence[] lines) {
        if (lines == null || lines.length == 0) return "";
        StringBuilder out = new StringBuilder();
        int n = Math.min(lines.length, 4);
        for (int i = 0; i < n; i++) {
            if (TextUtils.isEmpty(lines[i])) continue;
            if (out.length() > 0) out.append(" · ");
            out.append(lines[i]);
        }
        return out.toString();
    }

    private static String compact(String value, int max) {
        if (value == null) return "";
        String clean = value.replace('\n', ' ').replaceAll("\\s+", " ").trim();
        return clean.length() <= max ? clean : clean.substring(0, Math.max(0, max - 1)) + "…";
    }
}
