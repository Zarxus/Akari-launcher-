package mx.zarxus.akari;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.TimeZone;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class NewsItem {
    public final String title;
    public final String link;
    public final String source;
    public final String pubDate;

    public NewsItem(String title, String link, String source, String pubDate) {
        this.title = title;
        this.link = link;
        this.source = source;
        this.pubDate = pubDate;
    }

    public String ageLabel() {
        try {
            SimpleDateFormat parser = new SimpleDateFormat("EEE, dd MMM yyyy HH:mm:ss z", Locale.US);
            Date date = parser.parse(pubDate);
            if (date == null) return "reciente";
            long minutes = Math.max(0, (System.currentTimeMillis() - date.getTime()) / 60000L);
            if (minutes < 2) return "ahora";
            if (minutes < 60) return "hace " + minutes + " min";
            long hours = minutes / 60;
            if (hours < 24) return "hace " + hours + " h";
            return "hace " + (hours / 24) + " d";
        } catch (Exception ignored) {
            return "reciente";
        }
    }

    public static List<NewsItem> parseRss(String xml) {
        List<NewsItem> out = new ArrayList<>();
        if (xml == null) return out;
        Pattern item = Pattern.compile("<item(?:\\s[^>]*)?>([\\s\\S]*?)</item>", Pattern.CASE_INSENSITIVE);
        Pattern title = Pattern.compile("<title><!\\[CDATA\\[([\\s\\S]*?)\\]\\]></title>|<title>([\\s\\S]*?)</title>", Pattern.CASE_INSENSITIVE);
        Pattern link = Pattern.compile("<link><!\\[CDATA\\[([\\s\\S]*?)\\]\\]></link>|<link>([\\s\\S]*?)</link>", Pattern.CASE_INSENSITIVE);
        Pattern source = Pattern.compile("<source(?:\\s[^>]*)?>(?:<!\\[CDATA\\[)?([\\s\\S]*?)(?:\\]\\]>)?</source>", Pattern.CASE_INSENSITIVE);
        Pattern date = Pattern.compile("<pubDate>([\\s\\S]*?)</pubDate>", Pattern.CASE_INSENSITIVE);
        Matcher matcher = item.matcher(xml);
        while (matcher.find() && out.size() < 30) {
            String block = matcher.group(1);
            String text = clean(first(title, block));
            String url = clean(first(link, block));
            String publisher = clean(first(source, block));
            String when = clean(first(date, block));
            if (text.isEmpty()) continue;
            if (publisher.isEmpty()) {
                int dash = text.lastIndexOf(" - ");
                if (dash > text.length() / 2) {
                    publisher = text.substring(dash + 3).trim();
                    text = text.substring(0, dash).trim();
                }
            }
            out.add(new NewsItem(text, url, publisher.isEmpty() ? "Fuente enlazada" : publisher, when));
        }
        return out;
    }

    private static String first(Pattern pattern, String source) {
        Matcher matcher = pattern.matcher(source);
        if (!matcher.find()) return "";
        for (int i = 1; i <= matcher.groupCount(); i++) {
            String value = matcher.group(i);
            if (value != null && !value.trim().isEmpty()) return value.trim();
        }
        return "";
    }

    private static String clean(String text) {
        if (text == null) return "";
        return text.replace("&amp;", "&").replace("&quot;", "\"")
                .replace("&#39;", "'").replace("&#039;", "'")
                .replace("&lt;", "<").replace("&gt;", ">")
                .replaceAll("<[^>]+>", "").trim();
    }
}
