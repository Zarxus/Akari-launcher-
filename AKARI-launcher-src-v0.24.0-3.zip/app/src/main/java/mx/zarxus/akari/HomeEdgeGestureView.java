package mx.zarxus.akari;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.VelocityTracker;
import android.view.View;

/**
 * Direct-manipulation controller for the four HOME layers.
 *
 * It deliberately accepts a gesture only when it begins on an exposed edge. All
 * other touches fall through to the launcher or to the controls inside an open
 * layer. This makes a layer feel attached to the glass instead of behaving like
 * a modal dialog.
 */
public final class HomeEdgeGestureView extends View {
    public static final int NONE = 0;
    public static final int LEFT_APPS = 1;
    public static final int RIGHT_AKARI = 2;
    public static final int TOP_SIGNAL = 3;
    public static final int BOTTOM_TOOLS = 4;

    public interface Listener {
        void onBegin(int edge);
        void onProgress(int edge, float progress);
        void onRelease(int edge, float progress, float velocityAlong, boolean open);
    }

    private final Paint line = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint text = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF pill = new RectF();
    private final float density;
    private Listener listener;
    private VelocityTracker velocity;
    private int openEdge = NONE;
    private int dragEdge = NONE;
    private float progress;
    private float downX;
    private float downY;
    private float startProgress;
    private boolean dragging;
    private boolean enabledForLayers = true;

    public HomeEdgeGestureView(Context context, AttributeSet attrs) {
        super(context, attrs);
        density = getResources().getDisplayMetrics().density;
        setWillNotDraw(false);
        setFocusable(true);
        setContentDescription("Ventanas de AKARI. Jala un borde: izquierda aplicaciones, derecha AKARI, arriba avisos y abajo herramientas.");
        line.setStrokeWidth(dp(1.35f));
        text.setTextSize(dp(8.5f));
        text.setLetterSpacing(.11f);
        text.setTextAlign(Paint.Align.CENTER);
    }

    public void setListener(Listener listener) {
        this.listener = listener;
    }

    public void setLayersEnabled(boolean enabled) {
        enabledForLayers = enabled;
        if (!enabled && dragging) cancelDrag();
        setVisibility(enabled ? VISIBLE : INVISIBLE);
    }

    public void setState(int edge, float value) {
        openEdge = edge;
        progress = clamp(value);
        invalidate();
    }

    public int getOpenEdge() {
        return openEdge;
    }

    public float getProgress() {
        return progress;
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (!enabledForLayers || event == null) return false;
        final int action = event.getActionMasked();
        if (action == MotionEvent.ACTION_DOWN) {
            dragEdge = edgeForDown(event.getX(), event.getY());
            if (dragEdge == NONE) return false;
            dragging = true;
            downX = event.getX();
            downY = event.getY();
            startProgress = openEdge == dragEdge ? progress : 0f;
            if (velocity != null) velocity.recycle();
            velocity = VelocityTracker.obtain();
            velocity.addMovement(event);
            if (listener != null) listener.onBegin(dragEdge);
            getParent().requestDisallowInterceptTouchEvent(true);
            return true;
        }
        if (!dragging || dragEdge == NONE) return false;
        if (velocity != null) velocity.addMovement(event);
        if (action == MotionEvent.ACTION_MOVE) {
            float next = calculateProgress(event.getX(), event.getY());
            progress = next;
            if (listener != null) listener.onProgress(dragEdge, next);
            invalidate();
            return true;
        }
        if (action == MotionEvent.ACTION_UP || action == MotionEvent.ACTION_CANCEL) {
            float next = calculateProgress(event.getX(), event.getY());
            float along = 0f;
            if (velocity != null) {
                velocity.computeCurrentVelocity(1000);
                if (dragEdge == LEFT_APPS) along = velocity.getXVelocity();
                else if (dragEdge == RIGHT_AKARI) along = -velocity.getXVelocity();
                else if (dragEdge == TOP_SIGNAL) along = velocity.getYVelocity();
                else if (dragEdge == BOTTOM_TOOLS) along = -velocity.getYVelocity();
            }
            float size = (dragEdge == LEFT_APPS || dragEdge == RIGHT_AKARI)
                    ? Math.max(1f, getWidth()) : Math.max(1f, getHeight());
            boolean shouldOpen = action != MotionEvent.ACTION_CANCEL
                    && LayerMotion.shouldOpen(next, along, size);
            int releasedEdge = dragEdge;
            progress = next;
            recycleVelocity();
            dragging = false;
            dragEdge = NONE;
            if (listener != null) listener.onRelease(releasedEdge, next, along, shouldOpen);
            performClick();
            invalidate();
            return true;
        }
        return true;
    }

    @Override
    public boolean performClick() {
        super.performClick();
        return true;
    }

    private int edgeForDown(float x, float y) {
        float openSlop = dp(30f);
        float closeSlop = dp(24f);
        if (openEdge != NONE && progress > .01f) {
            float seam;
            if (openEdge == LEFT_APPS) {
                seam = getWidth() * progress;
                if (Math.abs(x - seam) <= closeSlop) return openEdge;
            } else if (openEdge == RIGHT_AKARI) {
                seam = getWidth() * (1f - progress);
                if (Math.abs(x - seam) <= closeSlop) return openEdge;
            } else if (openEdge == TOP_SIGNAL) {
                seam = getHeight() * progress;
                if (Math.abs(y - seam) <= closeSlop) return openEdge;
            } else if (openEdge == BOTTOM_TOOLS) {
                seam = getHeight() * (1f - progress);
                if (Math.abs(y - seam) <= closeSlop) return openEdge;
            }
            return NONE;
        }
        // Prefer the shortest distance at corners so the gesture is deterministic.
        float left = x;
        float right = getWidth() - x;
        float top = y;
        float bottom = getHeight() - y;
        float best = openSlop + 1f;
        int edge = NONE;
        if (left <= openSlop && left < best) { best = left; edge = LEFT_APPS; }
        if (right <= openSlop && right < best) { best = right; edge = RIGHT_AKARI; }
        if (top <= openSlop && top < best) { best = top; edge = TOP_SIGNAL; }
        if (bottom <= openSlop && bottom < best) edge = BOTTOM_TOOLS;
        return edge;
    }

    private float calculateProgress(float x, float y) {
        return LayerMotion.progress(dragEdge, startProgress, x - downX, y - downY,
                getWidth(), getHeight());
    }

    private void cancelDrag() {
        recycleVelocity();
        dragging = false;
        dragEdge = NONE;
    }

    private void recycleVelocity() {
        if (velocity != null) velocity.recycle();
        velocity = null;
    }

    @Override
    protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (!enabledForLayers || getWidth() <= 0 || getHeight() <= 0) return;
        int cyan = 0xD92EF0FF;
        int magenta = 0xD9FF2ED9;
        if (openEdge == NONE || progress <= .01f) {
            drawVerticalHandle(canvas, true, "APPS  ›", cyan);
            drawVerticalHandle(canvas, false, "‹  AKARI", magenta);
            drawHorizontalHandle(canvas, true, "AVISOS  ↓", cyan);
            drawHorizontalHandle(canvas, false, "↑  CONTROL", magenta);
        } else {
            if (openEdge == LEFT_APPS) drawVerticalHandleAt(canvas, getWidth() * progress, false, "‹  JALA", cyan);
            else if (openEdge == RIGHT_AKARI) drawVerticalHandleAt(canvas, getWidth() * (1f - progress), true, "JALA  ›", magenta);
            else if (openEdge == TOP_SIGNAL) drawHorizontalHandleAt(canvas, getHeight() * progress, false, "↑  JALA", cyan);
            else drawHorizontalHandleAt(canvas, getHeight() * (1f - progress), true, "JALA  ↓", magenta);
        }
    }

    private void drawVerticalHandle(Canvas canvas, boolean leftSide, String label, int color) {
        drawVerticalHandleAt(canvas, leftSide ? dp(6f) : getWidth() - dp(6f), leftSide, label, color);
    }

    private void drawVerticalHandleAt(Canvas canvas, float position, boolean leftSide, String label, int color) {
        float w = dp(22f);
        float h = dp(96f);
        float cx = Math.max(0f, Math.min(getWidth(), position));
        float cy = getHeight() * .52f;
        pill.set(cx - w * .5f, cy - h * .5f, cx + w * .5f, cy + h * .5f);
        line.setColor(color & 0x55FFFFFF);
        line.setStyle(Paint.Style.FILL);
        canvas.drawRoundRect(pill, dp(11f), dp(11f), line);
        line.setColor(color);
        line.setStyle(Paint.Style.STROKE);
        canvas.drawLine(cx, cy - dp(25f), cx, cy + dp(25f), line);
        text.setColor(color);
        canvas.save();
        canvas.rotate(leftSide ? -90f : 90f, cx, cy);
        canvas.drawText(label, cx, cy + dp(3f), text);
        canvas.restore();
    }

    private void drawHorizontalHandle(Canvas canvas, boolean topSide, String label, int color) {
        drawHorizontalHandleAt(canvas, topSide ? dp(6f) : getHeight() - dp(6f), topSide, label, color);
    }

    private void drawHorizontalHandleAt(Canvas canvas, float position, boolean topSide, String label, int color) {
        float w = dp(112f);
        float h = dp(21f);
        float cx = getWidth() * .5f;
        float cy = Math.max(0f, Math.min(getHeight(), position));
        pill.set(cx - w * .5f, cy - h * .5f, cx + w * .5f, cy + h * .5f);
        line.setColor(color & 0x55FFFFFF);
        line.setStyle(Paint.Style.FILL);
        canvas.drawRoundRect(pill, dp(11f), dp(11f), line);
        text.setColor(color);
        canvas.drawText(label, cx, cy + dp(3f), text);
    }

    private float dp(float value) {
        return value * density;
    }

    private static float clamp(float value) {
        return Math.max(0f, Math.min(1f, value));
    }
}
