package mx.zarxus.akari;

import android.content.Context;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.PorterDuff;
import android.graphics.PorterDuffColorFilter;
import android.graphics.RectF;
import android.os.Handler;
import android.os.Looper;
import android.util.AttributeSet;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;
import android.view.View;

/**
 * Full-screen, single-sprite AKARI puppet. The bitmap never changes: breathing,
 * sway, touch deformation, spring inertia and device tilt are generated here.
 */
public class AkariAvatarView extends View {
    public enum Zone { HEAD, CHEST, WAIST, LEGS }
    public enum Gesture { LEFT, RIGHT, UP, DOWN }

    public interface Listener {
        void onBodyTouch(Zone zone, float normalizedY, boolean hold);
        void onGesture(Gesture gesture);
        void onDoubleTap();
        void onScale(float scale);
    }

    private static final int COLS = 8;
    private static final int ROWS = 14;
    private static final float SPRING_K = 45f;
    private static final float SPRING_C = 9.5f;
    private static Bitmap sharedAvatar;

    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint glow = new Paint(Paint.ANTI_ALIAS_FLAG | Paint.FILTER_BITMAP_FLAG);
    private final Paint ring = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final RectF bodyRect = new RectF();
    private final float[] mesh = new float[(COLS + 1) * (ROWS + 1) * 2];
    private final Handler handler = new Handler(Looper.getMainLooper());
    private final ScaleGestureDetector scaleDetector;
    private final Bitmap avatar;

    private Listener listener;
    private float phase;
    private float heat;
    private float bond;
    private float userScale = 1f;
    private float offsetX;
    private float offsetY;
    private float velocityX;
    private float velocityY;
    private float squashX = 1f;
    private float squashY = 1f;
    private float tiltX;
    private float tiltY;
    private float targetTiltX;
    private float targetTiltY;
    private float touchPulse;
    private float touchNy = .46f;
    private float lastTouchX;
    private float lastTouchY;
    private float downX;
    private float downY;
    private float previousX;
    private float previousY;
    private long previousEventAt;
    private long downAt;
    private long lastTapAt;
    private long lastFrameNs;
    private boolean touching;
    private boolean moved;
    private boolean holdFired;
    private boolean running;
    private boolean portalActive;
    private int portalStyle;
    private int poseMode = 1;
    private Zone activeZone = Zone.CHEST;

    private static final int[] PORTAL_ACCENTS = {
            0xFF2EF0FF, 0xFFFF2ED9, 0xFFFFC857, 0xFFFF496C
    };

    private final Runnable holdRunnable = new Runnable() {
        @Override public void run() {
            if (!touching || moved || holdFired) return;
            holdFired = true;
            touchPulse = 1f;
            squashX = 1.045f;
            squashY = .955f;
            if (listener != null) listener.onBodyTouch(activeZone, touchNy, true);
            invalidate();
        }
    };

    public AkariAvatarView(Context context) { this(context, null); }

    public AkariAvatarView(Context context, AttributeSet attrs) {
        super(context, attrs);
        avatar = loadAvatar();
        glow.setColorFilter(new PorterDuffColorFilter(0xFFFF2ED9, PorterDuff.Mode.SRC_ATOP));
        ring.setStyle(Paint.Style.STROKE);
        ring.setStrokeWidth(dp(1.4f));
        setWillNotDraw(false);
        setClickable(true);
        setFocusable(true);
        setContentDescription("AKARI de cuerpo completo. Toca, mantén, arrastra o desliza para interactuar.");
        userScale = Prefs.avatarScale();
        scaleDetector = new ScaleGestureDetector(context, new ScaleGestureDetector.SimpleOnScaleGestureListener() {
            @Override public boolean onScale(ScaleGestureDetector detector) {
                userScale = clamp(userScale * detector.getScaleFactor(), .80f, 1.16f);
                touchPulse = Math.max(touchPulse, .35f);
                invalidate();
                return true;
            }

            @Override public void onScaleEnd(ScaleGestureDetector detector) {
                Prefs.setAvatarScale(userScale);
                if (listener != null) listener.onScale(userScale);
            }
        });
    }

    public void setListener(Listener value) { listener = value; }

    public void setPortalActive(boolean value) {
        if (portalActive == value) return;
        portalActive = value;
        touchPulse = 1f;
        velocityY += value ? -120f : 70f;
        squashX = value ? .94f : 1.05f;
        squashY = value ? 1.08f : .96f;
        invalidate();
    }

    public void setPortalStyle(int value) {
        portalStyle = Math.max(0, Math.min(3, value));
        glow.setColorFilter(new PorterDuffColorFilter(PORTAL_ACCENTS[portalStyle], PorterDuff.Mode.SRC_ATOP));
        touchPulse = Math.max(touchPulse, .66f);
        invalidate();
    }

    public void setPoseMode(int value) {
        poseMode = Math.max(0, Math.min(2, value));
        jiggle();
    }

    public boolean isPortalActive() { return portalActive; }

    public void setHeat(int value) {
        heat = clamp(value / 100f, 0f, 1f);
        invalidate();
    }

    public void setBond(int value) {
        bond = clamp(value / 100f, 0f, 1f);
        invalidate();
    }

    public void setTilt(float x, float y) {
        targetTiltX = clamp(x, -1f, 1f);
        targetTiltY = clamp(y, -1f, 1f);
    }

    public void jiggle() {
        float motion = Prefs.motionScale();
        impulse((float) (Math.random() * 120f - 60f), -95f);
        squashX = 1f - .08f * motion;
        squashY = 1f + .08f * motion;
        touchPulse = 1f;
        invalidate();
    }

    public void squash() {
        float motion = Prefs.motionScale();
        squashX = 1f + .09f * motion;
        squashY = 1f - .12f * motion;
        touchPulse = Math.max(touchPulse, .75f);
        invalidate();
    }

    public void impulse(float x, float y) {
        float motion = Prefs.motionScale();
        velocityX += x * motion;
        velocityY += y * motion;
        invalidate();
    }

    public float getCharacterCenterX() { return bodyRect.centerX() + offsetX; }
    public float getCharacterCenterY() { return bodyRect.centerY() + offsetY; }
    public float getLastTouchX() { return lastTouchX > 0 ? lastTouchX : getCharacterCenterX(); }
    public float getLastTouchY() { return lastTouchY > 0 ? lastTouchY : getCharacterCenterY(); }

    @Override protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        running = getWindowVisibility() == VISIBLE;
        lastFrameNs = 0L;
        if (running) postInvalidateOnAnimation();
    }

    @Override protected void onDetachedFromWindow() {
        running = false;
        handler.removeCallbacks(holdRunnable);
        super.onDetachedFromWindow();
    }

    @Override protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        running = visibility == VISIBLE;
        lastFrameNs = 0L;
        if (running) postInvalidateOnAnimation();
    }

    @Override protected void onDraw(Canvas canvas) {
        super.onDraw(canvas);
        if (avatar == null || getWidth() <= 0 || getHeight() <= 0) return;

        long now = System.nanoTime();
        float dt = lastFrameNs == 0L ? .016f : (now - lastFrameNs) / 1_000_000_000f;
        lastFrameNs = now;
        dt = clamp(dt, .001f, .045f);
        update(dt);
        buildMesh();

        float pivotX = bodyRect.centerX();
        float pivotY = bodyRect.bottom - bodyRect.height() * .035f;
        canvas.save();
        canvas.translate(offsetX + tiltX * dp(6f), offsetY + tiltY * dp(3f));
        canvas.scale(userScale, userScale, pivotX, pivotY);
        float rotation = clamp(offsetX * .018f + tiltX * 2.7f, -8.5f, 8.5f);
        canvas.rotate(rotation, pivotX, pivotY);
        canvas.scale(squashX, squashY, pivotX, pivotY);

        int portalAccent = PORTAL_ACCENTS[portalStyle];
        if (portalActive || heat > .24f || touchPulse > .08f) {
            glow.setColorFilter(new PorterDuffColorFilter(
                    portalActive ? portalAccent : 0xFFFF2ED9, PorterDuff.Mode.SRC_ATOP));
            glow.setAlpha((int) (22 + heat * 42 + touchPulse * 34 + (portalActive ? 22 : 0)));
            canvas.save();
            canvas.translate(-dp(2.2f), 0f);
            canvas.drawBitmapMesh(avatar, COLS, ROWS, mesh, 0, null, 0, glow);
            canvas.restore();
            glow.setColorFilter(new PorterDuffColorFilter(0xFF2EF0FF, PorterDuff.Mode.SRC_ATOP));
            glow.setAlpha((int) (14 + bond * 34));
            canvas.save();
            canvas.translate(dp(2.2f), 0f);
            canvas.drawBitmapMesh(avatar, COLS, ROWS, mesh, 0, null, 0, glow);
            canvas.restore();
            glow.setColorFilter(new PorterDuffColorFilter(
                    portalActive ? portalAccent : 0xFFFF2ED9, PorterDuff.Mode.SRC_ATOP));
        }
        paint.setAlpha(255);
        canvas.drawBitmapMesh(avatar, COLS, ROWS, mesh, 0, null, 0, paint);
        canvas.restore();

        if (touchPulse > .02f) {
            int alpha = (int) (115 * touchPulse);
            int ringColor = portalActive ? portalAccent
                    : Color.rgb(heat > .55f ? 255 : 46, heat > .55f ? 46 : 240, 255);
            ring.setColor((alpha << 24) | (ringColor & 0x00FFFFFF));
            float radius = dp(18f + (1f - touchPulse) * 42f);
            canvas.drawCircle(getLastTouchX(), getLastTouchY(), radius, ring);
        }

        if (running && isShown()) {
            if (Prefs.motionLevel() == 0) postInvalidateDelayed(32L);
            else postInvalidateOnAnimation();
        }
    }

    private void update(float dt) {
        boolean physics = Prefs.physics();
        if (physics) phase += dt;
        else phase = 0f;

        if (!touching) {
            velocityX += (-SPRING_K * offsetX - SPRING_C * velocityX) * dt;
            velocityY += (-SPRING_K * offsetY - SPRING_C * velocityY) * dt;
            offsetX += velocityX * dt;
            offsetY += velocityY * dt;
        }
        if (!physics) {
            offsetX *= .82f;
            offsetY *= .82f;
            velocityX *= .65f;
            velocityY *= .65f;
            targetTiltX = targetTiltY = 0f;
        }
        tiltX += (targetTiltX - tiltX) * Math.min(1f, dt * 8f);
        tiltY += (targetTiltY - tiltY) * Math.min(1f, dt * 8f);
        squashX += (1f - squashX) * Math.min(1f, dt * 8.5f);
        squashY += (1f - squashY) * Math.min(1f, dt * 8.5f);
        touchPulse = Math.max(0f, touchPulse - dt * 1.7f);
    }

    private void buildMesh() {
        float w = getWidth();
        float h = getHeight();
        float portalScale = portalActive ? (poseMode == 0 ? 1.04f : poseMode == 1 ? 1.13f : 1.09f) : 1f;
        float scale = Math.min((w * 1.08f) / avatar.getWidth(), (h * .86f) / avatar.getHeight()) * portalScale;
        float dw = avatar.getWidth() * scale;
        float dh = avatar.getHeight() * scale;
        float left = (w - dw) * .5f;
        float top = h * (portalActive ? .095f : .17f);
        float floor = portalActive ? .985f : .94f;
        if (top + dh > h * floor) top = h * floor - dh;
        bodyRect.set(left, top, left + dw, top + dh);

        float motion = Prefs.motionScale();
        float portalMotion = portalActive ? (poseMode == 0 ? .76f : poseMode == 1 ? 1.38f : 1.08f) : 1f;
        float breathe = Prefs.physics() ? (float) Math.sin(phase * 2.15f) * motion * portalMotion : 0f;
        float sway = Prefs.physics() ? (float) Math.sin(phase * .82f) * motion * portalMotion : 0f;
        float hip = Prefs.physics() ? (float) Math.sin(phase * 1.08f + .8f) * motion * portalMotion : 0f;
        float poseLean = portalActive ? (poseMode == 0 ? -.6f : poseMode == 1 ? 1f : .25f) : 0f;
        int p = 0;
        for (int row = 0; row <= ROWS; row++) {
            float v = row / (float) ROWS;
            float chestMask = gaussian(v, .31f, .115f);
            float hipMask = gaussian(v, .54f, .13f);
            float headMask = gaussian(v, .12f, .15f);
            for (int col = 0; col <= COLS; col++) {
                float u = col / (float) COLS;
                float edge = (u - .5f) * 2f;
                float x = bodyRect.left + u * bodyRect.width();
                float y = bodyRect.top + v * bodyRect.height();
                if (portalActive) {
                    x += poseLean * dp(5.2f) * (1f - v);
                    x += edge * dp(poseMode == 1 ? 3.2f : 1.2f) * hipMask;
                    y -= dp(poseMode == 2 ? 2.6f : 1.2f) * headMask;
                }
                x += sway * dp(5.5f + heat * 4f) * (1f - v);
                x += hip * dp(2.8f) * hipMask;
                x += edge * breathe * dp(2.4f + heat * 3.8f) * chestMask;
                x += targetTiltX * dp(3.2f) * headMask;
                y -= Math.abs(breathe) * dp(1.7f) * chestMask;
                if (touching || touchPulse > .02f) {
                    float touchMask = gaussian(v, touchNy, .095f + touchPulse * .055f);
                    x += edge * dp(3.5f) * touchPulse * touchMask;
                    y += (v - touchNy) * dp(6f) * touchPulse * touchMask;
                }
                mesh[p++] = x;
                mesh[p++] = y;
            }
        }
    }

    @Override public boolean onTouchEvent(MotionEvent event) {
        scaleDetector.onTouchEvent(event);
        switch (event.getActionMasked()) {
            case MotionEvent.ACTION_DOWN:
                if (!hitCharacter(event.getX(), event.getY())) return false;
                touching = true;
                moved = false;
                holdFired = false;
                downAt = event.getEventTime();
                previousEventAt = downAt;
                downX = previousX = lastTouchX = event.getX();
                downY = previousY = lastTouchY = event.getY();
                touchNy = normalizedY(event.getY());
                activeZone = zoneFor(touchNy);
                velocityX = velocityY = 0f;
                squashX = 1.035f;
                squashY = .965f;
                touchPulse = .55f;
                handler.removeCallbacks(holdRunnable);
                handler.postDelayed(holdRunnable, 520L);
                getParent().requestDisallowInterceptTouchEvent(true);
                invalidate();
                return true;
            case MotionEvent.ACTION_POINTER_DOWN:
            case MotionEvent.ACTION_POINTER_UP:
                return touching;
            case MotionEvent.ACTION_MOVE:
                if (!touching) return false;
                float x = event.getX();
                float y = event.getY();
                float dx = x - previousX;
                float dy = y - previousY;
                long elapsed = Math.max(1L, event.getEventTime() - previousEventAt);
                velocityX = velocityX * .55f + dx * 1000f / elapsed * .45f;
                velocityY = velocityY * .55f + dy * 1000f / elapsed * .45f;
                if (!scaleDetector.isInProgress()) {
                    offsetX = clamp(offsetX + dx * .78f, -getWidth() * .19f, getWidth() * .19f);
                    offsetY = clamp(offsetY + dy * .62f, -getHeight() * .10f, getHeight() * .13f);
                }
                previousX = lastTouchX = x;
                previousY = lastTouchY = y;
                previousEventAt = event.getEventTime();
                if (Math.hypot(x - downX, y - downY) > dp(12f)) {
                    moved = true;
                    handler.removeCallbacks(holdRunnable);
                }
                touchNy = normalizedY(y);
                invalidate();
                return true;
            case MotionEvent.ACTION_CANCEL:
            case MotionEvent.ACTION_UP:
                if (!touching) return false;
                touching = false;
                handler.removeCallbacks(holdRunnable);
                getParent().requestDisallowInterceptTouchEvent(false);
                float totalX = event.getX() - downX;
                float totalY = event.getY() - downY;
                float distance = (float) Math.hypot(totalX, totalY);
                long held = event.getEventTime() - downAt;
                velocityX = clamp(velocityX, -900f, 900f);
                velocityY = clamp(velocityY, -900f, 900f);
                SoundEngine.spring();
                if (!holdFired && distance < dp(20f) && held < 520L) {
                    long gap = event.getEventTime() - lastTapAt;
                    performClick();
                    if (gap < 310L) {
                        lastTapAt = 0L;
                        if (listener != null) listener.onDoubleTap();
                    } else {
                        lastTapAt = event.getEventTime();
                        if (listener != null) listener.onBodyTouch(activeZone, touchNy, false);
                    }
                } else if (!holdFired && distance > dp(54f) && listener != null) {
                    if (Math.abs(totalX) > Math.abs(totalY)) {
                        listener.onGesture(totalX < 0 ? Gesture.LEFT : Gesture.RIGHT);
                    } else {
                        listener.onGesture(totalY < 0 ? Gesture.UP : Gesture.DOWN);
                    }
                }
                touchPulse = Math.max(touchPulse, .72f);
                invalidate();
                return true;
            default:
                return touching;
        }
    }

    @Override public boolean performClick() {
        super.performClick();
        return true;
    }

    private boolean hitCharacter(float x, float y) {
        if (avatar == null || bodyRect.isEmpty()) return false;
        float cx = bodyRect.centerX();
        float cy = bodyRect.centerY();
        float localX = (x - offsetX - cx) / userScale + cx;
        float localY = (y - offsetY - cy) / userScale + cy;
        if (!bodyRect.contains(localX, localY)) return false;
        int px = (int) ((localX - bodyRect.left) / bodyRect.width() * (avatar.getWidth() - 1));
        int py = (int) ((localY - bodyRect.top) / bodyRect.height() * (avatar.getHeight() - 1));
        px = (int) clamp(px, 0, avatar.getWidth() - 1);
        py = (int) clamp(py, 0, avatar.getHeight() - 1);
        return Color.alpha(avatar.getPixel(px, py)) > 20;
    }

    private float normalizedY(float y) {
        return clamp((y - offsetY - bodyRect.top) / Math.max(1f, bodyRect.height()), 0f, 1f);
    }

    private Zone zoneFor(float ny) {
        if (ny < .25f) return Zone.HEAD;
        if (ny < .49f) return Zone.CHEST;
        if (ny < .69f) return Zone.WAIST;
        return Zone.LEGS;
    }

    private float gaussian(float value, float center, float width) {
        float z = (value - center) / Math.max(.001f, width);
        return (float) Math.exp(-.5f * z * z);
    }

    private float dp(float value) { return value * getResources().getDisplayMetrics().density; }

    private Bitmap loadAvatar() {
        synchronized (AkariAvatarView.class) {
            if (sharedAvatar == null || sharedAvatar.isRecycled()) {
                BitmapFactory.Options options = new BitmapFactory.Options();
                options.inPreferredConfig = Bitmap.Config.ARGB_8888;
                sharedAvatar = BitmapFactory.decodeResource(getResources(),
                        R.drawable.akari_avatar_v021, options);
            }
            return sharedAvatar;
        }
    }

    private static float clamp(float value, float min, float max) {
        return Math.max(min, Math.min(max, value));
    }
}
