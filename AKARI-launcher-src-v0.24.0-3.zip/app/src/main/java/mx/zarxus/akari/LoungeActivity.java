package mx.zarxus.akari;

import android.Manifest;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.media.MediaPlayer;
import android.media.audiofx.Visualizer;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public class LoungeActivity extends Activity {
    private final Handler h = new Handler(Looper.getMainLooper());
    private final List<Track> all = new ArrayList<>();
    private final List<Track> shown = new ArrayList<>();
    private ArrayAdapter<String> adapter;
    private MediaPlayer player;
    private Visualizer viz;
    private volatile float energy;
    private int index = -1;
    private ImageView art;
    private TextView now, mood, playBtn;
    private ProgressBar seek;
    private boolean dancing;
    private View flash;
    private float downX, downY;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (player != null && player.isPlaying()) {
                int d = player.getDuration();
                int p = player.getCurrentPosition();
                if (d > 0) seek.setProgress((int) (p * 1000f / d));
                danceFrame();
            }
            h.postDelayed(this, 80);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_lounge);

        Insets.attach(this);        Voice.init(this);
        art = findViewById(R.id.danceArt);
        now = findViewById(R.id.nowPlaying);
        mood = findViewById(R.id.moodLine);
        playBtn = findViewById(R.id.btnPlay);
        seek = findViewById(R.id.seekBar);
        flash = findViewById(R.id.danceFlash);
        findViewById(R.id.btnVolHere).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                startActivity(new android.content.Intent(LoungeActivity.this, VolumeActivity.class));
            }
        });
        art.setOnTouchListener(new View.OnTouchListener() {
            @Override public boolean onTouch(View v, android.view.MotionEvent e) {
                if (e.getAction() == android.view.MotionEvent.ACTION_DOWN) {
                    downX = e.getX();
                    downY = e.getY();
                    return true;
                }
                if (e.getAction() == android.view.MotionEvent.ACTION_UP) {
                    float dx = e.getX() - downX;
                    float dy = e.getY() - downY;
                    if (Math.abs(dx) > 80 && Math.abs(dx) > Math.abs(dy)) {
                        skip(dx < 0 ? 1 : -1);
                    } else {
                        Prefs.addHeat(2);
                        energy = Math.min(1f, energy + 0.45f);
                        mood.setText("Me tocaste al ritmo. Sigo.");
                        Voice.speak("Así, no pares.");
                        if (flash != null) flash.setBackgroundColor(0x55FF2ED9);
                    }
                    return true;
                }
                return false;
            }
        });
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { SoundEngine.back(); finish(); }
        });
        findViewById(R.id.btnPlay).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { toggle(); }
        });
        findViewById(R.id.btnPrev).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { skip(-1); }
        });
        findViewById(R.id.btnNext).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { skip(1); }
        });

        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, new ArrayList<String>());
        ListView list = findViewById(R.id.trackList);
        list.setAdapter(adapter);
        list.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override public void onItemClick(AdapterView<?> p, View v, int pos, long id) {
                playAt(pos);
            }
        });
        ((EditText) findViewById(R.id.musicSearch)).addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void onTextChanged(CharSequence s, int a, int b, int c) {}
            @Override public void afterTextChanged(Editable s) { filter(s.toString()); }
        });

        if (needPerm()) {
            requestPermissions(perms(), 91);
            mood.setText("Dame acceso a tu música descargada.");
            Voice.speak("Necesito permiso para ver lo que bajaste.");
        } else {
            boot();
        }
    }

    private boolean needPerm() {
        for (String p : perms()) {
            if (checkSelfPermission(p) != PackageManager.PERMISSION_GRANTED) return true;
        }
        return false;
    }

    private String[] perms() {
        if (Build.VERSION.SDK_INT >= 33) {
            return new String[]{Manifest.permission.READ_MEDIA_AUDIO};
        }
        return new String[]{Manifest.permission.READ_EXTERNAL_STORAGE};
    }

    @Override
    public void onRequestPermissionsResult(int c, String[] p, int[] g) {
        super.onRequestPermissionsResult(c, p, g);
        if (c == 91 && g.length > 0 && g[0] == PackageManager.PERMISSION_GRANTED) boot();
        else {
            mood.setText("Sin permiso no veo tus archivos.");
            Toast.makeText(this, "Permiso de audio denegado", Toast.LENGTH_SHORT).show();
        }
    }

    private void boot() {
        all.clear();
        all.addAll(MusicLib.load(this));
        ((TextView) findViewById(R.id.loungeCount)).setText(all.size() + " pistas");
        filter("");
        if (all.isEmpty()) {
            mood.setText("No encontré mp3/m4a en el teléfono.");
            Voice.speak("No hay música descargada que pueda leer.");
        } else {
            Voice.speak("Lounge listo. " + all.size() + " temas. Elige uno y bailo.");
        }
    }

    private void filter(String q) {
        shown.clear();
        String n = q == null ? "" : q.toLowerCase(Locale.ROOT).trim();
        List<String> labels = new ArrayList<>();
        for (Track t : all) {
            if (n.isEmpty() || t.line().toLowerCase(Locale.ROOT).contains(n)) {
                shown.add(t);
                labels.add(t.line());
            }
        }
        adapter.clear();
        adapter.addAll(labels);
        adapter.notifyDataSetChanged();
    }

    private void playAt(int shownIndex) {
        if (shownIndex < 0 || shownIndex >= shown.size()) return;
        Track t = shown.get(shownIndex);
        index = all.indexOf(t);
        start(t);
    }

    private void start(final Track t) {
        release();
        try {
            player = new MediaPlayer();
            player.setDataSource(this, t.uri);
            player.setOnPreparedListener(new MediaPlayer.OnPreparedListener() {
                @Override public void onPrepared(MediaPlayer mp) {
                    mp.start();
                    playBtn.setText("PAUSE");
                    hookViz(mp.getAudioSessionId());
                    now.setText(t.line());
                    applyMood(t);
                    dancing = true;
                }
            });
            player.setOnCompletionListener(new MediaPlayer.OnCompletionListener() {
                @Override public void onCompletion(MediaPlayer mp) { skip(1); }
            });
            player.prepareAsync();
        } catch (Exception e) {
            Voice.speak("Ese archivo no me abre.");
        }
    }

    private void hookViz(int session) {
        try {
            if (viz != null) { viz.release(); viz = null; }
            viz = new Visualizer(session);
            viz.setCaptureSize(Visualizer.getCaptureSizeRange()[0]);
            viz.setDataCaptureListener(new Visualizer.OnDataCaptureListener() {
                @Override public void onWaveFormDataCapture(Visualizer v, byte[] wf, int sr) {
                    if (wf == null || wf.length == 0) return;
                    long sum = 0;
                    for (byte b : wf) sum += Math.abs(b);
                    energy = Math.min(1f, (sum / (float) wf.length) / 80f);
                }
                @Override public void onFftDataCapture(Visualizer v, byte[] fft, int sr) {}
            }, Visualizer.getMaxCaptureRate() / 2, true, false);
            viz.setEnabled(true);
        } catch (Exception ignored) {
            energy = 0.35f;
        }
    }

    private void applyMood(Track t) {
        String m = MusicLib.mood(t, energy);
        String line = MusicLib.moodLine(m);
        mood.setText(m.toUpperCase(Locale.ROOT) + " · " + line);
        Voice.speak(line);
        if ("caliente".equals(m) || "agresiva".equals(m) || "eufórica".equals(m)) {
            Prefs.addHeat(4);
            art.setImageResource(R.drawable.cg_jacket);
        } else if ("cariñosa".equals(m) || "nocturna".equals(m)) {
            Prefs.addHeat(2);
            art.setImageResource(R.drawable.cg_face);
        } else {
            art.setImageResource(R.drawable.akari_portrait);
        }
    }

    private void danceFrame() {
        if (!dancing || art == null) return;
        float e = Math.max(0.12f, energy);
        double t = System.currentTimeMillis();
        float s = 1f + e * 0.16f;
        art.setScaleX(s + (float) Math.sin(t / 90) * e * 0.04f);
        art.setScaleY(1f + e * 0.10f);
        art.setRotation((float) Math.sin(t / (160.0 - e * 70)) * (8 + e * 14));
        art.setTranslationX((float) Math.sin(t / 210.0) * (10 + e * 18));
        art.setTranslationY((float) Math.abs(Math.sin(t / 120.0)) * -(12 + e * 22));
        if (flash != null) {
            int a = Math.min(90, (int) (e * 90));
            flash.setBackgroundColor((a << 24) | 0x00FF2ED9);
        }
    }

    private void toggle() {
        if (player == null) {
            if (!shown.isEmpty()) playAt(0);
            return;
        }
        if (player.isPlaying()) {
            player.pause();
            playBtn.setText("PLAY");
            dancing = false;
            art.setRotation(0);
            art.setScaleX(1);
            art.setScaleY(1);
            Voice.speak("Pauso. Me quedo a medio paso.");
        } else {
            player.start();
            playBtn.setText("PAUSE");
            dancing = true;
            Voice.speak("Sigo.");
        }
    }

    private void skip(int d) {
        if (all.isEmpty()) return;
        index = (Math.max(0, index) + d + all.size()) % all.size();
        // map to shown if possible
        Track t = all.get(index);
        int si = shown.indexOf(t);
        if (si >= 0) playAt(si);
        else start(t);
    }

    private void release() {
        dancing = false;
        try { if (viz != null) { viz.release(); viz = null; } } catch (Exception ignored) {}
        try { if (player != null) { player.release(); player = null; } } catch (Exception ignored) {}
    }

    @Override protected void onResume() {
        super.onResume();
        h.removeCallbacks(tick);
        h.post(tick);
    }

    @Override protected void onPause() {
        super.onPause();
        h.removeCallbacks(tick);
    }

    @Override protected void onDestroy() {
        release();
        super.onDestroy();
    }
}
