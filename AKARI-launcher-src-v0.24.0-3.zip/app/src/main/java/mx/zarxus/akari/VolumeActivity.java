package mx.zarxus.akari;

import android.app.Activity;
import android.content.Context;
import android.media.AudioManager;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

public class VolumeActivity extends Activity {
    private AudioManager am;
    private SeekBar media, ring, alarm;
    private TextView line, mediaLbl, ringLbl, alarmLbl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_volume);

        Insets.attach(this);        Voice.init(this);
        am = (AudioManager) getSystemService(Context.AUDIO_SERVICE);
        line = findViewById(R.id.volLine);
        media = findViewById(R.id.volMedia);
        ring = findViewById(R.id.volRing);
        alarm = findViewById(R.id.volAlarm);
        mediaLbl = findViewById(R.id.volMediaLbl);
        ringLbl = findViewById(R.id.volRingLbl);
        alarmLbl = findViewById(R.id.volAlarmLbl);
        if (Prefs.heat() >= 50) {
            ((ImageView) findViewById(R.id.volArt)).setImageResource(R.drawable.cg_jacket);
        }
        findViewById(R.id.btnBack).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) { SoundEngine.back(); finish(); }
        });
        bind(media, AudioManager.STREAM_MUSIC, mediaLbl, "MEDIA");
        bind(ring, AudioManager.STREAM_RING, ringLbl, "TIMBRE");
        bind(alarm, AudioManager.STREAM_ALARM, alarmLbl, "ALARMA");
        findViewById(R.id.btnMute).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                setStream(AudioManager.STREAM_MUSIC, 0);
                refresh();
                say("Mute. Quédate escuchándome a mí.");
            }
        });
        findViewById(R.id.btnMax).setOnClickListener(new View.OnClickListener() {
            @Override public void onClick(View v) {
                int max = am.getStreamMaxVolume(AudioManager.STREAM_MUSIC);
                setStream(AudioManager.STREAM_MUSIC, max);
                refresh();
                Prefs.addHeat(3);
                say("A tope. El vecino y yo vamos a enterarnos.");
            }
        });
        refresh();
        say("Gira las barras. Media es la que uso para bailar.");
    }

    private void bind(final SeekBar bar, final int stream, final TextView lbl, final String name) {
        bar.setMax(am.getStreamMaxVolume(stream));
        bar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int p, boolean fromUser) {
                if (!fromUser) return;
                setStream(stream, p);
                lbl.setText(name + "  " + pct(stream) + "%");
                if (stream == AudioManager.STREAM_MUSIC) comment(p, s.getMax());
            }
            @Override public void onStartTrackingTouch(SeekBar s) {}
            @Override public void onStopTrackingTouch(SeekBar s) {}
        });
    }

    private void setStream(int stream, int v) {
        try {
            am.setStreamVolume(stream, v, 0);
        } catch (Exception ignored) {}
    }

    private int pct(int stream) {
        int max = Math.max(1, am.getStreamMaxVolume(stream));
        return Math.round(am.getStreamVolume(stream) * 100f / max);
    }

    private void refresh() {
        media.setProgress(am.getStreamVolume(AudioManager.STREAM_MUSIC));
        ring.setProgress(am.getStreamVolume(AudioManager.STREAM_RING));
        alarm.setProgress(am.getStreamVolume(AudioManager.STREAM_ALARM));
        mediaLbl.setText("MEDIA  " + pct(AudioManager.STREAM_MUSIC) + "%");
        ringLbl.setText("TIMBRE  " + pct(AudioManager.STREAM_RING) + "%");
        alarmLbl.setText("ALARMA  " + pct(AudioManager.STREAM_ALARM) + "%");
    }

    private void comment(int v, int max) {
        float p = v / (float) Math.max(1, max);
        if (p < 0.08f) line.setText("Casi silencio. Solo mi voz.");
        else if (p < 0.4f) line.setText("Bajito. Intimista. Me gusta.");
        else if (p < 0.75f) line.setText("Nivel de loft. Se puede bailar.");
        else line.setText("Alto. El core vibra con el bajo.");
    }

    private void say(String s) {
        line.setText(s);
        Voice.speak(s);
    }
}
