package mx.zarxus.akari;

import android.app.admin.DeviceAdminReceiver;
import android.content.Context;
import android.content.Intent;

public class AkariAdmin extends DeviceAdminReceiver {
    @Override
    public void onEnabled(Context context, Intent intent) {
        Voice.speak("Ya puedo cerrar el teléfono por ti.");
    }
}
