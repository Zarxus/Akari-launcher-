package mx.zarxus.akari;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.media.AudioAttributes;
import android.net.Uri;
import android.os.Build;
import android.os.PowerManager;

/** Raises AKARI's wake screen and a supported full-screen alarm notification. */
public class AlarmReceiver extends BroadcastReceiver {
    static final String CHANNEL = "akari_wake_alarm";
    static final int NOTICE = 6020;

    @Override public void onReceive(Context c, Intent source) {
        boolean snooze = source != null && source.getBooleanExtra(AlarmScheduler.EXTRA_SNOOZE, false);
        if (!Prefs.alarmEnabled() && !snooze) return;
        Prefs.setAlarmSnoozeAt(0);
        if (Prefs.alarmEnabled()) AlarmScheduler.schedule(c);
        PowerManager.WakeLock lock = null;
        try {
            PowerManager pm = (PowerManager) c.getSystemService(Context.POWER_SERVICE);
            if (pm != null) {
                lock = pm.newWakeLock(PowerManager.PARTIAL_WAKE_LOCK, "akari:alarm");
                lock.acquire(12_000L);
            }
            show(c);
        } finally {
            if (lock != null && lock.isHeld()) lock.release();
        }
    }

    private void show(Context c) {
        Intent ring = new Intent(c, AlarmRingActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK
                | Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_SINGLE_TOP);
        PendingIntent full = PendingIntent.getActivity(c, 6030, ring,
                PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        NotificationManager nm = (NotificationManager) c.getSystemService(Context.NOTIFICATION_SERVICE);
        boolean permitted = Build.VERSION.SDK_INT < 33 || c.checkSelfPermission(
                "android.permission.POST_NOTIFICATIONS") == PackageManager.PERMISSION_GRANTED;
        if (nm != null && permitted) {
            Uri tone = Uri.parse("android.resource://" + c.getPackageName() + "/" + R.raw.sfx_alarm);
            AudioAttributes attrs = new AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_ALARM)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build();
            NotificationChannel channel = new NotificationChannel(CHANNEL, "Despertador AKARI",
                    NotificationManager.IMPORTANCE_HIGH);
            channel.setSound(tone, attrs);
            channel.enableVibration(true);
            channel.setVibrationPattern(new long[]{0, 300, 180, 500, 500});
            channel.setLockscreenVisibility(Notification.VISIBILITY_PUBLIC);
            nm.createNotificationChannel(channel);
            Notification.Builder b = new Notification.Builder(c, CHANNEL);
            b.setSmallIcon(R.mipmap.ic_launcher).setContentTitle("AKARI · " + Prefs.alarmLabel())
                    .setContentText(AkariLines.alarmRing()).setCategory(Notification.CATEGORY_ALARM)
                    .setVisibility(Notification.VISIBILITY_PUBLIC)
                    .setOngoing(true).setContentIntent(full).setFullScreenIntent(full, true);
            nm.notify(NOTICE, b.build());
        }
        try { c.startActivity(ring); } catch (Exception ignored) {}
    }
}
