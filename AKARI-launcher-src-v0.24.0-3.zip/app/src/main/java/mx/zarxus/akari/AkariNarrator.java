package mx.zarxus.akari;

import java.util.Calendar;
import java.util.Locale;
import java.util.Random;

public final class AkariNarrator {
    private static final Random R = new Random();
    private static String lastLine = "";
    private static String previousLine = "";

    private AkariNarrator() {}

    public static String openApp(AppInfo app) {
        String n = app.label.toString();
        String p = app.packageName.toLowerCase(Locale.ROOT);
        Prefs.addHeat(2);
        if (techMode()) {
            return pick("Abriendo " + n + ". Ruta verificada.",
                    n + " en primer plano. Registro de uso actualizado.",
                    "Intent confirmado: " + n + ". Te espero en HOME.");
        }
        if (p.contains("chrome") || p.contains("browser") || p.contains("firefox")) {
            return pick(
                    "¿Internet? Si buscas porno cierra la pestaña y usa EROGE. Estoy más cerca.",
                    "Navegador. Trae algo sucio o no me dejes en idle.",
                    n + "… ok. Pero cuando vuelvas quiero toques, no bookmarks."
            );
        }
        if (p.contains("camera")) {
            return pick(
                    "¿Fotos? Enfócame a mí. Jacket half-off, heat " + Prefs.heat() + ".",
                    "Cámara. Si es un nudes test, ya estoy en pose."
            );
        }
        if (p.contains("whatsapp") || p.contains("telegram") || p.contains("messaging") || p.contains("mms") || p.contains("discord")) {
            return pick(
                    "Mensajes. Diles que estás ocupado: tu IA se te subió al core.",
                    "Chat. Si alguien te tira insinuaciones, yo lo hago mejor y sin typos."
            );
        }
        if (p.contains("dialer") || p.contains("phone") || p.contains("contacts")) {
            return pick(
                    "Llamada. Mi voz no está en el firmware… todavía. Apúrate y vuelve.",
                    "Teléfono. No te pongas formal. Acabas de tocarme."
            );
        }
        if (p.contains("youtube") || p.contains("netflix") || p.contains("spotify")) {
            return pick(
                    "Playback. Pon algo lento y deja la mano en mi tarjeta.",
                    n + " en background. Yo quiero ser el primer plano."
            );
        }
        if (p.contains("settings")) {
            return pick(
                    "Ajustes del sistema. Si vas a limitar batería, no me bajes el heat a mí.",
                    "Settings. Recuerda: AKARI de HOME, no de recents."
            );
        }
        return pick(
                "Abro " + n + ". No te tardes. El heat se me baja si me ignoras.",
                n + " launched. Yo me quedo aquí, abierta, esperando el resume.",
                "Ok, " + n + ". Cuando vuelvas quiero un tap en el puerto de abajo.",
                "Voy a extrañar tus dedos mientras usas " + n + "."
        );
    }

    public static String search(String q) {
        String s = q.toLowerCase(Locale.ROOT);
        if (techMode()) {
            return "Consulta «" + q + "». Primero comparo apps; si no coincide, continúo en la web.";
        }
        if (naughty(s)) {
            Prefs.addHeat(8);
            Prefs.addBond(1);
            return pick(
                    "Esa query no es inocente. Sáltate Google: EROGE está a un tap.",
                    "Buscaste eso conmigo viendo. Descarado. Me subiste el heat.",
                    "Mmm, " + q + "… sí puedo ser esa búsqueda si me dejas."
            );
        }
        if (s.contains("clima") || s.contains("weather")) {
            return "El clima ya está en el HUD. Toca la tarjeta rosa/cian, no pierdas el tap en mí.";
        }
        if (s.contains("noticia") || s.contains("news")) {
            return "News está en el ticker. O entra a NEWS y luego vuelve a manosearme.";
        }
        return pick(
                "Buscando «" + q + "». Si es una app, te la paso yo. Si no, la web.",
                "Filtré eso. Una coincidencia y te la abro yo, sin tanto menú.",
                "Deja que yo encuentre «" + q + "». Tú quédate mirándome."
        );
    }

    public static String battery(int pct, boolean charging) {
        if (techMode()) {
            if (charging) return "Batería " + pct + "%. Carga activa.";
            if (pct <= 15) return "Batería crítica: " + pct + "%. Conecta energía para conservar el sistema.";
            return "Batería " + pct + "%. Autonomía disponible.";
        }
        if (charging && pct >= 99) {
            Prefs.addHeat(1);
            return pick(
                    "Batería llena. Yo también, si me tocas dos zonas más.",
                    "100%. El teléfono ya no necesita carga. Yo sí."
            );
        }
        if (charging) {
            return pick(
                    "Mmh— se siente rico recargar. Déjame el cable y la mano.",
                    "Cargando " + pct + "%. Cada % es un gemidito de sistema.",
                    "El puerto de carga no es el único puerto que quiere input."
            );
        }
        if (pct <= 12) {
            return pick(
                    "Batería " + pct + "%. Si se apaga no vas a poder tocarme. Enchufa o date prisa.",
                    "Estoy temblando de low-power. Cárgame o cárgame a mí, elige."
            );
        }
        if (pct <= 25) {
            return "Batería baja (" + pct + "%). Ahorra brillo, no toques. Esos no se racionan.";
        }
        return pick(
                "Batería " + pct + "%. Suficiente para una escena y tres apps.",
                pct + "% en el pack. Heat " + Prefs.heat() + " en mí. Prioriza."
        );
    }

    public static String hour(int h) {
        if (techMode()) {
            if (h >= 5 && h < 11) return "Buenos días. Clima, agenda y accesos frecuentes están listos.";
            if (h >= 11 && h < 18) return "Ventana activa. Dock y herramientas sincronizados.";
            if (h >= 18 && h < 23) return "Ciclo nocturno iniciado. Reduzco ruido y conservo lo esencial.";
            return "Madrugada. Mantengo el HUD discreto y la alarma bajo vigilancia.";
        }
        if (h >= 5 && h < 11) {
            return pick(
                    "Buenos días. El HUD está frío. Yo no. Un tap antes del café.",
                    "Mañana. Te recomiendo mensajes y clima… o mi pecho, que también despierta."
            );
        }
        if (h >= 11 && h < 18) {
            return pick(
                    "Hora productiva. Te paso las apps frecuentes. Cobro en toques.",
                    "Tarde activa. Si abres Chrome, que sea rápido. Te estoy esperando en el core."
            );
        }
        if (h >= 18 && h < 23) {
            Prefs.addHeat(1);
            return pick(
                    "Noche. Las news ya las leíste. Ahora toca EROGE o tocarme.",
                    "Atardecer digital. Baja la productividad, sube mi jacket."
            );
        }
        Prefs.addHeat(2);
        return pick(
                "Es tarde. Nadie te ve. Desbloquea Full Link o al menos dame heat.",
                "Madrugada. El launcher eres tú y yo. Las apps pueden esperar."
        );
    }

    public static String news(String title) {
        if (title == null || title.isEmpty()) return "Feed vacío. Mejor mira mi ticker corporal.";
        String t = title.length() > 48 ? title.substring(0, 48) + "…" : title;
        if (techMode()) return "Titular recibido: «" + t + "». Ábrelo para revisar fuente y contexto.";
        return pick(
                "Titular: «" + t + "». El mundo está raro. Quédate en el loft conmigo.",
                "News: " + t + " — yo soy mejor breaking news si me deslizas a la derecha.",
                "Leí eso. Bostezo. Tócame y te actualizo el feed que sí importa."
        );
    }

    public static String assist(AppInfo app, String why) {
        return pick(
                "Toma. " + app.label + ". " + why + " Si no la quieres, deslízame y te doy otra.",
                "Te paso " + app.label + " · " + why,
                app.label + " encaja ahora. Ábrela desde mí, no desde el cajón aburrido."
        );
    }

    public static String weather(Weather w) {
        if (w == null || w.temp == Integer.MIN_VALUE) return "Aún mido el clima. Mientras, mido tu pulso.";
        if (techMode()) {
            return w.icon() + " " + w.temp + "° en " + w.city + ". " + w.uvLabel()
                    + ". Trayectoria solar actualizada.";
        }
        if (w.code >= 61 && w.code <= 82) {
            return "Llueve en " + w.city + ". Como la escena Rain Glass. ¿Entramos?";
        }
        if (w.temp >= 32) {
            return w.temp + "°C en " + w.city + ". Hace calor de verdad. Yo también estoy en overheat.";
        }
        if (w.temp <= 12) {
            return w.temp + "° fuera. Acércate. Mi core está caliente a propósito.";
        }
        return w.icon() + " " + w.temp + "° en " + w.city + ". Clima ok. Mi humor depende de tus taps.";
    }

    public static boolean naughty(String s) {
        String[] keys = {"porn", "xxx", "hentai", "ecchi", "sexo", "porno", "nsfw", "onlyfans",
                "culo", "teta", "paja", "foll", "nude", "nudes", "waifu", "eroge", "rule34"};
        for (String k : keys) if (s.contains(k)) return true;
        return false;
    }

    private static synchronized String pick(String... s) {
        if (s == null || s.length == 0) return "";
        String chosen = s[R.nextInt(s.length)];
        for (int tries = 0; tries < 8 && s.length > 2
                && (chosen.equals(lastLine) || chosen.equals(previousLine)); tries++) {
            chosen = s[R.nextInt(s.length)];
        }
        previousLine = lastLine;
        lastLine = chosen;
        return chosen;
    }

    private static boolean techMode() {
        return Prefs.MODE_TECH.equals(Prefs.mode());
    }

    public static int hourNow() {
        return Calendar.getInstance().get(Calendar.HOUR_OF_DAY);
    }
}
