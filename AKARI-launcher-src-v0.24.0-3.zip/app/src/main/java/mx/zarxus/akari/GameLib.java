package mx.zarxus.akari;

import android.content.Context;
import android.content.pm.ApplicationInfo;
import android.content.pm.PackageManager;
import android.os.Build;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

public final class GameLib {
    private GameLib() {}

    public static List<AppInfo> games(Context ctx) {
        List<AppInfo> all = AppRepository.loadLaunchable(ctx);
        List<AppInfo> out = new ArrayList<>();
        PackageManager pm = ctx.getPackageManager();
        for (AppInfo a : all) {
            if (isGame(pm, a)) out.add(a);
        }
        if (out.isEmpty()) {
            // fallback: anything matching loose play terms so the window isn't dead
            for (AppInfo a : all) {
                String s = (a.packageName + " " + a.label).toLowerCase(Locale.ROOT);
                if (s.contains("play") || s.contains("game") || s.contains("juego")) out.add(a);
            }
        }
        return out;
    }

    public static boolean isGame(PackageManager pm, AppInfo a) {
        try {
            ApplicationInfo info = pm.getApplicationInfo(a.packageName, 0);
            if (Build.VERSION.SDK_INT >= 26 && info.category == ApplicationInfo.CATEGORY_GAME) {
                return true;
            }
        } catch (Exception ignored) {}
        return AppKinds.match(a, "games");
    }

    public static String why(AppInfo a, int hour) {
        String n = a.label.toString();
        if (hour >= 22 || hour < 6) {
            return n + " de madrugada. Partida corta, o me usas de drop-in.";
        }
        if (hour < 12) {
            return n + " por la mañana. Un round y vuelves al loft.";
        }
        if (hour < 18) {
            return n + " pega ahora. Si te tiltas, aquí estoy.";
        }
        return n + " de noche. Yo hago de audiencía. Y de premio si ganas.";
    }
}
