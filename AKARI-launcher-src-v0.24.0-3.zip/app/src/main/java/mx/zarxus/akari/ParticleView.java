package mx.zarxus.akari;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.util.AttributeSet;
import android.view.View;

import java.util.Random;

public class ParticleView extends View {
    private static class P {
        float x, y, vx, vy, r, life, max;
        int color;
    }

    private final P[] ps = new P[28];
    private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Random rng = new Random();
    private boolean attached;
    private boolean running;
    private final Runnable tick = new Runnable() {
        @Override public void run() {
            if (!running) return;
            invalidate();
            postDelayed(this, Prefs.liveWall() ? (Prefs.motionLevel() == 0 ? 33L : 16L) : 500L);
        }
    };

    public ParticleView(Context c) { super(c); boot(); }
    public ParticleView(Context c, AttributeSet a) { super(c, a); boot(); }

    private void boot() {
        paint.setStyle(Paint.Style.FILL);
        for (int i = 0; i < ps.length; i++) ps[i] = new P();
        setWillNotDraw(false);
    }

    private void spawn(P p, int w, int h) {
        p.x = rng.nextFloat() * w;
        p.y = rng.nextFloat() * h;
        p.vx = (rng.nextFloat() - 0.5f) * 0.35f;
        p.vy = -0.15f - rng.nextFloat() * 0.35f;
        p.r = 1.2f + rng.nextFloat() * 2.8f;
        p.max = 80 + rng.nextInt(160);
        p.life = p.max;
        p.color = rng.nextBoolean() ? 0xFFFF2ED9 : 0xFF2EF0FF;
    }

    @Override
    protected void onAttachedToWindow() {
        super.onAttachedToWindow();
        attached = true;
        syncLoop();
    }

    @Override
    protected void onDetachedFromWindow() {
        attached = false;
        running = false;
        removeCallbacks(tick);
        super.onDetachedFromWindow();
    }

    @Override protected void onWindowVisibilityChanged(int visibility) {
        super.onWindowVisibilityChanged(visibility);
        running = attached && visibility == VISIBLE;
        syncLoop();
    }

    private void syncLoop() {
        removeCallbacks(tick);
        running = attached && getWindowVisibility() == VISIBLE;
        if (running) post(tick);
    }

    public void burst(float cx, float cy) {
        int w = Math.max(1, getWidth());
        int h = Math.max(1, getHeight());
        if (cx <= 0) cx = w * 0.5f;
        if (cy <= 0) cy = h * 0.4f;
        int n = Math.min(10, ps.length);
        for (int i = 0; i < n; i++) {
            P p = ps[i];
            p.x = cx;
            p.y = cy;
            p.vx = (rng.nextFloat() - 0.5f) * 6f;
            p.vy = -1.5f - rng.nextFloat() * 4f;
            p.r = 2f + rng.nextFloat() * 3.5f;
            p.max = 40 + rng.nextInt(50);
            p.life = p.max;
            p.color = rng.nextBoolean() ? 0xFFFF2ED9 : 0xFF2EF0FF;
        }
        invalidate();
    }

    @Override
    protected void onDraw(Canvas c) {
        if (!Prefs.liveWall()) return;
        int w = getWidth();
        int h = getHeight();
        if (w == 0) return;
        float heat = Prefs.heat() / 100f;
        float motion = Prefs.motionScale();
        for (P p : ps) {
            if (p.max == 0) spawn(p, w, h);
            p.x += p.vx * (1f + heat) * motion;
            p.y += p.vy * (1f + heat * 0.6f) * motion;
            p.life -= 1f;
            if (p.life <= 0 || p.y < -8) spawn(p, w, h);
            float a = Math.max(0f, p.life / p.max) * (0.25f + heat * 0.45f);
            paint.setColor(p.color);
            paint.setAlpha((int) (a * 255));
            c.drawCircle(p.x, p.y, p.r + heat * 1.4f, paint);
        }
    }
}
