# Cambios

## 0.24.0 — VEIL

### Manipulación directa en HOME

- Cuatro ventanas nativas salen de los bordes y siguen el dedo cuadro a cuadro: APPS, AKARI, SIGNAL y CONTROL.
- Apertura parcial, proyección por velocidad, umbral háptico, retorno con inercia, rebote final e inclinación direccional.
- Indicadores visibles en los cuatro bordes y una zona opuesta dedicada a volver a jalar la ventana para cerrarla.
- Parallax independiente para cada arte personalizado y desplazamiento sutil del tablero base durante la revelación.

### Interfaces integradas

- Cajón completo de aplicaciones dentro de HOME con filtro en vivo, conteo, acciones largas y lanzamiento exclusivo del APK instalado.
- Resultados múltiples de la búsqueda de HOME se resuelven en la ventana APPS, sin saltar al cajón externo.
- Panel personalizado de AKARI con tres composiciones visuales, respuesta al toque, métricas BOND/HEAT y rutas a RIFT, escenas y galería.
- SIGNAL combina clima/UV/ciclo solar con hasta cuatro avisos que se pueden abrir o descartar.
- CONTROL reúne doce herramientas y ajustes rápidos sin presentar primero otro menú o Activity.
- Los cuatro gestos del cuerpo y las rutas de RIFT se conectan a las nuevas ventanas.

### Sonido, acceso y compatibilidad

- Sonido de arrastre cuantizado por progreso, tono por dirección y respuestas separadas para agarrar, cruzar el umbral, abrir y cerrar.
- Etiquetas y descripciones de accesibilidad para identificar cada ventana y la acción de sus bordes.
- versionCode 25, versionName 0.24.0, minSdk 26 y targetSdk 34.
- Conserva paquete, datos y certificado de las versiones 0.21–0.23.

## 0.23.0 — RIFT

### Apertura nativa corregida

- Las fichas de aplicaciones ya no consultan ni obedecen el antiguo modo `portal first`.
- La ruta primaria usa el intent de lanzamiento del paquete instalado y conserva el componente Android como respaldo.
- WhatsApp, YouTube, Telegram, Instagram y cualquier otra app abren su APK original; el sitio web solo se usa para búsquedas o enlaces elegidos expresamente.
- Ajustes separa con claridad `enlaces web dentro de AKARI` de la apertura de aplicaciones.
- El botón del navegador interno ahora se identifica como EXTERNO y no como NATIVO.

### HOME RIFT

- Segunda composición de pantalla accesible desde el tirador lateral, doble toque, voz o búsqueda.
- Apertura y cierre mediante diagonales, anillos, rejilla dinámica, pulsos y desplazamiento físico del HUD.
- Rutas táctiles en los cuatro bordes hacia vestuario, escenas adultas, aplicaciones y música.
- Deslizamiento horizontal para cambiar paleta, vertical para cambiar postura o cerrar, y centro corporal con reacciones localizadas.
- Paletas persistentes NEXUS, VIOLETA, DAWN y CRIMSON.
- Posturas físicas persistentes CALMA, PULSO y GUARDIA.

### AKARI y EROTECH

- El mismo cuerpo completo cambia escala, respiración, balance, inclinación, aura y deformación dentro del RIFT sin convertirse en un carrusel de retratos.
- Reacciones con memoria de contacto consecutivo por zona.
- EROTECH reemplaza su portada estática por la marioneta corporal viva y reutiliza gestos, estilo y postura del HOME.
- Galería con entrada escalonada y escenas con parallax reversible y transiciones físicas entre elecciones.
- Nuevas firmas de audio y vibración para apertura, cambio y cierre del portal.
- Controles de estilo y postura añadidos a Ajustes.

### Compatibilidad

- versionCode 24, versionName 0.23.0, targetSdk 34.
- Conserva package, datos y certificado de firma de v0.21/v0.22.

## 0.22.0 — REFINE

### Interfaz

- Panel inferior plegable con modo limpio predeterminado y estado persistente.
- Carril horizontal para diez herramientas, objetivos táctiles más amplios y reloj adaptable a 12/24 horas.
- Atmósfera de amanecer, día, ocaso y noche ligada al ciclo solar real cuando está disponible.
- Aviso emergente descartable por deslizamiento y transiciones comunes entre pantallas.

### Aplicaciones y búsqueda

- Vista previa silenciosa y debounced de apps desde HOME.
- Coincidencias sin acentos, por palabras, paquete y subsecuencia aproximada, ordenadas por relevancia.
- Menú unificado al mantener una app: abrir, dock, ocultar/restaurar, información y desinstalar.
- Corregida la sexta fijación del dock; sustituye la más antigua en vez de descartarse silenciosamente.
- Dock y sugerencias de primer uso ya no se llenan alfabéticamente; priorizan uso real y herramientas comunes.
- Registro temporal para que el estante RECIENTES sea realmente reciente desde esta versión.
- Estados vacíos explicativos en el cajón y respuesta visible cuando una app no puede abrirse.

### Movimiento, sonido y rendimiento

- Perfiles CALMA, EQUILIBRADA y VIBRANTE aplicados a malla corporal, dock, resortes, partículas y vibración.
- Escala corporal persistente después de pellizcar, sin reanimar el diálogo en cada fotograma del gesto.
- Controles independientes de nivel SFX y ambiente.
- Los bucles de cuerpo, partículas, scanlines y arco solar se pausan cuando la ventana deja de ser visible.
- Menor frecuencia de animación en CALMA y menor sondeo de reloj, batería y avisos.

### Datos, noticias y diálogo

- Clima protegido contra solicitudes duplicadas, con recuperación explícita desde caché sin inventar lecturas.
- Noticias con edad de caché, protección contra cargas paralelas, acción COMPARTIR visible y máximo de 30 tarjetas simultáneas.
- Corregidos falsos positivos al detectar la sigla `IA` dentro de otras palabras.
- Narración con memoria antirrepetición y tono TECH coherente en contactos, apps, batería, hora, clima y avisos.
- Eliminada la repetición automática de la última frase al volver al HOME y el habla por cada carácter escrito.

### Compatibilidad

- versionCode 23, versionName 0.22.0, targetSdk 34.
- Conserva applicationId, datos y certificado de firma de v0.21.0.

## 0.21.0 — EMBODY

### Nuevo

- AKARI de cuerpo completo sobre el wallpaper real del teléfono, sin tarjeta de retrato ni rotación de imágenes.
- Marioneta 2D de malla con respiración, sway, movimiento de cadera, reacción localizada, deformación elástica y aura ligada a HEAT/BOND.
- Interacciones por zonas con toque, pulsación sostenida, arrastre, fling, cuatro deslizamientos, pellizco y doble toque.
- Globo mínimo de diálogo que se anima y cambia de lado para despejar la interacción corporal.
- Selector de wallpaper del sistema accesible desde Ajustes.
- Instrumento SOLAR LINK con UV actual, categoría de riesgo, arco del sol, amanecer, ocaso, luz restante y cuenta regresiva hasta el día siguiente.
- VECTOR LINK: brújula animada de norte verdadero, 16 rumbos, declinación local, precisión, fijado de lectura y guía de calibración.
- Gestos de AKARI en noticias: cambiar, leer, analizar y abrir titulares directamente desde su cuerpo animado.

### Mejorado

- El sensor de inclinación ahora modifica la postura interna de la figura en vez de desplazar una imagen de fondo.
- Notificaciones, apertura de apps, reloj, batería y accesos provocan impulsos visibles en el cuerpo completo.
- Los efectos de lluvia, scanlines y partículas son una capa opcional sobre el wallpaper del propietario.
- El HOME reduce el sombreado para que el wallpaper y la silueta sigan visibles sin perder contraste del HUD.
- Las noticias destacan el titular enfocado y sincronizan gesto, diálogo, voz y física de AKARI.
- Cajón y Atelier presentan tarjetas de tres columnas, estado de dock, halo, entrada escalonada y selección visual más clara.
- Tocar, mantener y lanzar una app genera una firma sonora propia por paquete, con capas distintas según la intención.
- El bitmap corporal se comparte entre pantallas para reducir decodificaciones y memoria cuando HOME, Noticias o Brújula se alternan.

### Datos

- Clima, índice UV y ciclo solar mediante Open-Meteo, con zona horaria automática, caché local y atribución visible.
- El UV mostrado es una estimación meteorológica; la orientación depende de los sensores disponibles en el dispositivo.

### Compatibilidad

- versionCode 22, versionName 0.21.0, targetSdk 34.
- Conserva applicationId y certificado de firma para instalar sobre v0.20.0.

## 0.20.0 — DAWN

### Nuevo

- Dawn Link: despertador recurrente con escena de AKARI, etiqueta, días, volumen gradual, vibración, posponer, prueba y restauración tras reinicio.
- Flujo guiado para alarma exacta, avisos y pantalla completa en Android moderno.
- Mate Link con tres niveles, evaluación posicional, pista visual, deshacer y cálculo asíncrono.
- Core Math con precedencia, paréntesis, raíz, potencia, porcentaje, memoria, ANS e historial.
- AKARI Signal con cuatro temas, fuente, antigüedad, foco, compartir, lectura y reacción contextual.
- Seis señales sonoras nuevas y patrones hápticos semánticos.

### Mejorado

- Dock, cajón, botones, tarjetas de avisos y accesos de apps usan elevación magnética, inclinación, rebote y onda de lanzamiento.
- Movimientos y capturas del ajedrez tienen respuestas audiovisuales diferentes.
- Los diálogos evitan repeticiones recientes y responden al contexto de alarma, cálculo y noticias.
- Ajustes y Permisos muestran el estado del despertador y cada autorización por separado.

### Compatibilidad

- versionCode 21, versionName 0.20.0, targetSdk 34.
- Conserva applicationId y certificado de firma para instalar sobre v0.19.0.

## 0.18.1 — SIGNAL-R

### Corregido

- Nuevo asistente de dos pasos para el bloqueo “Configuración restringida” de Android/Xiaomi.
- Acceso directo a la ficha de AKARI para elegir `⋮ → Permitir configuración restringida`.
- Segundo botón separado para activar `Centro AKARI`, con explicación visible si el sistema vuelve a bloquearlo.
- Ajustes, Dossier y acciones sin permiso usan ahora el mismo flujo guiado.

## 0.18.0 — SIGNAL

### Nuevo

- Centro AKARI de avisos con servicio de acceso, filtros y contador en HOME.
- Tarjeta emergente propia y reacción animada de Akari.
- Prioridad visual para llamadas y mensajes.
- Acciones de notificación, respuesta rápida, descarte y ajustes por aplicación.
- Privacidad de contenido y anuncios de voz configurables.
- Modo opcional `HOME propietario` que oculta la barra de estado dentro del launcher.
- Comando de voz y búsqueda `avisos`, `notificaciones` o `centro akari`.
- Acceso al Centro desde HOME, Ajustes y Dossier.
- Estante `OCULTAS` en Atelier para recuperar aplicaciones escondidas.
- Selección automática de la voz española instalada de mayor calidad.

### Corregido

- El botón Avisos ya no depende de una API privada para desplegar la cortina de Android.
- El padding de las pantallas ya no se pierde al aplicar insets.
- La batería ya no se consulta cuatro veces por segundo.
- El TTS ya no recibe etiquetas SSML como texto plano ni usa un tono extremo.
- Las versiones de Gradle, recursos y script de compilación coinciden en 0.18.0.

### Seguridad y privacidad

- Eliminados `QUERY_ALL_PACKAGES`, `EXPAND_STATUS_BAR` y `POST_NOTIFICATIONS`.
- Los avisos activos no se guardan en disco ni se envían a red.
- El acceso sensible se habilita exclusivamente desde Ajustes de Android.
