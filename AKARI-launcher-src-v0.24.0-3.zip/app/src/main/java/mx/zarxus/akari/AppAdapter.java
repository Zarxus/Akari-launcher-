package mx.zarxus.akari;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ImageView;
import android.widget.TextView;

import java.util.ArrayList;
import java.util.List;

public class AppAdapter extends BaseAdapter {
    private final LayoutInflater inf;
    private final int layout;
    private List<AppInfo> data = new ArrayList<>();

    public AppAdapter(Context ctx, int layout) {
        this.inf = LayoutInflater.from(ctx);
        this.layout = layout;
    }

    public void setData(List<AppInfo> data) {
        this.data = data;
        notifyDataSetChanged();
    }

    @Override public int getCount() { return data.size(); }
    @Override public AppInfo getItem(int position) { return data.get(position); }
    @Override public long getItemId(int position) {
        String pkg = data.get(position).packageName;
        return pkg == null ? position : pkg.hashCode();
    }
    @Override public boolean hasStableIds() { return true; }

    @Override
    public View getView(int position, View convertView, ViewGroup parent) {
        View v = convertView;
        boolean fresh = v == null;
        if (fresh) v = inf.inflate(layout, parent, false);
        AppInfo a = data.get(position);
        ImageView icon = v.findViewById(R.id.icon);
        TextView label = v.findViewById(R.id.label);
        TextView meta = v.findViewById(R.id.appMeta);
        icon.setImageDrawable(a.icon);
        label.setText(a.label);
        v.setTag(a.packageName);
        boolean pinned = Prefs.pinned(a.packageName);
        v.setContentDescription(a.label + (pinned ? ". Fijada en el dock." : ". Aplicación.")
                + " Toca para abrir; mantén para acciones.");
        v.setBackgroundResource(pinned ? R.drawable.bg_app_tile_pinned : R.drawable.bg_app_tile);
        if (meta != null) {
            meta.setText(pinned ? "● DOCK" : "APP");
            meta.setTextColor(pinned ? 0xFFFF2ED9 : 0xFF817A98);
        }
        DockMotion.bind(v);
        if (fresh) {
            v.setAlpha(0f);
            v.setTranslationY(18f);
            v.setScaleX(.96f);
            v.setScaleY(.96f);
            v.animate().alpha(1f).translationY(0f).scaleX(1f).scaleY(1f)
                    .setStartDelay(Math.min(180L, position * 18L)).setDuration(220L).start();
        } else {
            v.animate().cancel();
            v.setAlpha(1f);
            v.setTranslationX(0f);
            v.setTranslationY(0f);
            v.setRotation(0f);
            v.setScaleX(1f);
            v.setScaleY(1f);
        }
        return v;
    }
}
