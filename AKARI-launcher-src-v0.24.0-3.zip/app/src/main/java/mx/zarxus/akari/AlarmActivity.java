package mx.zarxus.akari;

import android.Manifest;
import android.animation.ObjectAnimator;
import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import java.text.DateFormat;
import java.util.Date;

public class AlarmActivity extends Activity {
    private static final String[] D = {"D","L","M","X","J","V","S"};
    private final TextView[] dayViews = new TextView[7];
    private TimePicker time;
    private EditText label;
    private TextView state, enable, gradual, snooze, exact, line;
    private int mask;
    private ObjectAnimator floatArt;

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_alarm);
        Insets.attach(this); SoundEngine.init(this); Voice.init(this);
        time = findViewById(R.id.alarmTime); label = findViewById(R.id.alarmLabel);
        state = findViewById(R.id.alarmState); enable = findViewById(R.id.alarmEnable);
        gradual = findViewById(R.id.alarmGradual); snooze = findViewById(R.id.alarmSnoozeMinutes);
        exact = findViewById(R.id.alarmExact); line = findViewById(R.id.alarmLine);
        time.setIs24HourView(android.text.format.DateFormat.is24HourFormat(this));
        time.setHour(Prefs.alarmHour());
        time.setMinute(Prefs.alarmMinute());
        label.setText(Prefs.alarmLabel()); mask = Prefs.alarmDays(); buildDays();
        findViewById(R.id.btnBack).setOnClickListener(v -> { SoundEngine.back(); finish(); });
        findViewById(R.id.alarmArt).setOnClickListener(v -> {
            line.setText(AkariLines.alarmSet()); SoundEngine.breath(); Voice.speak(line.getText().toString());
        });
        gradual.setOnClickListener(v -> { Prefs.setAlarmGradual(!Prefs.alarmGradual()); SoundEngine.click(); render(); });
        snooze.setOnClickListener(v -> {
            int n=Prefs.alarmSnoozeMinutes(); Prefs.setAlarmSnoozeMinutes(n==5?10:n==10?15:5);
            SoundEngine.click(); render();
        });
        exact.setOnClickListener(v -> {
            if (!AlarmScheduler.canExact(this)) AlarmScheduler.requestExact(this);
            else if (!AlarmScheduler.canFullScreen(this)) AlarmScheduler.requestFullScreen(this);
        });
        enable.setOnClickListener(v -> toggle());
        findViewById(R.id.alarmTest).setOnClickListener(v -> {
            save(); startActivity(new Intent(this, AlarmRingActivity.class).putExtra(AlarmRingActivity.EXTRA_TEST,true));
        });
        int[] motion={R.id.alarmArt,R.id.alarmGradual,R.id.alarmSnoozeMinutes,R.id.alarmExact,
                R.id.alarmTest,R.id.alarmEnable};
        for(int id:motion) DockMotion.bind(findViewById(id));
        render();
    }

    private void buildDays() {
        LinearLayout row=findViewById(R.id.alarmDays); row.removeAllViews();
        for (int i=0;i<7;i++) {
            final int x=i; TextView v=new TextView(this); v.setText(D[i]); v.setGravity(Gravity.CENTER); v.setTextSize(12);
            LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(0,dp(44),1); lp.setMargins(dp(3),0,dp(3),0); v.setLayoutParams(lp);
            v.setOnClickListener(q -> { int bit=1<<x; mask^=bit; if(mask==0)mask=bit; SoundEngine.click(); renderDays(); });
            DockMotion.bind(v);
            dayViews[i]=v; row.addView(v);
        }
        renderDays();
    }

    private void renderDays() {
        for(int i=0;i<7;i++) { boolean on=(mask&(1<<i))!=0;
            dayViews[i].setBackgroundResource(on?R.drawable.bg_chip_selected:R.drawable.bg_chip);
            dayViews[i].setTextColor(on?0xFF2EF0FF:0xFF9B93B3);
        }
    }

    private void toggle() {
        save(); boolean on=!Prefs.alarmEnabled(); Prefs.setAlarmEnabled(on);
        if(on) {
            long at=AlarmScheduler.schedule(this); SoundEngine.unlock(); Voice.speak(AkariLines.alarmSet()); askNotices();
            if(!AlarmScheduler.canExact(this)) new AlertDialog.Builder(this).setTitle("Falta precisión exacta")
                    .setMessage("La alarma está guardada, pero Android puede retrasarla. Autoriza “Alarmas y recordatorios” para que AKARI despierte a la hora exacta.")
                    .setNegativeButton("DESPUÉS",null).setPositiveButton("AUTORIZAR",(d,w)->AlarmScheduler.requestExact(this)).show();
            else if(!AlarmScheduler.canFullScreen(this)) new AlertDialog.Builder(this).setTitle("Permite la pantalla del despertador")
                    .setMessage("Android necesita una autorización adicional para mostrar a AKARI encima de la pantalla bloqueada cuando suene.")
                    .setNegativeButton("DESPUÉS",null).setPositiveButton("AUTORIZAR",(d,w)->AlarmScheduler.requestFullScreen(this)).show();
            else Toast.makeText(this,"Próxima: "+DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(at)),Toast.LENGTH_LONG).show();
        } else { AlarmScheduler.cancel(this); SoundEngine.back(); }
        render();
    }

    private void save() {
        int h=time.getHour();
        int m=time.getMinute();
        String s=label.getText().toString().trim();
        Prefs.setAlarmConfig(h,m,mask,s.isEmpty()?"Despierta, Saúl":s);
        if(Prefs.alarmEnabled()) AlarmScheduler.schedule(this);
    }

    private void askNotices() {
        if(Build.VERSION.SDK_INT>=33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)!=PackageManager.PERMISSION_GRANTED)
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS},620);
    }

    private void render() {
        boolean on=Prefs.alarmEnabled(), precise=AlarmScheduler.canExact(this), full=AlarmScheduler.canFullScreen(this);
        enable.setText(on?"DESACTIVAR DESPERTADOR":"ACTIVAR DESPERTADOR");
        enable.setTextColor(on?0xFF2EF0FF:0xFFFF2ED9);
        gradual.setText("VOLUMEN GRADUAL · "+(Prefs.alarmGradual()?"ON":"OFF"));
        snooze.setText("POSPONER · "+Prefs.alarmSnoozeMinutes()+" MIN");
        exact.setVisibility(precise&&full?View.GONE:View.VISIBLE);
        exact.setText(!precise?"AUTORIZAR HORA EXACTA":"AUTORIZAR PANTALLA COMPLETA");
        long at=Prefs.alarmNextAt();
        state.setText(!on?"OFFLINE · toca activar cuando esté lista":(precise?"EXACTA · ":"APROXIMADA · ")
                +DateFormat.getDateTimeInstance(DateFormat.SHORT,DateFormat.SHORT).format(new Date(at>0?at:System.currentTimeMillis())));
        renderDays();
    }

    @Override protected void onResume() {
        super.onResume(); if(Prefs.alarmEnabled()&&AlarmScheduler.canExact(this))AlarmScheduler.schedule(this); render();
        View art=findViewById(R.id.alarmArt); floatArt=ObjectAnimator.ofFloat(art,View.TRANSLATION_Y,0,-dp(6)*Prefs.motionScale(),0);
        floatArt.setDuration(3200);floatArt.setRepeatCount(ObjectAnimator.INFINITE);floatArt.start();
    }
    @Override protected void onPause(){save();if(floatArt!=null)floatArt.cancel();super.onPause();}
    private int dp(int n){return Math.round(n*getResources().getDisplayMetrics().density);}
}
