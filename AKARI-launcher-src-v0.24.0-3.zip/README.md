# AKARI Launcher v0.24.0 — VEIL

Launcher Android nativo con companion interactiva, centro propio de avisos, despertador y herramientas integradas. VEIL convierte los bordes de HOME en ventanas de manipulación directa y conserva RIFT como escena secundaria.

## VEIL · ventanas unidas al gesto

- Jala desde la izquierda para descubrir las aplicaciones, desde la derecha para el panel personalizado de AKARI, desde arriba para señales y desde abajo para controles.
- Cada ventana sigue la distancia exacta del dedo. Si la sueltas despacio en la zona media queda anclada parcialmente; puedes agarrar su borde visible para continuar abriendo o devolverla. Posición y velocidad deciden el anclaje final.
- Al cruzar el umbral responde con vibración; la apertura usa inclinación, rebote, parallax de la imagen y una firma sonora diferente por dirección y progreso.
- Las cuatro interfaces viven dentro de `HomeActivity`: la pantalla principal permanece detrás y no se simula la transición lanzando otra Activity.
- La ventana de aplicaciones filtra en vivo, muestra tarjetas de tres columnas y abre siempre el paquete Android instalado. Solo búsquedas y enlaces explícitos pueden usar un navegador.
- El panel derecho usa arte personalizado de AKARI con perfil, lluvia y chaqueta, parallax, reacción al toque, BOND/HEAT y accesos a RIFT, escenas y galería.
- La capa superior resume clima, UV, luz restante y hasta cuatro avisos interactivos. Toca para abrir el aviso y mantén para descartarlo cuando Android lo permita.
- El control inferior integra Wi‑Fi, Bluetooth, linterna, calculadora, brújula, alarma, música, ajedrez, ajustes, teléfono, volumen y bloqueo.
- Deslizar el cuerpo de AKARI abre las mismas cuatro capas; los botones de RIFT ahora desembocan en ellas antes de abrir herramientas profundas.

## RIFT · segunda capa interactiva

- Las fichas del dock, cajón, sugerencias y comandos de voz abren siempre el APK Android instalado. WhatsApp abre WhatsApp, YouTube abre YouTube y ninguna preferencia antigua puede sustituirlos por su sitio web.
- El navegador interno queda limitado a búsquedas y enlaces web explícitos. Puede desactivarse desde Ajustes para usar el navegador externo.
- El doble toque sobre AKARI, el botón RIFT de su ventana, el comando `RIFT` o la búsqueda `portal akari` abren una segunda composición del HOME.
- La abertura se anima mediante diagonales, anillos, rejilla, pulsos táctiles y paneles que se apartan; no es un cuadro emergente ni un cambio de retrato.
- Los cuatro bordes actúan como rutas físicas: vestuario, escenas, aplicaciones y música. Deslizar a los lados cambia la paleta; arriba cambia la postura y abajo vuelve al HOME.
- Cuatro identidades visuales persistentes (`NEXUS`, `VIOLETA`, `DAWN`, `CRIMSON`) y tres posturas físicas (`CALMA`, `PULSO`, `GUARDIA`) modifican color, escala, respiración, balance y deformación de la misma marioneta.
- EROTECH deja la imagen de portada estática: usa el cuerpo completo animado sobre el RIFT, con toque localizado, presión, arrastre, pellizco, gestos y diálogo contextual.
- La galería entra por etapas y cada escena incorpora transición de elecciones y parallax continuo que se puede invertir tocando el arte.
- AKARI recuerda estilo, postura, escala y repetición por zona; una insistencia consecutiva produce una reacción distinta.
- El contenido añadido mantiene a AKARI como personaje adulto y sensual sin depender de imágenes rectangulares intercambiables.

## REFINE · acabado integral

- El HOME inicia en modo limpio: conserva información esencial, AKARI y el dock. El triángulo `MOSTRAR HERRAMIENTAS` despliega u oculta el resto sin cambiar de pantalla y recuerda la preferencia.
- Las diez herramientas ya no se comprimen en una sola fila ilegible; viven en un carril horizontal de blancos táctiles uniformes.
- El reloj adapta su tamaño al formato de 12/24 horas y la atmósfera cambia entre amanecer, día, ocaso y noche. Cuando hay datos solares, usa el amanecer y ocaso reales de la ciudad configurada.
- La búsqueda previa es silenciosa, debounced, tolera acentos y coincidencias parciales y coloca hasta cuatro apps útiles en el carril de AKARI. Enter abre la mejor coincidencia o continúa en la web.
- Mantener cualquier app abre el mismo menú profesional: abrir, fijar/quitar del dock, ocultar/restaurar, información y desinstalar.
- El dock prioriza usos reales y herramientas comunes. Fijar una sexta app sustituye correctamente la fijación más antigua; el estante RECIENTES registra recencia real desde esta versión.
- El aviso flotante del HOME se abre con toque y se descarta deslizando a cualquiera de los lados.
- Ajustes añade intensidad de dinámica `CALMA / EQUILIBRADA / VIBRANTE`, volumen SFX y volumen del ambiente por separado. Movimiento, rebote y vibración obedecen el perfil elegido.
- El tamaño elegido con pellizco sobre AKARI queda guardado; el diálogo se actualiza solo al terminar el gesto.
- AKARI y las capas ambientales pausan sus bucles al salir de pantalla; en CALMA reducen también la frecuencia de dibujo.
- El clima evita consultas duplicadas, conserva la última lectura válida cuando falla la red y diferencia claramente una lectura en caché.
- Noticias muestra antigüedad de la caché, impide recargas duplicadas, limita el render a 30 tarjetas, expone COMPARTIR y corrige la detección de la sigla IA.
- El modo TECH ahora mantiene un lenguaje tecnológico coherente también al tocar a AKARI, abrir apps, consultar batería/clima y recibir avisos.
- Sonido de retroceso coherente y transición visual común en las pantallas internas.

## EMBODY · escenario vivo

- El HOME ya no muestra a AKARI dentro de una tarjeta ni intercambia retratos según el heat.
- Una sola figura adulta de cuerpo completo y fondo transparente se dibuja directamente sobre el wallpaper elegido en el teléfono.
- Una malla corporal animada por código produce respiración, balanceo, cadera, inclinación de cabeza, elasticidad y brillo cian/magenta; la intensidad responde a HEAT y BOND.
- Toca distintas zonas, mantén, arrastra, lanza, desliza en cuatro direcciones o pellizca para cambiar la escala. La figura conserva inercia y vuelve a su anclaje con un resorte.
- El giroscopio/acelerómetro inclina la postura. Al desactivar Física, el cuerpo vuelve suavemente a reposo.
- El único recuadro de la companion es un globo compacto de diálogo. Cambia de lado para no tapar la zona que acabas de tocar.
- Doble toque sobre AKARI abre o cierra RIFT; con RIFT cerrado, los cuatro deslizamientos abren las ventanas VEIL correspondientes.
- Ajustes abre el selector real de wallpaper de Android. La lluvia, scanlines y partículas quedan como una capa ambiental opcional encima de ese fondo.

La animación es una marioneta 2D propia basada en malla, no un carrusel de imágenes ni un motor Live2D externo. Todo se procesa localmente.

## SOLAR LINK · UV y ciclo del día

- Índice UV actual con riesgo BAJO, MODERADO, ALTO, MUY ALTO o EXTREMO y color semántico.
- Arco solar en vivo con posición estimada del sol, amanecer, ocaso y tiempo de luz restante.
- Cuenta regresiva independiente hasta el siguiente día según la zona horaria devuelta para la ciudad configurada.
- Toca el arco para escuchar a AKARI resumir el ciclo solar; toca el clima para sincronizarlo de nuevo.
- Temperatura, UV, amanecer y ocaso se obtienen de Open-Meteo. El UV es una estimación meteorológica, no una medición de un sensor del teléfono.

## VECTOR LINK · brújula

- Dial fluido con 72 marcas, rumbo en grados y dieciséis direcciones.
- Prefiere el vector de rotación del teléfono y usa acelerómetro + magnetómetro como respaldo.
- Compensa norte magnético a norte verdadero con la declinación calculada para las coordenadas guardadas.
- Toca el dial para fijar/reanudar un rumbo; mantén para ver la guía de calibración en forma de ocho.
- AKARI comenta cada sector, reacciona físicamente al rumbo y conserva un diálogo compacto sobre el wallpaper.

## DAWN LINK · despertador

- Hora, etiqueta y repetición por días.
- Volumen de alarma gradual, vibración y posponer 5/10/15 minutos.
- Pantalla de AKARI visible sobre el bloqueo con una escena propia y diálogo matinal.
- Se restaura después de reiniciar, cambiar la hora o actualizar la aplicación.
- Usa AlarmClockInfo cuando Android concede alarmas exactas; si no, conserva una programación aproximada y explica cómo autorizarla.
- Android 13+ requiere avisos; Android 14 puede solicitar permiso separado para pantalla completa.
- Acceso desde HOME, Ajustes, búsqueda (alarma, despertador) y voz.

## Mate Link · ajedrez

- IA con tres niveles: Suave, Táctica y Neón.
- Evaluación de material, centro, avance de peones y seguridad legal del rey.
- Cálculo de la IA fuera del hilo de interfaz.
- Pista visual sin alterar la partida y deshacer el turno completo.
- Última jugada, balance de material, sonidos distintos para movimiento/captura y respuesta háptica.

## Core Math · calculadora

- Precedencia real, paréntesis, raíz, potencia, porcentaje y signo.
- Memoria M+ / MR / MC, ANS, historial persistente y vista previa.
- Errores de dominio controlados y diálogo contextual de AKARI.

## AKARI Signal · noticias

- Portada, México, Ciencia y Tecnología, con caché independiente.
- Titular enfocado, navegación anterior/siguiente, fuente y antigüedad.
- Lectura por voz, apertura y compartir con pulsación larga.
- AKARI ANALIZA comenta únicamente lo que permite inferir el titular y recomienda verificar la fuente; no presenta un titular como si fuera el artículo completo.
- AKARI ahora vive en la cabecera como figura animada: deslizarla cambia de titular, subir lee, bajar analiza, mantener abre y doble toque abre la fuente.
- La tarjeta enfocada se ilumina y el cuerpo responde con impulso, squash y gesto según la acción.

## Centro AKARI

- AVISOS, la cápsula superior y la barra de HOME abren la bandeja de AKARI, no la cortina del sistema.
- Lee avisos activos solo después de que el propietario autoriza NotificationListenerService.
- Prioriza llamadas, filtra señales y ejecuta las acciones publicadas por cada app: abrir, responder, contestar/rechazar cuando estén disponibles, descartar y configurar.
- El contenido activo vive en memoria y no se sube a servidores.
- Android puede bloquear el permiso sensible en APK instalados manualmente. AKARI muestra la ruta exacta: ficha de la app → ⋮ → Permitir configuración restringida → activar Centro AKARI.

### Límite real de Android

AKARI reemplaza la presentación y operación cotidiana de los avisos mientras usas el launcher. Android y cada app siguen entregando el aviso. Una llamada solo puede contestarse desde AKARI cuando el marcador publica esa acción. Reemplazar por completo la pantalla telefónica exigiría convertir AKARI también en el marcador predeterminado.

## Movimiento, sonido y voz

- Física magnética en dock, botones, tarjetas, cajón y lanzamientos: elevación, inclinación, rebote y onda entre vecinos.
- Patrones hápticos distintos para toque, presión, éxito, advertencia y captura.
- Nuevas capas de audio para dock, movimiento, captura, calculadora, noticias y alarma.
- Cada aplicación recibe una firma sonora determinista distinta para tocar, mantener y lanzar; no necesita archivos duplicados por app.
- Cajón y Atelier usan tarjetas de tres columnas, halo, estado `APP`/`● DOCK`, entrada escalonada y selección magenta/cian más legible.
- Diálogo contextual con reducción de repeticiones; la música ambiente baja mientras AKARI habla.

## Datos y atribución

Los datos meteorológicos, UV y solares se consultan en [Open-Meteo](https://open-meteo.com/) bajo CC BY 4.0. AKARI guarda una caché local breve para reducir solicitudes y muestra la atribución dentro del instrumento solar.

## Instalar y autorizar

1. Instala AKARI-v0.24.0.apk encima de v0.21.0, v0.22.0 o v0.23.0.
2. Abre ALARMA, elige hora/días y toca ACTIVAR DESPERTADOR.
3. Concede avisos, hora exacta y pantalla completa si Android los solicita.
4. Abre AVISOS. Si aparece “Configuración restringida”, sigue los dos pasos visibles dentro de Centro AKARI.
5. Para máxima fiabilidad, en Permisos e atajos habilita batería sin límite.

## Compilar

Requisitos: JDK 11 o superior, Android SDK Platform 34 y Build Tools 34.0.0.

~~~bash
export ANDROID_SDK_ROOT=/ruta/al/android-sdk
./build_apk.sh
~~~

El script genera AKARI-v0.24.0.apk, alineado y firmado con la clave de desarrollo incluida para permitir la actualización sobre las compilaciones anteriores firmadas con esa misma clave.
